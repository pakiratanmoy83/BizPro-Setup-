<?php
require __DIR__ . '/inc/bootstrap.php';
do_logout();
redirect('login.php');
