<?php
/** Printable documents: invoices (A4 / thermal), vouchers, party statements. ?pdf=1 downloads PDF. */
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/posting.php';
if (!validate_session()) redirect('login.php');

$type = $_GET['type'] ?? 'doc';
$pdf = !empty($_GET['pdf']);
$S = settings_all();
$cur = '';
$logo = ($S['business_logo'] ?? '') && is_file(BASE_DIR . '/' . $S['business_logo']) ? $S['business_logo'] : '';

try {
    if ($type === 'statement') {
        $id = (int)($_GET['id'] ?? 0);
        $p = row('SELECT * FROM parties WHERE id=? AND is_deleted=0', [$id]);
        if (!$p) throw new AppException('Party not found');
        $isC = $p['ptype'] === 'C';
        if (!can_any($isC ? ['customer.ledger', 'customer.view'] : ['supplier.ledger', 'supplier.view'])) throw new AppException('Access denied');
        [$fyS] = fy_range();
        $from = ind('from', $fyS); $to = ind('to');
        [$ob, $lines] = party_statement($id, $from, $to);
        $docTitle = ($isC ? 'Customer' : 'Supplier') . ' Statement';
        $fmt = 'A4';
        $fileName = 'Statement_' . $p['code'] . '_' . $from . '_' . $to;
        audit('PRINT', $isC ? 'customer' : 'supplier', $id, $p['code'], ['statement' => "$from to $to"]);
    } else {
        $id = (int)($_GET['id'] ?? 0);
        $d = row('SELECT d.*, a.name account, a2.name to_account, ec.name exp_cat FROM documents d LEFT JOIN accounts a ON a.id=d.account_id LEFT JOIN accounts a2 ON a2.id=d.to_account_id LEFT JOIN expense_categories ec ON ec.id=d.expense_category_id WHERE d.id=?', [$id]);
        if (!$d) throw new AppException('Document not found');
        [$canView, $own] = doc_view_scope($d['dtype']);
        if (!$canView && !can(perm_for($d['dtype'], 'add'))) throw new AppException('Access denied');
        if ($own && $d['created_by'] != current_user()['id']) throw new AppException('Access denied');
        $cfg = dt($d['dtype']);
        $p = $d['party_id'] ? row('SELECT * FROM parties WHERE id=?', [$d['party_id']]) : null;
        $items = rows('SELECT * FROM document_items WHERE document_id=? ORDER BY line_no', [$id]);
        $against = $d['against_doc_id'] ? row('SELECT doc_no, doc_date FROM documents WHERE id=?', [$d['against_doc_id']]) : null;
        $fmt = ($_GET['fmt'] ?? '') === 'thermal' ? 'thermal' : (($_GET['fmt'] ?? '') === 'A4' ? 'A4' : ($cfg['items'] ? ($S['invoice_format'] ?? 'A4') : 'A4'));
        if ($fmt !== 'thermal') $fmt = 'A4';
        $titles = ['SALE' => ($S['business_gstin'] ?? '') ? 'TAX INVOICE' : 'INVOICE', 'PURCHASE' => 'PURCHASE INVOICE', 'SRET' => 'CREDIT NOTE / SALES RETURN', 'PRET' => 'DEBIT NOTE / PURCHASE RETURN', 'RECEIPT' => 'PAYMENT RECEIPT', 'PAYMENT' => 'PAYMENT VOUCHER', 'EXPENSE' => 'EXPENSE VOUCHER', 'CASH' => 'CASH / BANK VOUCHER', 'ADJ' => 'STOCK ADJUSTMENT'];
        $docTitle = $titles[$d['dtype']];
        $fileName = $d['doc_no'];
        $party_bal = $p ? party_balance((int)$p['id']) : 0;
        $isReprint = (int)val("SELECT COUNT(*) FROM audit_log WHERE module=? AND record_id=? AND action='PRINT'", [$d['dtype'], $id]) > 0;
        audit('PRINT', $d['dtype'], $id, $d['doc_no'], ['format' => $pdf ? 'PDF' : $fmt]);
    }
} catch (AppException $ex) {
    http_response_code(403);
    echo '<p style="font-family:sans-serif;color:#b91c1c;padding:20px">' . e($ex->getMessage()) . '</p>';
    exit;
}
$tw = (int)($S['thermal_width'] ?? 80) === 58 ? 58 : 80;
?><!doctype html>
<html><head><meta charset="utf-8"><title><?= e($fileName) ?></title>
<style>
*{box-sizing:border-box} body{font-family:"Segoe UI",Arial,sans-serif;color:#111;margin:0;background:#e5e7eb;font-size:12px}
.toolbar{position:sticky;top:0;background:#1e293b;color:#fff;padding:8px 14px;display:flex;gap:8px;align-items:center;z-index:5}
.toolbar button{background:#fff;border:0;border-radius:6px;padding:6px 12px;cursor:pointer;font-weight:600}.toolbar .sp{flex:1}
.page{background:#fff;margin:14px auto;box-shadow:0 2px 10px rgba(0,0,0,.15)}
.a4{width:210mm;min-height:290mm;padding:12mm}
.thermal{width:<?= $tw ?>mm;padding:3mm;font-size:<?= $tw === 58 ? '10px' : '11px' ?>;font-family:"Consolas","Courier New",monospace}
table{width:100%;border-collapse:collapse} .num{text-align:right} .c{text-align:center} .b{font-weight:700}
.a4 .head{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid #1e3a8a;padding-bottom:8px;gap:12px}
.a4 .head img{max-height:70px;max-width:160px}
.a4 .biz h1{margin:0;font-size:22px;color:#1e3a8a}.a4 .biz div{color:#333;line-height:1.45}
.a4 .dtitle{font-size:16px;font-weight:700;text-align:center;margin:8px 0;letter-spacing:1px}
.a4 .boxes{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px}
.a4 .box{border:1px solid #cbd5e1;border-radius:4px;padding:8px;line-height:1.5}.a4 .box h4{margin:0 0 4px;font-size:11px;color:#475569;text-transform:uppercase}
.a4 table.items th{background:#1e3a8a;color:#fff;padding:6px 5px;font-size:11px;text-align:left}.a4 table.items th.num{text-align:right}
.a4 table.items td{padding:5px;border-bottom:1px solid #e2e8f0;vertical-align:top}.a4 table.items tfoot td{font-weight:700;background:#f1f5f9;border-top:1px solid #94a3b8}
.a4 .sum{display:grid;grid-template-columns:1fr 280px;gap:14px;margin-top:10px}
.a4 .tot td{padding:3px 6px}.a4 .tot tr.g td{font-size:15px;font-weight:700;border-top:2px solid #1e3a8a;border-bottom:2px solid #1e3a8a}
.a4 .words{border:1px dashed #94a3b8;padding:6px;margin-bottom:8px}
.a4 .terms{white-space:pre-line;color:#333;font-size:11px}
.a4 .sign{display:flex;justify-content:space-between;margin-top:40px;align-items:flex-end}.a4 .sign div{text-align:center;min-width:180px;border-top:1px solid #333;padding-top:4px}
.a4 .foot{text-align:center;color:#555;margin-top:14px;font-size:11px}
.a4 table.gst td,.a4 table.gst th{border:1px solid #cbd5e1;padding:3px 5px;font-size:10.5px}
.thermal .c1{text-align:center}.thermal hr{border:0;border-top:1px dashed #000;margin:4px 0}.thermal td{padding:1px 0;vertical-align:top}
.thermal h2{margin:2px 0;font-size:1.35em;text-align:center}.thermal img{max-width:40mm;max-height:18mm;display:block;margin:0 auto}
.stamp{color:#b91c1c;border:2px solid #b91c1c;display:inline-block;padding:2px 8px;font-weight:700;transform:rotate(-4deg)}
@media print{body{background:#fff}.toolbar{display:none}.page{margin:0;box-shadow:none}
  @page{size:<?= $fmt === 'thermal' ? $tw . 'mm auto' : 'A4' ?>;margin:<?= $fmt === 'thermal' ? '0' : '8mm' ?>}.a4{width:auto;min-height:0;padding:0}}
</style></head><body>
<div class="toolbar"><b><?= e($docTitle) ?></b> <span><?= e($fileName) ?></span><span class="sp"></span>
  <?php if ($type !== 'statement' && $cfg['items'] && $d['dtype'] !== 'ADJ'): ?><button onclick="location.href='print.php?id=<?= $id ?>&fmt=<?= $fmt === 'thermal' ? 'A4' : 'thermal' ?>'"><?= $fmt === 'thermal' ? 'A4 format' : 'Thermal format' ?></button><?php endif; ?>
  <button onclick="makePdf()">Download PDF</button><button onclick="window.print()">Print (Ctrl+P)</button><button onclick="window.close()">Close</button></div>

<?php if ($type === 'statement'): $bal = $ob; $td = 0; $tc = 0; ?>
<div class="page a4" id="doc">
  <?php include __DIR__ . '/inc/print_head.php'; ?>
  <div class="dtitle"><?= e(strtoupper($docTitle)) ?></div>
  <div class="boxes"><div class="box"><h4><?= $isC ? 'Customer' : 'Supplier' ?></h4><b><?= e($p['name']) ?></b> (<?= e($p['code']) ?>)<br><?= nl2br(e($p['address'])) ?><br><?= e($p['mobile']) ?> <?= $p['gstin'] ? '<br>GSTIN: ' . e($p['gstin']) : '' ?></div>
    <div class="box"><h4>Period</h4><?= dmy($from) ?> to <?= dmy($to) ?><br>Printed: <?= dmyhm(now()) ?> by <?= e(current_user()['username']) ?></div></div>
  <table class="items"><thead><tr><th>Date</th><th>Doc No</th><th>Particulars</th><th class="num">Debit</th><th class="num">Credit</th><th class="num">Balance</th></tr></thead><tbody>
    <tr><td><?= dmy($from) ?></td><td></td><td class="b">Opening Balance</td><td></td><td></td><td class="num b"><?= money($ob) ?></td></tr>
    <?php foreach ($lines as $l): $bal += $isC ? $l['debit'] - $l['credit'] : $l['credit'] - $l['debit']; $td += $l['debit']; $tc += $l['credit']; ?>
    <tr><td><?= dmy($l['txn_date']) ?></td><td><?= e($l['doc_no']) ?></td><td><?= e($l['narration']) ?></td><td class="num"><?= $l['debit'] > 0 ? money($l['debit']) : '' ?></td><td class="num"><?= $l['credit'] > 0 ? money($l['credit']) : '' ?></td><td class="num"><?= money($bal) ?></td></tr>
    <?php endforeach; ?></tbody>
    <tfoot><tr><td colspan="3">Closing Balance (<?= $bal >= 0 ? ($isC ? 'Receivable' : 'Payable') : 'Advance' ?>)</td><td class="num"><?= money($td) ?></td><td class="num"><?= money($tc) ?></td><td class="num"><?= money($bal) ?></td></tr></tfoot></table>
  <div class="words" style="margin-top:10px">Closing balance in words: <b><?= e(amount_in_words(abs($bal))) ?></b></div>
  <div class="sign"><div>Received / Checked by</div><div>For <?= e($S['business_name']) ?><br><br>Authorised Signatory</div></div>
</div>

<?php elseif ($fmt === 'thermal'): ?>
<div class="page thermal" id="doc">
  <?php if ($logo): ?><img src="<?= e($logo) ?>" alt=""><?php endif; ?>
  <h2><?= e($S['business_name']) ?></h2>
  <div class="c1"><?= nl2br(e($S['business_address'])) ?><?= $S['business_phone'] ? '<br>Ph: ' . e($S['business_phone']) : '' ?><?= $S['business_gstin'] ? '<br>GSTIN: ' . e($S['business_gstin']) : '' ?></div>
  <hr><div class="c1 b"><?= e($docTitle) ?><?= $isReprint ? ' (REPRINT)' : '' ?></div><hr>
  <table><tr><td>No: <b><?= e($d['doc_no']) ?></b></td><td class="num"><?= dmy($d['doc_date']) ?> <?= date('h:i A', strtotime($d['created_at'])) ?></td></tr>
  <?php if ($p): ?><tr><td colspan="2"><?= $cfg['ptype'] === 'C' ? 'Customer' : 'Supplier' ?>: <?= e($p['name']) ?><?= $p['mobile'] ? ' ' . e($p['mobile']) : '' ?><?= $p['gstin'] ? '<br>GSTIN: ' . e($p['gstin']) : '' ?></td></tr><?php endif; ?>
  <?php if ($against): ?><tr><td colspan="2">Against: <?= e($against['doc_no']) ?></td></tr><?php endif; ?>
  <tr><td colspan="2">Cashier: <?= e($d['created_by_name']) ?></td></tr></table><hr>
  <?php if ($cfg['items']): ?>
  <table><thead><tr><td class="b">Item</td><td class="num b">Qty</td><td class="num b">Rate</td><td class="num b">Amt</td></tr></thead><tbody>
  <?php foreach ($items as $it): ?><tr><td colspan="4"><?= e($it['product_name']) ?><?= $it['gst_pct'] > 0 ? ' <small>(GST ' . (float)$it['gst_pct'] . '%)</small>' : '' ?></td></tr>
    <tr><td><?= $it['disc_amt'] > 0 ? '<small>Disc ' . money($it['disc_amt']) . '</small>' : '' ?></td><td class="num"><?= qtyf($it['qty']) ?></td><td class="num"><?= money($it['rate']) ?></td><td class="num"><?= money($it['total']) ?></td></tr><?php endforeach; ?>
  </tbody></table><hr>
  <table>
    <tr><td>Items: <?= count($items) ?> &nbsp; Qty: <?= qtyf(array_sum(array_column($items, 'qty'))) ?></td><td class="num"></td></tr>
    <tr><td>Taxable</td><td class="num"><?= money($d['taxable_amount']) ?></td></tr>
    <?php if ($d['is_interstate']): ?><tr><td>IGST</td><td class="num"><?= money($d['igst']) ?></td></tr><?php elseif ($d['gst_total'] > 0): ?><tr><td>CGST</td><td class="num"><?= money($d['cgst']) ?></td></tr><tr><td>SGST</td><td class="num"><?= money($d['sgst']) ?></td></tr><?php endif; ?>
    <?php if ($d['item_discount'] + $d['bill_discount'] > 0): ?><tr><td>Total Discount</td><td class="num">-<?= money($d['item_discount'] + $d['bill_discount']) ?></td></tr><?php endif; ?>
    <?php if ($d['other_charges'] > 0): ?><tr><td>Other Charges</td><td class="num"><?= money($d['other_charges']) ?></td></tr><?php endif; ?>
    <?php if ($d['round_off'] != 0): ?><tr><td>Round Off</td><td class="num"><?= money($d['round_off']) ?></td></tr><?php endif; ?>
    <tr><td class="b" style="font-size:1.25em">TOTAL</td><td class="num b" style="font-size:1.25em"><?= money($d['grand_total']) ?></td></tr>
    <tr><td>Paid (<?= e($d['payment_mode']) ?>)</td><td class="num"><?= money($d['paid_amount']) ?></td></tr>
    <?php if ($d['due_amount'] > 0): ?><tr><td class="b">Due</td><td class="num b"><?= money($d['due_amount']) ?></td></tr><?php endif; ?>
  </table>
  <?php else: ?>
  <table><tr><td>Amount</td><td class="num b" style="font-size:1.3em"><?= money($d['grand_total']) ?></td></tr><tr><td>Mode</td><td class="num"><?= e($d['payment_mode'] ?: $d['entry_type']) ?></td></tr><?php if ($d['reference_no']): ?><tr><td>Ref</td><td class="num"><?= e($d['reference_no']) ?></td></tr><?php endif; ?>
  <?php if ($p): ?><tr><td>Balance now</td><td class="num"><?= money($party_bal) ?></td></tr><?php endif; ?></table>
  <?php endif; ?>
  <hr><div><?= e(amount_in_words((float)$d['grand_total'])) ?></div><hr>
  <div class="c1"><?= nl2br(e($S['invoice_footer'] ?? '')) ?></div>
</div>

<?php else: /* A4 */ ?>
<div class="page a4" id="doc">
  <?php include __DIR__ . '/inc/print_head.php'; ?>
  <div class="dtitle"><?= e($docTitle) ?> <?= $isReprint ? '<span class="stamp">DUPLICATE</span>' : '' ?> <?= $d['is_deleted'] ? '<span class="stamp">CANCELLED</span>' : '' ?></div>
  <div class="boxes">
    <div class="box"><h4><?= $p ? ($cfg['ptype'] === 'C' ? 'Bill To' : 'Supplier') : 'Details' ?></h4>
      <?php if ($p): ?><b><?= e($p['name']) ?></b><?= $p['company_name'] ? '<br>' . e($p['company_name']) : '' ?><br><?= nl2br(e($p['address'])) ?><?= $p['state'] ? '<br>State: ' . e($p['state']) : '' ?><?= $p['mobile'] ? '<br>Mobile: ' . e($p['mobile']) : '' ?><?= $p['gstin'] ? '<br>GSTIN: <b>' . e($p['gstin']) . '</b>' : '' ?>
      <?php else: ?><?= $d['exp_cat'] ? 'Expense head: <b>' . e($d['exp_cat']) . '</b><br>' : '' ?><?= $d['entry_type'] ? 'Type: <b>' . e($d['entry_type']) . '</b>' . ($d['to_account'] ? ' to ' . e($d['to_account']) : '') . '<br>' : '' ?><?= e($d['description']) ?><?php endif; ?></div>
    <div class="box"><h4>Document</h4>No: <b><?= e($d['doc_no']) ?></b><br>Date: <b><?= dmy($d['doc_date']) ?></b><?= $d['ref_invoice_no'] ? '<br>Supplier Bill No: ' . e($d['ref_invoice_no']) : '' ?><?= $against ? '<br>Against Invoice: ' . e($against['doc_no']) . ' dt. ' . dmy($against['doc_date']) : '' ?>
      <?php if ($d['payment_mode']): ?><br>Payment: <?= e($d['payment_mode']) ?><?= $d['account'] ? ' (' . e($d['account']) . ')' : '' ?><?php endif; ?><?= $d['reference_no'] ? '<br>Ref: ' . e($d['reference_no']) : '' ?>
      <?php if ($cfg['items'] && $d['dtype'] !== 'ADJ'): ?><br>Place of supply: <?= e($p['state'] ?? $S['business_state']) ?> (<?= $d['is_interstate'] ? 'IGST' : 'CGST+SGST' ?>)<?php endif; ?>
      <br><small>Prepared by <?= e($d['created_by_name']) ?> on <?= dmyhm($d['created_at']) ?></small></div>
  </div>
  <?php if ($cfg['items']): $sumQty = 0; ?>
  <table class="items"><thead><tr><th>#</th><th>Product</th><th>HSN</th><th class="num">Qty</th><th class="num">Rate</th><?php if ($d['dtype'] !== 'ADJ'): ?><th class="num">Disc</th><th class="num">Taxable</th><th class="num">GST</th><?php endif; ?><th class="num">Amount</th></tr></thead><tbody>
    <?php foreach ($items as $it): $sumQty += $it['qty']; ?>
    <tr><td><?= $it['line_no'] ?></td><td><?= e($it['product_name']) ?><?= $it['mrp'] > 0 && $d['dtype'] === 'SALE' ? '<br><small style="color:#666">MRP ' . money($it['mrp']) . '</small>' : '' ?></td><td><?= e($it['hsn_code']) ?></td>
      <td class="num"><?= qtyf($it['qty']) ?> <?= e($it['unit']) ?><?= $it['free_qty'] > 0 ? '<br><small>+' . qtyf($it['free_qty']) . ' free</small>' : '' ?></td><td class="num"><?= money($it['rate']) ?></td>
      <?php if ($d['dtype'] !== 'ADJ'): ?><td class="num"><?= $it['disc_amt'] > 0 ? money($it['disc_amt']) : '-' ?></td><td class="num"><?= money($it['taxable']) ?></td><td class="num"><?= money($it['gst_amt']) ?><br><small><?= (float)$it['gst_pct'] ?>%</small></td><?php endif; ?>
      <td class="num"><?= money($d['dtype'] === 'ADJ' ? $it['amount'] : $it['total']) ?></td></tr>
    <?php endforeach; ?></tbody>
    <?php if ($d['dtype'] !== 'ADJ'): ?><tfoot><tr><td colspan="3">Total</td><td class="num"><?= qtyf($sumQty) ?></td><td></td><td class="num"><?= money($d['item_discount']) ?></td><td class="num"><?= money($d['taxable_amount']) ?></td><td class="num"><?= money($d['gst_total']) ?></td><td class="num"><?= money($d['taxable_amount'] + $d['gst_total']) ?></td></tr></tfoot><?php endif; ?>
  </table>
  <?php if ($d['dtype'] !== 'ADJ'):
    $gstRows = [];
    foreach ($items as $it) { $k = (string)(float)$it['gst_pct']; $gstRows[$k]['t'] = ($gstRows[$k]['t'] ?? 0) + $it['taxable']; $gstRows[$k]['g'] = ($gstRows[$k]['g'] ?? 0) + $it['gst_amt']; }
    ksort($gstRows, SORT_NUMERIC); ?>
  <div class="sum">
    <div>
      <div class="words">Amount in words: <b><?= e(amount_in_words((float)$d['grand_total'])) ?></b></div>
      <?php if ($d['gst_total'] > 0): ?>
      <table class="gst"><thead><tr><th>GST %</th><th class="num">Taxable</th><?php if ($d['is_interstate']): ?><th class="num">IGST</th><?php else: ?><th class="num">CGST</th><th class="num">SGST</th><?php endif; ?><th class="num">Total Tax</th></tr></thead><tbody>
      <?php foreach ($gstRows as $k => $g): ?><tr><td><?= $k ?>%</td><td class="num"><?= money($g['t']) ?></td><?php if ($d['is_interstate']): ?><td class="num"><?= money($g['g']) ?></td><?php else: ?><td class="num"><?= money($g['g'] / 2) ?></td><td class="num"><?= money($g['g'] / 2) ?></td><?php endif; ?><td class="num"><?= money($g['g']) ?></td></tr><?php endforeach; ?>
      </tbody></table><?php endif; ?>
      <?php if ($d['remarks']): ?><p><b>Remarks:</b> <?= nl2br(e($d['remarks'])) ?></p><?php endif; ?>
      <?php if ($p && in_array($d['dtype'], ['SALE', 'PURCHASE'])): ?><p>Current account balance: <b><?= money($party_bal) ?></b> <?= $cfg['ptype'] === 'C' ? '(receivable)' : '(payable)' ?></p><?php endif; ?>
    </div>
    <table class="tot">
      <tr><td>Taxable Value</td><td class="num"><?= money($d['taxable_amount']) ?></td></tr>
      <?php if ($d['is_interstate']): ?><tr><td>IGST</td><td class="num"><?= money($d['igst']) ?></td></tr><?php else: ?><tr><td>CGST</td><td class="num"><?= money($d['cgst']) ?></td></tr><tr><td>SGST</td><td class="num"><?= money($d['sgst']) ?></td></tr><?php endif; ?>
      <?php if ($d['bill_discount'] > 0): ?><tr><td>Bill Discount</td><td class="num">-<?= money($d['bill_discount']) ?></td></tr><?php endif; ?>
      <?php if ($d['other_charges'] > 0): ?><tr><td>Other Charges</td><td class="num"><?= money($d['other_charges']) ?></td></tr><?php endif; ?>
      <tr><td>Round Off</td><td class="num"><?= money($d['round_off']) ?></td></tr>
      <tr class="g"><td>Grand Total</td><td class="num"><?= e($S['currency_symbol'] ?? '') ?> <?= money($d['grand_total']) ?></td></tr>
      <tr><td>Paid</td><td class="num"><?= money($d['paid_amount']) ?></td></tr>
      <tr><td class="b">Balance Due</td><td class="num b"><?= money($d['due_amount']) ?></td></tr>
    </table>
  </div>
  <?php if (in_array($d['dtype'], ['SALE', 'SRET'])): ?><div style="margin-top:10px"><b>Terms &amp; Conditions</b><div class="terms"><?= e($S['invoice_terms'] ?? '') ?></div></div><?php endif; ?>
  <?php else: ?><p><b>Reason:</b> <?= e($d['remarks']) ?></p><?php endif; ?>
  <?php else: /* voucher */ ?>
  <table class="items"><thead><tr><th>Particulars</th><th class="num">Amount</th></tr></thead><tbody>
    <tr><td style="height:60px"><?php
      if ($d['dtype'] === 'RECEIPT') echo 'Received with thanks from <b>' . e($p['name']) . '</b> by ' . e($d['payment_mode']);
      elseif ($d['dtype'] === 'PAYMENT') echo 'Paid to <b>' . e($p['name']) . '</b> by ' . e($d['payment_mode']);
      elseif ($d['dtype'] === 'EXPENSE') echo 'Expense: <b>' . e($d['exp_cat']) . '</b> ' . e($d['description']);
      else echo e($d['entry_type']) . ': ' . e($d['description']);
      echo $d['remarks'] ? '<br><small>' . e($d['remarks']) . '</small>' : ''; ?></td><td class="num b" style="font-size:15px"><?= money($d['grand_total']) ?></td></tr></tbody></table>
  <div class="words" style="margin-top:10px">Amount in words: <b><?= e(amount_in_words((float)$d['grand_total'])) ?></b></div>
  <?php if ($p): ?><p>Balance after this entry: <b><?= money($party_bal) ?></b> <?= $cfg['ptype'] === 'C' ? '(receivable)' : '(payable)' ?></p><?php endif; ?>
  <?php endif; ?>
  <div class="sign"><div><?= in_array($d['dtype'], ['SALE', 'RECEIPT', 'SRET']) ? "Customer's Signature" : 'Receiver\'s Signature' ?></div><div>For <?= e($S['business_name']) ?><br><br>Authorised Signatory</div></div>
  <div class="foot"><?= nl2br(e($S['invoice_footer'] ?? '')) ?><br><small>This is a computer generated document.</small></div>
</div>
<?php endif; ?>
<script src="assets/vendor/html2canvas.min.js"></script>
<script src="assets/vendor/jspdf.umd.min.js"></script>
<script>
async function makePdf() {
  const el = document.getElementById('doc');
  const canvas = await html2canvas(el, { scale: 2, backgroundColor: '#ffffff', useCORS: true });
  const { jsPDF } = window.jspdf;
  const thermal = el.classList.contains('thermal');
  const pw = thermal ? <?= $tw ?> : 210;
  const ph = thermal ? (canvas.height * pw / canvas.width) + 2 : 297;
  const pdf = new jsPDF({ unit: 'mm', format: thermal ? [pw, ph] : 'a4' });
  const imgH = canvas.height * pw / canvas.width;
  const img = canvas.toDataURL('image/jpeg', 0.92);
  let y = 0;
  pdf.addImage(img, 'JPEG', 0, 0, pw, imgH);
  if (!thermal) { let left = imgH - ph; while (left > 1) { y -= ph; pdf.addPage(); pdf.addImage(img, 'JPEG', 0, y, pw, imgH); left -= ph; } }
  pdf.save(<?= json_encode($fileName . '.pdf') ?>);
}
<?php if ($pdf): ?>window.addEventListener('load', () => setTimeout(makePdf, 300));
<?php elseif (!empty($_GET['autoprint']) || (($S['auto_print'] ?? '0') === '1' && empty($_GET['noprint']))): ?>window.addEventListener('load', () => setTimeout(() => window.print(), 300));
<?php endif; ?>
document.addEventListener('keydown', e => { if (e.key === 'Escape') window.close(); });
</script>
</body></html>
