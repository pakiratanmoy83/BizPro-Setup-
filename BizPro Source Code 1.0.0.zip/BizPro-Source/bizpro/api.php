<?php
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/posting.php';
require __DIR__ . '/inc/dashboard_lib.php';

if (!validate_session()) json_out(['ok' => false, 'error' => 'Session expired. Please log in again.'], 401);
$a = (string)($_GET['a'] ?? '');
$body = [];
if (is_post()) {
    $raw = file_get_contents('php://input');
    $body = json_decode($raw ?: '[]', true) ?: $_POST;
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''))) json_out(['ok' => false, 'error' => 'Security token expired. Reload the page.'], 403);
}
$B = fn($k, $d = null) => $body[$k] ?? $d;

try {
    switch ($a) {
        case 'ping':
            json_out(['ok' => true, 'time' => now()]);

        case 'product_search':
            require_perm('product.view', 'stock.view', 'sale.add', 'purchase.add', 'stock.adjust', 'sret.add', 'pret.add', 'report.sales', 'report.purchase', 'report.stock');
            $qv = trim((string)($_GET['q'] ?? ''));
            $like = '%' . $qv . '%';
            $items = rows("SELECT p.id, p.code, p.barcode, p.name, p.hsn_code, p.gst_pct, p.purchase_rate, p.sale_rate, p.mrp, p.current_stock, p.min_stock, c.name category, u.name unit
                FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN units u ON u.id=p.unit_id
                WHERE p.is_deleted=0 AND p.is_active=1 AND (p.barcode=? OR p.code=? OR p.name LIKE ? OR p.code LIKE ?)
                ORDER BY (p.barcode=?) DESC, (p.code=?) DESC, p.name LIMIT 25", [$qv, $qv, $like, $like, $qv, $qv]);
            foreach ($items as &$i) $i['stock_fmt'] = qtyf($i['current_stock']) . ' ' . ($i['unit'] ?? '');
            json_out(['ok' => true, 'items' => $items]);

        case 'product_by_code':
            require_perm('product.view', 'stock.view', 'sale.add', 'purchase.add', 'stock.adjust', 'sret.add', 'pret.add', 'report.sales', 'report.purchase', 'report.stock');
            $c = trim((string)($_GET['code'] ?? ''));
            $p = row("SELECT p.id, p.code, p.barcode, p.name, p.hsn_code, p.gst_pct, p.purchase_rate, p.sale_rate, p.mrp, p.current_stock, p.min_stock, u.name unit
                FROM products p LEFT JOIN units u ON u.id=p.unit_id WHERE p.is_deleted=0 AND p.is_active=1 AND (p.barcode=? OR p.code=?) LIMIT 1", [$c, $c]);
            json_out(['ok' => true, 'item' => $p]);

        case 'party_search':
            $t = ($_GET['t'] ?? 'C') === 'S' ? 'S' : 'C';
            require_perm($t === 'C' ? 'customer.view' : 'supplier.view', $t === 'C' ? 'sale.add' : 'purchase.add', $t === 'C' ? 'receipt.add' : 'payment.add', $t === 'C' ? 'sret.add' : 'pret.add', $t === 'C' ? 'customer.ledger' : 'supplier.ledger', $t === 'C' ? 'report.customer' : 'report.supplier', $t === 'C' ? 'report.sales' : 'report.purchase');
            $qv = trim((string)($_GET['q'] ?? ''));
            $like = '%' . $qv . '%';
            $items = rows("SELECT id, code, name, company_name, mobile, gstin, state, address, credit_limit, is_system FROM parties WHERE ptype=? AND is_deleted=0 AND is_active=1 AND (name LIKE ? OR code LIKE ? OR mobile LIKE ? OR company_name LIKE ? OR gstin LIKE ?) ORDER BY is_system DESC, name LIMIT 25", [$t, $like, $like, $like, $like, $like]);
            foreach ($items as &$i) $i['balance'] = party_balance((int)$i['id']);
            json_out(['ok' => true, 'items' => $items]);

        case 'party_info':
            $id = (int)($_GET['id'] ?? 0);
            $p = row('SELECT id, ptype, code, name, mobile, gstin, state, address, credit_limit, is_system FROM parties WHERE id=?', [$id]);
            if (!$p) throw new AppException('Party not found');
            require_perm($p['ptype'] === 'C' ? 'customer.view' : 'supplier.view', $p['ptype'] === 'C' ? 'sale.add' : 'purchase.add', $p['ptype'] === 'C' ? 'receipt.add' : 'payment.add', $p['ptype'] === 'C' ? 'sret.add' : 'pret.add');
            $p['balance'] = party_balance($id);
            $biz = strtolower(trim(setting('business_state', '')));
            $p['interstate'] = ($biz && $p['state'] && strtolower(trim($p['state'])) !== $biz);
            json_out(['ok' => true, 'party' => $p]);

        case 'party_quick_add':
            $t = $B('ptype') === 'S' ? 'S' : 'C';
            require_perm($t === 'C' ? 'customer.add' : 'supplier.add');
            $name = trim((string)$B('name', ''));
            if ($name === '') throw new AppException('Name is required.');
            $id = tx(function () use ($t, $name, $B) {
                $code = next_number($t === 'C' ? 'CUST' : 'SUPP');
                $id = insert('parties', array_merge(['ptype' => $t, 'code' => $code, 'name' => $name, 'mobile' => trim((string)$B('mobile', '')), 'address' => trim((string)$B('address', '')), 'gstin' => strtoupper(trim((string)$B('gstin', ''))), 'state' => trim((string)$B('state', setting('business_state')))], stamp_create()));
                audit('CREATE', $t === 'C' ? 'customer' : 'supplier', $id, $code, ['name' => $name, 'quick' => true]);
                return $id;
            });
            json_out(['ok' => true, 'id' => $id, 'name' => $name]);

        case 'due_bills':
            $pid = (int)($_GET['id'] ?? 0);
            $pt = val('SELECT ptype FROM parties WHERE id=?', [$pid]);
            require_perm($pt === 'C' ? 'receipt.add' : 'payment.add', $pt === 'C' ? 'customer.ledger' : 'supplier.ledger', $pt === 'C' ? 'sale.view_all' : 'purchase.view_all');
            // FIFO: current balance is matched against the most recent bills
            $remaining = party_balance($pid);
            $items = [];
            foreach (rows('SELECT id, doc_no, doc_date, grand_total FROM documents WHERE party_id=? AND dtype=? AND is_deleted=0 ORDER BY doc_date DESC, id DESC LIMIT 500', [$pid, $pt === 'C' ? 'SALE' : 'PURCHASE']) as $b) {
                if ($remaining <= 0.009) break;
                $b['due_amount'] = r2(min((float)$b['grand_total'], $remaining));
                $remaining = r2($remaining - $b['due_amount']);
                $items[] = $b;
            }
            if ($remaining > 0.009) $items[] = ['id' => 0, 'doc_no' => 'Opening Balance', 'doc_date' => '', 'grand_total' => $remaining, 'due_amount' => $remaining];
            $items = array_reverse($items);
            json_out(['ok' => true, 'items' => $items]);

        case 'dashboard':
            require_perm('dashboard.view');
            json_out(['ok' => true, 'data' => dashboard_data()]);

        case 'doc_items':
            // items of an original invoice for return entry
            $id = (int)($_GET['id'] ?? 0);
            $d = row('SELECT id, dtype, doc_no, doc_date, party_id FROM documents WHERE id=? AND is_deleted=0', [$id]);
            if (!$d || !in_array($d['dtype'], ['SALE', 'PURCHASE'])) throw new AppException('Invoice not found.');
            require_perm($d['dtype'] === 'SALE' ? 'sret.add' : 'pret.add');
            $rt = $d['dtype'] === 'SALE' ? 'SRET' : 'PRET';
            $items = rows('SELECT i.product_id, i.product_name name, i.qty, i.rate, i.disc_pct, i.gst_pct, p.code, p.barcode, p.current_stock, u.name unit FROM document_items i JOIN products p ON p.id=i.product_id LEFT JOIN units u ON u.id=p.unit_id WHERE i.document_id=? ORDER BY i.line_no', [$id]);
            $ret = [];
            foreach (rows('SELECT i.product_id, SUM(i.qty) q FROM document_items i JOIN documents d ON d.id=i.document_id WHERE d.against_doc_id=? AND d.dtype=? AND d.is_deleted=0 GROUP BY i.product_id', [$id, $rt]) as $r) $ret[$r['product_id']] = (float)$r['q'];
            foreach ($items as &$i) { $i['returned'] = $ret[$i['product_id']] ?? 0; $i['returnable'] = max(0, (float)$i['qty'] - $i['returned']); }
            json_out(['ok' => true, 'doc' => $d, 'items' => $items]);

        case 'invoice_search':
            $t = ($_GET['t'] ?? 'SALE') === 'PURCHASE' ? 'PURCHASE' : 'SALE';
            require_perm($t === 'SALE' ? 'sret.add' : 'pret.add');
            $pid = (int)($_GET['party_id'] ?? 0);
            $qv = '%' . trim((string)($_GET['q'] ?? '')) . '%';
            $sql = 'SELECT d.id, d.doc_no, d.ref_invoice_no, d.doc_date, d.grand_total, p.name party FROM documents d JOIN parties p ON p.id=d.party_id WHERE d.dtype=? AND d.is_deleted=0 AND (d.doc_no LIKE ? OR d.ref_invoice_no LIKE ?)';
            $pp = [$t, $qv, $qv];
            if ($pid) { $sql .= ' AND d.party_id=?'; $pp[] = $pid; }
            json_out(['ok' => true, 'items' => rows($sql . ' ORDER BY d.id DESC LIMIT 30', $pp)]);

        case 'save_doc':
            $t = (string)$B('dtype');
            dt($t);
            $id = (int)$B('id', 0) ?: null;
            require_perm(perm_for($t, $id ? 'edit' : 'add'));
            if ($id) {
                $od = row('SELECT * FROM documents WHERE id=?', [$id]);
                if (!$od || !can_edit_doc($od)) throw new AppException('You do not have permission to edit this document.');
                [$cv, $own] = doc_view_scope($t);
                if ($own && $od['created_by'] != current_user()['id']) throw new AppException('You can only edit your own entries.');
            }
            $newId = save_document($t, $body, $id, $id ? (int)$B('row_version', 0) : null);
            if ($hold = (int)$B('from_hold', 0)) q('DELETE FROM held_bills WHERE id=?', [$hold]);
            $d = row('SELECT id, doc_no, grand_total FROM documents WHERE id=?', [$newId]);
            json_out(['ok' => true, 'id' => $newId, 'doc_no' => $d['doc_no'], 'grand_total' => $d['grand_total']]);

        case 'hold_save':
            require_perm('sale.add');
            $payload = $B('payload', []);
            if (empty($payload['items'])) throw new AppException('Nothing to hold - add products first.');
            $u = current_user();
            $pname = !empty($payload['party_id']) ? val('SELECT name FROM parties WHERE id=?', [(int)$payload['party_id']]) : '';
            $id = insert('held_bills', ['label' => mb_substr(trim((string)$B('label', '')) ?: ($pname ?: 'Held bill'), 0, 100), 'party_id' => $payload['party_id'] ?: null, 'payload' => json_encode($payload), 'grand_total' => r2($B('grand_total', 0)), 'user_id' => $u['id'], 'user_name' => $u['username'], 'device_name' => device_name(), 'created_at' => now()]);
            audit('HOLD', 'SALE', $id, null, ['label' => $B('label', ''), 'total' => $B('grand_total', 0)]);
            json_out(['ok' => true, 'id' => $id]);

        case 'hold_list':
            require_perm('sale.add');
            $sql = 'SELECT id, label, grand_total, user_name, device_name, created_at FROM held_bills';
            $p = [];
            if (!can('sale.view_all')) { $sql .= ' WHERE user_id=?'; $p[] = current_user()['id']; }
            json_out(['ok' => true, 'items' => rows($sql . ' ORDER BY id DESC', $p)]);

        case 'hold_get':
            require_perm('sale.add');
            $h = row('SELECT * FROM held_bills WHERE id=?', [(int)($_GET['id'] ?? 0)]);
            if (!$h) throw new AppException('Held bill not found (maybe resumed on another PC).');
            json_out(['ok' => true, 'id' => (int)$h['id'], 'payload' => json_decode($h['payload'], true)]);

        case 'hold_delete':
            require_perm('sale.add');
            q('DELETE FROM held_bills WHERE id=?', [(int)$B('id', 0)]);
            json_out(['ok' => true]);

        case 'next_code':
            require_perm('product.add', 'product.edit');
            $kind = $_GET['kind'] ?? 'code';
            if ($kind === 'barcode') {
                json_out(['ok' => true, 'code' => gen_barcode()]);
            }
            $max = (int)val("SELECT MAX(CAST(SUBSTRING(code, ?) AS UNSIGNED)) FROM products WHERE code REGEXP ?", [strlen(setting('product_code_prefix', 'P')) + 1, '^' . preg_quote(setting('product_code_prefix', 'P')) . '[0-9]+$']);
            json_out(['ok' => true, 'code' => setting('product_code_prefix', 'P') . str_pad((string)($max + 1), 5, '0', STR_PAD_LEFT)]);

        default:
            json_out(['ok' => false, 'error' => 'Unknown action'], 404);
    }
} catch (AppException $e) {
    json_out(['ok' => false, 'error' => $e->getMessage()], 200);
} catch (Throwable $e) {
    error_log($e->__toString());
    $msg = $e->getMessage();
    if ($e instanceof PDOException && ($e->errorInfo[1] ?? 0) == 1062) $msg = 'Duplicate value - this number/code already exists.';
    json_out(['ok' => false, 'error' => 'Server error: ' . $msg], 200);
}
