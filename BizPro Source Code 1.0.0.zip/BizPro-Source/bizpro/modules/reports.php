<?php
$title = 'Reports';
$groups = [];
foreach (report_registry() as $k => $r) if (can($r[2])) $groups[$r[0]][$k] = $r;
if (!$groups) throw new AppException('You do not have permission to view any report.');
$icons = ['Sales' => 'green', 'Purchase' => 'blue', 'Stock' => 'amber', 'Customer' => 'green', 'Supplier' => 'blue', 'Financial' => 'red', 'User' => ''];
?>
<div class="grid grid-3">
<?php foreach ($groups as $g => $list): ?>
  <div class="card"><h3><span class="badge <?= $icons[$g] ?? '' ?>"><?= e($g) ?></span> Reports</h3>
    <ul class="report-list">
      <?php foreach ($list as $k => $r): ?><li><a href="<?= e($r[6] ?? url('report', ['r' => $k])) ?>"><?= e($r[1]) ?></a></li><?php endforeach; ?>
    </ul></div>
<?php endforeach; ?>
</div>
<div class="card muted small">All reports support filters (date, user, customer/supplier, product, category, search where applicable) and can be printed or exported to PDF and Excel.</div>
