<?php
$title = 'Categories, Brands, Units & Expense Heads';
$types = [
    'categories' => ['Product Categories', 'products', 'category_id'],
    'brands' => ['Brands', 'products', 'brand_id'],
    'units' => ['Units', 'products', 'unit_id'],
    'expense_categories' => ['Expense Categories', 'documents', 'expense_category_id'],
];
if (is_post()) {
    $t = (string)in('type');
    if (!isset($types[$t])) throw new AppException('Invalid master type');
    $name = trim((string)in('name'));
    $id = ini('id');
    $act = in('action');
    if ($act === 'delete') {
        [$lbl, $ut, $uc] = $types[$t];
        $used = (int)val("SELECT COUNT(*) FROM `$ut` WHERE `$uc`=? AND is_deleted=0", [$id]);
        if ($used) throw new AppException("Cannot delete: used in $used record(s).");
        $old = val("SELECT name FROM `$t` WHERE id=?", [$id]);
        update($t, ['is_deleted' => 1, 'name' => $old . '~' . $id], 'id=?', [$id]);
        audit('DELETE', $t, $id, null, ['name' => $old]);
        flash('success', 'Deleted.');
    } else {
        if ($name === '') throw new AppException('Name is required.');
        if (val("SELECT id FROM `$t` WHERE name=? AND id<>?", [$name, $id])) throw new AppException('"' . $name . '" already exists.');
        if ($id) { $old = val("SELECT name FROM `$t` WHERE id=?", [$id]); update($t, ['name' => $name], 'id=?', [$id]); audit('EDIT', $t, $id, null, ['from' => $old, 'to' => $name]); }
        else { $nid = insert($t, ['name' => $name]); audit('CREATE', $t, $nid, null, ['name' => $name]); }
        flash('success', 'Saved "' . $name . '".');
    }
    redirect(url('masters', ['tab' => $t]));
}
$tab = $_GET['tab'] ?? 'categories';
if (!isset($types[$tab])) $tab = 'categories';
[$lbl, $ut, $uc] = $types[$tab];
$list = rows("SELECT m.id, m.name, (SELECT COUNT(*) FROM `$ut` x WHERE x.`$uc`=m.id AND x.is_deleted=0) used FROM `$tab` m WHERE m.is_deleted=0 ORDER BY m.name");
?>
<div class="card">
  <div class="tabs"><?php foreach ($types as $k => $v): ?><a class="<?= $k === $tab ? 'active' : '' ?>" href="<?= e(url('masters', ['tab' => $k])) ?>"><?= e($v[0]) ?></a><?php endforeach; ?></div>
  <form method="post" class="filters"><?= csrf_field() ?><input type="hidden" name="type" value="<?= e($tab) ?>">
    <div class="fg grow"><label>New <?= e(rtrim($lbl, 's')) ?> name</label><input name="name" required autofocus></div><button class="btn btn-primary">+ Add</button></form>
  <div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th class="num">Used in</th><th class="actions">Actions</th></tr></thead><tbody>
  <?php foreach ($list as $m): ?>
    <tr><td><?= e($m['name']) ?></td><td class="num"><?= (int)$m['used'] ?></td><td class="actions">
      <button class="btn btn-sm" onclick="ren(<?= (int)$m['id'] ?>, <?= e(json_encode($m['name'])) ?>)">Rename</button>
      <?php if (!$m['used']): ?><form method="post" style="display:inline" data-confirm="Delete '<?= e($m['name']) ?>'?" data-danger="1"><?= csrf_field() ?><input type="hidden" name="type" value="<?= e($tab) ?>"><input type="hidden" name="id" value="<?= (int)$m['id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn btn-sm btn-danger">Delete</button></form><?php endif; ?>
    </td></tr>
  <?php endforeach; ?>
  </tbody></table></div>
</div>
<form method="post" id="renForm" style="display:none"><?= csrf_field() ?><input type="hidden" name="type" value="<?= e($tab) ?>"><input type="hidden" name="id"><input type="hidden" name="name"></form>
<script>
async function ren(id, name){
  const v = await BP.confirm('Rename "' + name + '"', {title:'Rename', input:'New name', ok:'Save'});
  if (!v || !v.trim()) return;
  const f = document.getElementById('renForm'); f.elements['id'].value = id; f.elements['name'].value = v.trim(); f.submit();
}
</script>
