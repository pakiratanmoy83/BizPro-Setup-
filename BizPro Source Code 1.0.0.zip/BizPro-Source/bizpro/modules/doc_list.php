<?php
$t = strtoupper((string)($_GET['t'] ?? 'SALE'));
$cfg = dt($t);
[$canView, $own] = doc_view_scope($t);
$canAdd = can(perm_for($t, 'add'));
if (!$canView && !$canAdd) throw new AppException('Access denied.');
$titles = ['SALE' => 'Sales Invoices', 'PURCHASE' => 'Purchase Invoices', 'SRET' => 'Sales Returns', 'PRET' => 'Purchase Returns', 'RECEIPT' => 'Customer Receipts', 'PAYMENT' => 'Supplier Payments', 'EXPENSE' => 'Expenses', 'ADJ' => 'Stock Adjustments', 'CASH' => 'Cash / Bank Entries'];
$title = $titles[$t];

// Delete action
if (is_post() && in('action') === 'delete') {
    $d = row('SELECT * FROM documents WHERE id=?', [ini('id')]);
    if (!$d || $d['dtype'] !== $t) throw new AppException('Document not found.');
    if (!can_delete_doc($d)) throw new AppException('You do not have permission to delete this ' . $cfg['label'] . '.');
    delete_document((int)$d['id'], trim((string)in('reason')));
    flash('success', $cfg['label'] . ' ' . $d['doc_no'] . ' deleted (moved to Recycle Bin).');
    redirect(url('doc_list', ['t' => $t]));
}

$from = ind('from', date('Y-m-01')); $to = ind('to');
$qv = trim((string)($_GET['q'] ?? ''));
$party = (int)($_GET['party'] ?? 0);
$user = (int)($_GET['user'] ?? 0);
$status = $_GET['status'] ?? '';
$w = ['d.dtype=?', 'd.is_deleted=0', 'd.doc_date BETWEEN ? AND ?']; $pp = [$t, $from, $to];
if ($own || !$canView) { $w[] = 'd.created_by=?'; $pp[] = current_user()['id']; }
if ($qv !== '') { $w[] = '(d.doc_no LIKE ? OR d.ref_invoice_no LIKE ? OR d.reference_no LIKE ? OR d.remarks LIKE ? OR d.description LIKE ? OR pa.name LIKE ? OR pa.mobile LIKE ?)'; array_push($pp, "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%"); }
if ($party) { $w[] = 'd.party_id=?'; $pp[] = $party; }
if ($user && !$own) { $w[] = 'd.created_by=?'; $pp[] = $user; }
if ($status === 'due') $w[] = 'd.due_amount>0.009';
if ($status === 'paid') $w[] = 'd.due_amount<=0.009';
if ($t === 'EXPENSE' && ($ec = (int)($_GET['cat'] ?? 0))) { $w[] = 'd.expense_category_id=?'; $pp[] = $ec; }
$sql = "SELECT d.*, pa.name party, pa.mobile, a.name account, a2.name to_account, ec.name exp_cat, (SELECT COUNT(*) FROM document_items i WHERE i.document_id=d.id) n_items
    FROM documents d LEFT JOIN parties pa ON pa.id=d.party_id LEFT JOIN accounts a ON a.id=d.account_id LEFT JOIN accounts a2 ON a2.id=d.to_account_id LEFT JOIN expense_categories ec ON ec.id=d.expense_category_id
    WHERE " . implode(' AND ', $w) . ' ORDER BY d.doc_date DESC, d.id DESC';
[$list, $pager] = paginate($sql, $pp, 50);
$tot = row("SELECT COUNT(*) n, COALESCE(SUM(grand_total),0) gt, COALESCE(SUM(paid_amount),0) pd, COALESCE(SUM(due_amount),0) du FROM ($sql) z", $pp);
$users = rows('SELECT id, username name FROM users WHERE is_deleted=0 ORDER BY username');
$ptype = $cfg['ptype'];
$parties = $ptype ? rows('SELECT id, name FROM parties WHERE ptype=? AND is_deleted=0 ORDER BY name', [$ptype]) : [];
$hasItems = $cfg['items'] && $t !== 'ADJ';
$formPage = doc_form_page($t);
?>
<div class="card">
  <div class="card-head"><h3><?= e($title) ?></h3>
    <div class="btn-row">
      <?php if ($canAdd): ?><a class="btn btn-primary" href="<?= e(url($formPage, ['t' => $t])) ?>">+ New <?= e($cfg['label']) ?></a><?php endif; ?>
      <button class="btn" data-export="excel" data-table="#dTable" data-file="<?= strtolower($t) ?>_<?= $from ?>_<?= $to ?>" data-title="<?= e($title) ?>">Excel</button>
      <button class="btn" data-export="pdf" data-table="#dTable" data-file="<?= strtolower($t) ?>_<?= $from ?>_<?= $to ?>" data-title="<?= e($title) ?>" data-sub="<?= dmy($from) ?> to <?= dmy($to) ?>">PDF</button>
      <button class="btn" onclick="window.print()">Print</button>
    </div></div>
  <form class="filters" method="get"><input type="hidden" name="p" value="doc_list"><input type="hidden" name="t" value="<?= e($t) ?>">
    <div class="fg"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
    <div class="fg"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
    <?php if ($ptype): ?><div class="fg"><label><?= $ptype === 'C' ? 'Customer' : 'Supplier' ?></label><select name="party"><?= options($parties, $party, 'id', 'name', 'All') ?></select></div><?php endif; ?>
    <?php if ($t === 'EXPENSE'): ?><div class="fg"><label>Category</label><select name="cat"><?= options(rows('SELECT id, name FROM expense_categories WHERE is_deleted=0 ORDER BY name'), $_GET['cat'] ?? '', 'id', 'name', 'All') ?></select></div><?php endif; ?>
    <?php if (!$own): ?><div class="fg"><label>User</label><select name="user"><?= options($users, $user, 'id', 'name', 'All users') ?></select></div><?php endif; ?>
    <?php if ($hasItems): ?><div class="fg"><label>Status</label><select name="status"><option value="">All</option><option value="due" <?= $status === 'due' ? 'selected' : '' ?>>Due</option><option value="paid" <?= $status === 'paid' ? 'selected' : '' ?>>Paid</option></select></div><?php endif; ?>
    <div class="fg grow"><label>Search</label><input name="q" value="<?= e($qv) ?>" placeholder="No., party, mobile, reference..."></div>
    <button class="btn btn-primary">Filter</button>
  </form>
  <?php if ($own): ?><div class="alert alert-info small">Showing only entries created by you.</div><?php endif; ?>
  <div class="table-wrap"><table class="table" id="dTable">
    <thead><tr><th>Date</th><th>No.</th>
      <?php if ($t === 'PURCHASE' || $t === 'PRET'): ?><th>Supplier Bill / Ref</th><?php endif; ?>
      <?php if ($ptype): ?><th><?= $ptype === 'C' ? 'Customer' : 'Supplier' ?></th><?php endif; ?>
      <?php if ($t === 'EXPENSE'): ?><th>Category</th><th>Description</th><?php endif; ?>
      <?php if ($t === 'CASH'): ?><th>Type</th><th>Description</th><?php endif; ?>
      <?php if ($t === 'ADJ'): ?><th>Reason</th><th class="num">Items</th><?php endif; ?>
      <?php if (!$cfg['items'] || $hasItems): ?><th>Mode</th><th>Account</th><?php endif; ?>
      <th>User</th><th>Computer</th>
      <?php if ($hasItems): ?><th class="num">Grand Total</th><th class="num">Paid</th><th class="num">Due</th><?php elseif ($t !== 'ADJ'): ?><th class="num">Amount</th><?php endif; ?>
      <th class="no-export"></th></tr></thead><tbody>
    <?php foreach ($list as $d): ?>
      <tr><td class="nowrap"><?= dmy($d['doc_date']) ?></td><td><a href="<?= e(url('doc_view', ['id' => $d['id']])) ?>"><?= e($d['doc_no']) ?></a></td>
      <?php if ($t === 'PURCHASE' || $t === 'PRET'): ?><td><?= e($d['ref_invoice_no']) ?></td><?php endif; ?>
      <?php if ($ptype): ?><td><?= e($d['party']) ?></td><?php endif; ?>
      <?php if ($t === 'EXPENSE'): ?><td><?= e($d['exp_cat']) ?></td><td><?= e($d['description']) ?></td><?php endif; ?>
      <?php if ($t === 'CASH'): ?><td><span class="badge <?= $d['entry_type'] === 'IN' ? 'green' : ($d['entry_type'] === 'OUT' ? 'red' : 'blue') ?>"><?= e($d['entry_type']) ?></span></td><td><?= e($d['description']) ?><?= $d['to_account'] ? ' &rarr; ' . e($d['to_account']) : '' ?></td><?php endif; ?>
      <?php if ($t === 'ADJ'): ?><td><?= e($d['remarks']) ?></td><td class="num"><?= (int)$d['n_items'] ?></td><?php endif; ?>
      <?php if (!$cfg['items'] || $hasItems): ?><td><?= e($d['payment_mode']) ?></td><td><?= e($d['account']) ?></td><?php endif; ?>
      <td><?= e($d['created_by_name']) ?><?= $d['modified_by_name'] ? ' <span class="badge" title="Modified by ' . e($d['modified_by_name']) . ' ' . e(dmyhm($d['modified_at'])) . '">edited</span>' : '' ?></td><td class="small muted"><?= e($d['device_name']) ?></td>
      <?php if ($hasItems): ?><td class="num"><?= money($d['grand_total']) ?></td><td class="num"><?= money($d['paid_amount']) ?></td><td class="num <?= $d['due_amount'] > 0 ? 'text-danger' : '' ?>"><?= money($d['due_amount']) ?></td>
      <?php elseif ($t !== 'ADJ'): ?><td class="num"><?= money($d['grand_total']) ?></td><?php endif; ?>
      <td class="actions no-export">
        <a class="btn btn-sm" href="<?= e(url('doc_view', ['id' => $d['id']])) ?>">View</a>
        <?php if ($t !== 'ADJ'): ?><a class="btn btn-sm" target="_blank" href="print.php?id=<?= (int)$d['id'] ?>">Print</a><?php endif; ?>
        <?php if (can_edit_doc($d)): ?><a class="btn btn-sm" href="<?= e(url($formPage, ['t' => $t, 'id' => $d['id']])) ?>">Edit</a><?php endif; ?>
        <?php if (can_delete_doc($d)): ?><form method="post" style="display:inline" data-confirm="Delete <?= e($cfg['label'] . ' ' . $d['doc_no']) ?>? Stock and balances will be reversed. The record goes to the Recycle Bin." data-danger="1" data-reason="1" data-ok="Delete"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><button class="btn btn-sm btn-danger">Delete</button></form><?php endif; ?>
      </td></tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="14" class="empty">No records for the selected filters.</td></tr><?php endif; ?>
    </tbody>
  </table></div>
  <div class="btn-row" style="margin-top:10px;justify-content:space-between"><div><b><?= (int)$tot['n'] ?></b> entries &middot; Total <b><?= money($tot['gt']) ?></b><?php if ($hasItems): ?> &middot; Paid <b><?= money($tot['pd']) ?></b> &middot; Due <b class="text-danger"><?= money($tot['du']) ?></b><?php endif; ?></div><?= $pager ?></div>
</div>
