<?php
$title = 'Stock Ledger & Movement';
[$fyS] = fy_range();
$pid = (int)($_GET['product'] ?? 0);
$from = ind('from', $pid ? $fyS : date('Y-m-01')); $to = ind('to');
$type = $_GET['type'] ?? '';
$user = (int)($_GET['user'] ?? 0);
$prod = $pid ? row('SELECT p.*, u.name unit FROM products p LEFT JOIN units u ON u.id=p.unit_id WHERE p.id=?', [$pid]) : null;
$types = ['OPENING' => 'Opening', 'PURCHASE' => 'Purchase', 'SALE' => 'Sale', 'SRET' => 'Sales Return', 'PRET' => 'Purchase Return', 'ADJ' => 'Adjustment'];
$w = ['s.txn_date BETWEEN ? AND ?']; $pp = [$from, $to];
if ($pid) { $w[] = 's.product_id=?'; $pp[] = $pid; }
if ($type && isset($types[$type])) { $w[] = 's.txn_type=?'; $pp[] = $type; }
if ($user) { $w[] = 's.user_id=?'; $pp[] = $user; }
$rowsL = rows('SELECT s.*, p.name pname, p.code FROM stock_transactions s JOIN products p ON p.id=s.product_id WHERE ' . implode(' AND ', $w) . ' ORDER BY s.txn_date, s.id LIMIT 5000', $pp);
$open = 0;
if ($prod) $open = (float)val('SELECT COALESCE(SUM(qty_in-qty_out),0) FROM stock_transactions WHERE product_id=? AND txn_date<?', [$pid, $from]);
$summary = rows('SELECT txn_type, SUM(qty_in) i, SUM(qty_out) o FROM stock_transactions s WHERE ' . implode(' AND ', $w) . ' GROUP BY txn_type', $pp);
?>
<div class="card">
  <div class="card-head"><h3><?= $prod ? 'Stock Ledger: ' . e($prod['name']) . ' <span class="muted small">' . e($prod['code']) . '</span>' : 'Date-wise Stock Movement' ?></h3>
    <div class="btn-row"><a class="btn" href="<?= e(url('stock')) ?>" data-cancel>Back to Stock</a>
      <button class="btn" data-export="excel" data-table="#slTable" data-file="stock_ledger" data-title="Stock Ledger">Excel</button>
      <button class="btn" data-export="pdf" data-table="#slTable" data-file="stock_ledger" data-title="<?= e($prod ? 'Stock Ledger - ' . $prod['name'] : 'Stock Movement') ?>" data-sub="<?= dmy($from) ?> to <?= dmy($to) ?>">PDF</button>
      <button class="btn" onclick="window.print()">Print</button></div></div>
  <form class="filters" method="get" id="slf"><input type="hidden" name="p" value="stock_ledger"><input type="hidden" name="product" id="slProd" value="<?= $pid ?: '' ?>">
    <div class="fg grow"><label>Product (blank = all products)</label><input id="slProdName" value="<?= e($prod['name'] ?? '') ?>" placeholder="Search product..." autocomplete="off"></div>
    <div class="fg"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div><div class="fg"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
    <div class="fg"><label>Type</label><select name="type"><option value="">All</option><?php foreach ($types as $k => $v) echo '<option value="' . $k . '"' . ($type === $k ? ' selected' : '') . '>' . $v . '</option>'; ?></select></div>
    <div class="fg"><label>User</label><select name="user"><?= options(rows('SELECT id, username name FROM users ORDER BY username'), $user, 'id', 'name', 'All') ?></select></div>
    <button class="btn btn-primary">Show</button></form>
  <div class="btn-row" style="margin-bottom:10px"><?php foreach ($summary as $s): ?><span class="badge"><?= e($types[$s['txn_type']] ?? $s['txn_type']) ?>: +<?= qtyf($s['i']) ?> / -<?= qtyf($s['o']) ?></span><?php endforeach; ?></div>
  <div class="table-wrap"><table class="table" id="slTable"><thead><tr><th>Date</th><?= $prod ? '' : '<th>Product</th>' ?><th>Type</th><th>Doc No</th><th>Particulars</th><th>User</th><th>Computer</th><th class="num">In</th><th class="num">Out</th><?= $prod ? '<th class="num">Balance</th>' : '' ?><th class="num">Rate</th></tr></thead><tbody>
    <?php if ($prod): ?><tr class="bold"><td><?= dmy($from) ?></td><td colspan="6">Opening balance</td><td></td><td></td><td class="num"><?= qtyf($open) ?></td><td></td></tr><?php endif; ?>
    <?php $bal = $open; $ti = $to_ = 0; foreach ($rowsL as $r): $bal += $r['qty_in'] - $r['qty_out']; $ti += $r['qty_in']; $to_ += $r['qty_out']; ?>
      <tr><td class="nowrap"><?= dmy($r['txn_date']) ?></td><?= $prod ? '' : '<td><a href="' . e(url('stock_ledger', ['product' => $r['product_id'], 'from' => $from, 'to' => $to])) . '">' . e($r['pname']) . '</a></td>' ?>
      <td><span class="badge <?= $r['qty_in'] > 0 ? 'green' : 'red' ?>"><?= e($types[$r['txn_type']] ?? $r['txn_type']) ?></span></td>
      <td><?= $r['document_id'] ? '<a href="' . e(url('doc_view', ['id' => $r['document_id']])) . '">' . e($r['doc_no']) . '</a>' : '' ?></td><td><?= e($r['narration']) ?></td><td><?= e($r['user_name']) ?></td><td class="small muted"><?= e($r['device_name']) ?></td>
      <td class="num"><?= $r['qty_in'] > 0 ? qtyf($r['qty_in']) : '' ?></td><td class="num"><?= $r['qty_out'] > 0 ? qtyf($r['qty_out']) : '' ?></td><?= $prod ? '<td class="num bold">' . qtyf($bal) . '</td>' : '' ?><td class="num"><?= money($r['rate']) ?></td></tr>
    <?php endforeach; if (!$rowsL) echo '<tr><td colspan="11" class="empty">No stock movement in this period.</td></tr>'; ?>
  </tbody><tfoot><tr><td colspan="<?= $prod ? 6 : 7 ?>">Total</td><td class="num"><?= qtyf($ti) ?></td><td class="num"><?= qtyf($to_) ?></td><?= $prod ? '<td class="num">' . qtyf($bal) . '</td>' : '' ?><td></td></tr></tfoot></table></div>
  <?php if ($prod && abs($bal - (float)$prod['current_stock']) > 0.001 && $to >= today()): ?><div class="alert alert-warning">Note: closing balance differs from current stock (<?= qtyf($prod['current_stock']) ?>) because of entries dated after <?= dmy($to) ?>.</div><?php endif; ?>
</div>
<script>
BP.autocomplete(document.getElementById('slProdName'), { source: BP.productSource, render: BP.productRender, onSelect: p => { document.getElementById('slProd').value = p.id; document.getElementById('slProdName').value = p.name; document.getElementById('slf').submit(); } });
document.getElementById('slProdName').addEventListener('input', e => { if (!e.target.value.trim()) document.getElementById('slProd').value = ''; });
</script>
