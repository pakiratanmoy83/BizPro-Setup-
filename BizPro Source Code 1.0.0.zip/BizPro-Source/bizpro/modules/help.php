<?php
$title = 'Help & Keyboard Shortcuts';
$keys = [
    ['F1', 'Open this Help page'], ['F2', 'Search product (on bills: jump to the product / barcode box)'], ['F3', 'Search customer'], ['F4', 'Search supplier'],
    ['F5', 'New Sale / Billing'], ['F6', 'New Purchase'], ['F7', 'Customer Receipt'], ['F8', 'Supplier Payment'],
    ['Ctrl + S', 'Save the current form / bill'], ['Ctrl + P', 'Print (on bills: save and print)'], ['Esc', 'Close dialog / cancel and go back'],
    ['Enter (in barcode box)', 'Add scanned product to the bill'], ['5*CODE + Enter', 'Add product with quantity 5 (quick quantity)'],
];
?>
<div class="grid grid-2">
  <div class="card"><h3>Keyboard Shortcuts</h3><table class="table"><tbody>
    <?php foreach ($keys as [$k, $d]): ?><tr><td style="width:190px"><?php foreach (explode(' + ', $k) as $i => $p) echo ($i ? ' + ' : '') . '<span class="kbd">' . e($p) . '</span>'; ?></td><td><?= e($d) ?></td></tr><?php endforeach; ?>
  </tbody></table></div>
  <div class="card"><h3>Quick Start</h3><ol style="line-height:1.8;padding-left:18px">
    <li><b>Settings</b>: enter business name, address, GSTIN, state, logo and invoice terms.</li>
    <li><b>Masters</b>: create categories, brands, units and expense heads.</li>
    <li><b>Products</b>: add products with rates, GST %, HSN and opening stock. Barcode and code are generated automatically if left blank.</li>
    <li><b>Customers / Suppliers</b>: add parties with opening balance (receivable / payable).</li>
    <li><b>Purchase</b> (F6): enter supplier bills - stock increases and supplier payable is updated.</li>
    <li><b>Sales</b> (F5): scan barcodes or search products, set discount and payment; print A4 or thermal invoice.</li>
    <li><b>Receipts</b> (F7) / <b>Payments</b> (F8): settle customer and supplier balances.</li>
    <li><b>Reports</b>: every report has filters and Print / PDF / Excel export.</li>
    <li><b>Users</b>: Admin creates users, assigns a role and optionally allows / denies individual permissions.</li>
  </ol></div>
</div>
<div class="grid grid-2">
  <div class="card"><h3>How transactions affect your books</h3><table class="table"><thead><tr><th>Entry</th><th>Stock</th><th>Party balance</th><th>Cash / Bank</th></tr></thead><tbody>
    <tr><td>Purchase</td><td>Increases</td><td>Supplier payable increases (less amount paid)</td><td>Paid amount goes out</td></tr>
    <tr><td>Sale</td><td>Decreases</td><td>Customer receivable increases (less amount received)</td><td>Received amount comes in</td></tr>
    <tr><td>Customer Receipt</td><td>-</td><td>Receivable decreases</td><td>Comes in</td></tr>
    <tr><td>Supplier Payment</td><td>-</td><td>Payable decreases</td><td>Goes out</td></tr>
    <tr><td>Sales Return</td><td>Increases</td><td>Receivable decreases (or refund)</td><td>Refund goes out</td></tr>
    <tr><td>Purchase Return</td><td>Decreases</td><td>Payable decreases (or refund)</td><td>Refund comes in</td></tr>
    <tr><td>Expense</td><td>-</td><td>-</td><td>Goes out</td></tr>
    <tr><td>Stock Adjustment</td><td>+ / -</td><td>-</td><td>-</td></tr>
  </tbody></table></div>
  <div class="card"><h3>Network (LAN) Use</h3>
    <p>The database runs only on the <b>server PC</b>. Other computers open the software through the <b>BizPro Client</b> shortcut, which connects to the server address shown below. Keep the server PC switched on while others are working.</p>
    <?php $hn = gethostname() ?: ''; $ips = array_values(array_filter((array)@gethostbynamel($hn), fn($ip) => strpos($ip, '127.') !== 0)); $port = (int)($_SERVER['SERVER_PORT'] ?? 80); ?>
    <p>Server PC name: <b><?= e($hn) ?></b> &nbsp; Port: <b><?= $port ?></b><br>Server LAN address(es): <b><?= e($ips ? implode(', ', $ips) : ($_SERVER['SERVER_ADDR'] ?? '')) ?></b><br>
    Clients enter this name or IP when installing the BizPro Client, or open <code>http://<?= e($ips[0] ?? $hn) ?>:<?= $port ?>/</code> in a browser.</p>
    <p>Every entry records the user, date &amp; time and computer name. Two users can bill at the same time: stock and numbers are locked safely inside database transactions, and if two people edit the same record, the second save is rejected with a message to reload.</p>
    <p>Backups: automatic (scheduled) and manual backups are available in <b>Backup &amp; Restore</b> (Admin).</p>
    <p class="muted small"><?= APP_NAME ?> version <?= APP_VERSION ?></p></div>
</div>
