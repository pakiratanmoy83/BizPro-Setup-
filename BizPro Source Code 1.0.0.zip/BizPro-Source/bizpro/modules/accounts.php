<?php
$title = 'Cash & Bank';
if (is_post()) {
    require_perm('account.manage');
    $id = ini('id');
    if (in('action') === 'delete') {
        if (val('SELECT COUNT(*) FROM account_transactions WHERE account_id=?', [$id]) || val('SELECT COUNT(*) FROM documents WHERE account_id=? OR to_account_id=?', [$id, $id])) throw new AppException('Account has transactions and cannot be deleted. Mark it inactive instead.');
        $old = row('SELECT * FROM accounts WHERE id=?', [$id]);
        update('accounts', ['is_deleted' => 1, 'is_active' => 0, 'name' => $old['name'] . '~' . $id], 'id=?', [$id]);
        audit('DELETE', 'account', $id, null, ['name' => $old['name']]);
        flash('success', 'Account deleted.');
        redirect(url('accounts'));
    }
    $data = ['name' => trim((string)in('name')), 'atype' => in_array(in('atype'), ['CASH', 'BANK', 'UPI', 'OTHER']) ? in('atype') : 'OTHER', 'account_no' => trim((string)in('account_no')) ?: null, 'opening_balance' => r2(inf('opening_balance')), 'is_active' => in('is_active') ? 1 : 0];
    if ($data['name'] === '') throw new AppException('Account name is required.');
    if (val('SELECT id FROM accounts WHERE name=? AND id<>?', [$data['name'], $id])) throw new AppException('Account name already exists.');
    if ($id) { $old = row('SELECT * FROM accounts WHERE id=?', [$id]); update('accounts', $data, 'id=?', [$id]); audit('EDIT', 'account', $id, null, ['before' => $old, 'after' => $data]); }
    else { $id = insert('accounts', $data); audit('CREATE', 'account', $id, null, $data); }
    flash('success', 'Account saved.');
    redirect(url('accounts'));
}
$accs = rows('SELECT * FROM accounts WHERE is_deleted=0 ORDER BY id');
$today = today();
$totals = ['CASH' => 0, 'BANK' => 0, 'UPI' => 0, 'OTHER' => 0];
foreach ($accs as &$a) {
    $a['balance'] = account_balance((int)$a['id']);
    $t = row('SELECT COALESCE(SUM(amount_in),0) i, COALESCE(SUM(amount_out),0) o FROM account_transactions WHERE account_id=? AND txn_date=?', [$a['id'], $today]);
    $a['today_in'] = $t['i']; $a['today_out'] = $t['o'];
    $totals[$a['atype']] += $a['balance'];
}
unset($a);
$edit = !empty($_GET['edit']) ? row('SELECT * FROM accounts WHERE id=?', [(int)$_GET['edit']]) : null;
?>
<div class="grid grid-4">
  <div class="stat green"><div class="label">Cash</div><div class="value"><?= money($totals['CASH']) ?></div></div>
  <div class="stat blue"><div class="label">Bank</div><div class="value"><?= money($totals['BANK']) ?></div></div>
  <div class="stat"><div class="label">UPI</div><div class="value"><?= money($totals['UPI']) ?></div></div>
  <div class="stat"><div class="label">Other</div><div class="value"><?= money($totals['OTHER']) ?></div><div class="sub">Total: <?= money(array_sum($totals)) ?></div></div>
</div>
<div class="card">
  <div class="card-head"><h3>Accounts &amp; Closing Balances</h3><div class="btn-row">
    <?php if (can('cash.entry')): ?>
      <a class="btn btn-success" href="<?= e(url('voucher_form', ['t' => 'CASH', 'type' => 'IN'])) ?>">+ Cash In</a>
      <a class="btn btn-danger" href="<?= e(url('voucher_form', ['t' => 'CASH', 'type' => 'OUT'])) ?>">- Cash Out</a>
      <a class="btn" href="<?= e(url('voucher_form', ['t' => 'CASH', 'type' => 'TRANSFER'])) ?>">Transfer</a>
    <?php endif; ?>
    <a class="btn" href="<?= e(url('doc_list', ['t' => 'CASH'])) ?>">Cash/Bank Entries</a>
    <a class="btn" href="<?= e(url('book')) ?>">Cash / Bank Book</a></div></div>
  <div class="table-wrap"><table class="table" id="accTable"><thead><tr><th>Account</th><th>Type</th><th>Account No.</th><th class="num">Opening</th><th class="num">Today In</th><th class="num">Today Out</th><th class="num">Closing Balance</th><th class="no-export"></th></tr></thead><tbody>
  <?php foreach ($accs as $a): ?>
    <tr><td><a href="<?= e(url('book', ['acc' => $a['id']])) ?>"><?= e($a['name']) ?></a> <?= $a['is_active'] ? '' : '<span class="badge">Inactive</span>' ?></td><td><?= e($a['atype']) ?></td><td><?= e($a['account_no']) ?></td><td class="num"><?= money($a['opening_balance']) ?></td>
    <td class="num text-success"><?= money($a['today_in']) ?></td><td class="num text-danger"><?= money($a['today_out']) ?></td><td class="num bold <?= $a['balance'] < 0 ? 'text-danger' : '' ?>"><?= money($a['balance']) ?></td>
    <td class="actions no-export"><a class="btn btn-sm" href="<?= e(url('book', ['acc' => $a['id']])) ?>">Book</a><?php if (can('account.manage')): ?> <a class="btn btn-sm" href="<?= e(url('accounts', ['edit' => $a['id']])) ?>">Edit</a><?php endif; ?></td></tr>
  <?php endforeach; ?></tbody></table></div>
</div>
<?php if (can('account.manage')): ?>
<form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
  <h3><?= $edit ? 'Edit Account' : 'Add Account' ?></h3>
  <div class="form-grid cols-4">
    <div class="fg"><label class="req">Name</label><input name="name" required value="<?= e($edit['name'] ?? '') ?>" placeholder="e.g. SBI Current A/c"></div>
    <div class="fg"><label>Type</label><select name="atype"><?php foreach (['CASH', 'BANK', 'UPI', 'OTHER'] as $t) echo '<option' . (($edit['atype'] ?? 'BANK') === $t ? ' selected' : '') . '>' . $t . '</option>'; ?></select></div>
    <div class="fg"><label>Account No. / UPI ID</label><input name="account_no" value="<?= e($edit['account_no'] ?? '') ?>"></div>
    <div class="fg"><label>Opening Balance</label><input type="number" step="0.01" name="opening_balance" value="<?= e($edit['opening_balance'] ?? 0) ?>"></div>
    <div class="fg"><label class="check"><input type="checkbox" name="is_active" value="1" <?= ($edit['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label></div>
  </div>
  <div class="btn-row"><button class="btn btn-primary">Save Account</button><?php if ($edit): ?><a class="btn" href="<?= e(url('accounts')) ?>">Cancel</a><?php endif; ?></div>
</form>
<?php if ($edit): ?><form method="post" class="card" data-confirm="Delete account <?= e($edit['name']) ?>?" data-danger="1"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$edit['id'] ?>"><input type="hidden" name="action" value="delete"><button class="btn btn-danger">Delete Account</button></form><?php endif; ?>
<?php endif; ?>
