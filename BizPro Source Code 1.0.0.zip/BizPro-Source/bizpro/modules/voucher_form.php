<?php
$t = strtoupper((string)($_GET['t'] ?? 'RECEIPT'));
if (!in_array($t, ['RECEIPT', 'PAYMENT', 'EXPENSE', 'CASH'])) throw new AppException('Invalid form');
$cfg = dt($t);
$id = (int)($_GET['id'] ?? 0);
$doc = null;
if ($id) {
    $doc = row('SELECT * FROM documents WHERE id=? AND dtype=? AND is_deleted=0', [$id, $t]);
    if (!$doc) throw new AppException('Entry not found.');
    if (!can_edit_doc($doc)) throw new AppException('You do not have permission to edit this entry.');
    [$cv, $own] = doc_view_scope($t);
    if ($own && $doc['created_by'] != current_user()['id']) throw new AppException('You can only edit your own entries.');
} else require_perm(perm_for($t, 'add'));

if (is_post()) {
    $in = [
        'doc_date' => in('doc_date'), 'party_id' => ini('party_id') ?: null, 'amount' => inf('amount'), 'payment_mode' => in('payment_mode'),
        'account_id' => ini('account_id') ?: null, 'to_account_id' => ini('to_account_id') ?: null, 'reference_no' => in('reference_no'),
        'expense_category_id' => ini('expense_category_id') ?: null, 'entry_type' => in('entry_type'), 'description' => in('description'), 'remarks' => in('remarks'),
    ];
    if ($t === 'CASH' && !$in['account_id']) throw new AppException('Select an account.');
    $nid = save_document($t, $in, $id ?: null, $id ? ini('row_version') : null);
    $no = val('SELECT doc_no FROM documents WHERE id=?', [$nid]);
    flash('success', $cfg['label'] . ' ' . $no . ' saved.');
    if (in('after') === 'print') $_SESSION['auto_print'] = $nid;
    redirect(in('after') === 'new' ? url('voucher_form', ['t' => $t]) : url('doc_view', ['id' => $nid]));
}

$title = ($id ? 'Edit ' : 'New ') . $cfg['label'];
$accounts = rows('SELECT id, name, atype FROM accounts WHERE is_active=1 AND is_deleted=0 ORDER BY id');
$d = $doc ?: ['doc_date' => today(), 'party_id' => (int)($_GET['party'] ?? 0), 'grand_total' => '', 'payment_mode' => 'Cash', 'account_id' => '', 'to_account_id' => '', 'reference_no' => '', 'expense_category_id' => '', 'entry_type' => $_GET['type'] ?? 'IN', 'description' => '', 'remarks' => '', 'row_version' => 0];
$party = $d['party_id'] ? row('SELECT id, code, name, mobile FROM parties WHERE id=?', [$d['party_id']]) : null;
$modes = array_values(array_filter(payment_modes(), fn($m) => $m !== 'Credit'));
$nextNo = $doc['doc_no'] ?? next_number($cfg['series'], false);
?>
<div class="grid" style="grid-template-columns:minmax(0,2fr) minmax(0,1fr);align-items:start">
<form method="post" class="card" data-save id="vForm"><?= csrf_field() ?><input type="hidden" name="row_version" value="<?= (int)$d['row_version'] ?>"><input type="hidden" name="after" id="after" value="">
  <div class="card-head"><h3><?= e($title) ?></h3><span class="muted small"><kbd>Ctrl+S</kbd> Save &middot; <kbd>Ctrl+P</kbd> Save &amp; Print</span></div>
  <div class="form-grid cols-2">
    <div class="fg"><label>Voucher No.</label><input value="<?= e($nextNo) ?>" readonly></div>
    <div class="fg"><label class="req">Date</label><input type="date" name="doc_date" value="<?= e($d['doc_date']) ?>" required></div>
    <?php if ($cfg['ptype']): ?>
    <div class="fg span-2"><label class="req"><?= $cfg['ptype'] === 'C' ? 'Customer' : 'Supplier' ?></label>
      <input id="partyInput" placeholder="Search name / mobile / code..." autocomplete="off" value="<?= e($party ? $party['name'] : '') ?>" <?= $party ? '' : 'autofocus' ?>>
      <input type="hidden" name="party_id" id="partyId" value="<?= (int)($party['id'] ?? 0) ?>">
      <div class="hint" id="partyInfo"></div></div>
    <?php endif; ?>
    <?php if ($t === 'EXPENSE'): ?>
    <div class="fg"><label class="req">Expense Category</label><select name="expense_category_id" required autofocus><?= options(rows('SELECT id, name FROM expense_categories WHERE is_deleted=0 ORDER BY name'), $d['expense_category_id'], 'id', 'name', '- Select -') ?></select></div>
    <div class="fg"><label>Description</label><input name="description" value="<?= e($d['description']) ?>" maxlength="250"></div>
    <?php endif; ?>
    <?php if ($t === 'CASH'): ?>
    <div class="fg"><label class="req">Entry Type</label><select name="entry_type" id="entryType"><?php foreach (['IN' => 'Cash / Money In', 'OUT' => 'Cash / Money Out', 'TRANSFER' => 'Transfer between accounts'] as $k => $v) echo '<option value="' . $k . '"' . ($d['entry_type'] === $k ? ' selected' : '') . '>' . $v . '</option>'; ?></select></div>
    <div class="fg"><label class="req">Description</label><input name="description" value="<?= e($d['description']) ?>" required maxlength="250" placeholder="e.g. Owner capital, bank deposit, petty cash..."></div>
    <div class="fg"><label class="req" id="accLbl">Account</label><select name="account_id" required><?= options($accounts, $d['account_id'], 'id', 'name', '- Select -') ?></select></div>
    <div class="fg" id="toAccWrap"><label class="req">To Account</label><select name="to_account_id"><?= options($accounts, $d['to_account_id'], 'id', 'name', '- Select -') ?></select></div>
    <?php endif; ?>
    <div class="fg"><label class="req">Amount</label><input type="number" step="0.01" min="0.01" name="amount" id="amount" value="<?= e($d['grand_total']) ?>" required style="font-size:1.2rem;font-weight:600"></div>
    <?php if ($t !== 'CASH'): ?>
    <div class="fg"><label>Payment Mode</label><select name="payment_mode" id="pMode"><?php foreach ($modes as $m) echo '<option' . ($m === $d['payment_mode'] ? ' selected' : '') . '>' . e($m) . '</option>'; ?></select></div>
    <div class="fg"><label>Cash / Bank Account</label><select name="account_id" id="pAcc"><?= options($accounts, $d['account_id'], 'id', 'name', '- Auto by mode -') ?></select></div>
    <div class="fg"><label>Reference (Cheque / UTR / Txn No.)</label><input name="reference_no" value="<?= e($d['reference_no']) ?>"></div>
    <?php else: ?>
    <div class="fg"><label>Reference</label><input name="reference_no" value="<?= e($d['reference_no']) ?>"></div>
    <?php endif; ?>
    <div class="fg span-2"><label>Remarks</label><textarea name="remarks" rows="2"><?= e($d['remarks']) ?></textarea></div>
  </div>
  <div class="amount-words muted small" id="words"></div>
  <div class="btn-row"><button class="btn btn-success">Save</button><button class="btn btn-primary" type="button" onclick="submitWith('print')">Save &amp; Print</button><?php if (!$id): ?><button class="btn" type="button" onclick="submitWith('new')">Save &amp; New</button><?php endif; ?>
    <a class="btn" data-cancel href="<?= e(url('doc_list', ['t' => $t])) ?>">Cancel</a></div>
</form>
<div class="card" id="sidePanel">
  <?php if ($cfg['ptype']): ?><h3>Outstanding Bills</h3><div id="dueBills" class="small muted">Select a <?= $cfg['ptype'] === 'C' ? 'customer' : 'supplier' ?> to see unpaid bills.</div>
  <?php else: ?><h3>Account Balances</h3><table class="table"><tbody><?php foreach ($accounts as $a): ?><tr><td><?= e($a['name']) ?></td><td class="num"><?= money(account_balance((int)$a['id'])) ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?>
</div>
</div>
<script>
(function(){
  const f = document.getElementById('vForm');
  window.submitWith = a => { document.getElementById('after').value = a; f.requestSubmit ? f.requestSubmit() : f.submit(); };
  BP.onPrint = () => submitWith('print');
  const amt = document.getElementById('amount');
  f.addEventListener('submit', e => { if (!(+amt.value > 0)) { e.preventDefault(); BP.toast('Enter an amount greater than zero', 'warning'); amt.focus(); }
    const pid = document.getElementById('partyId'); if (pid && !(+pid.value)) { e.preventDefault(); BP.toast('Select a party', 'warning'); document.getElementById('partyInput').focus(); } });
  const pm = document.getElementById('pMode'), pa = document.getElementById('pAcc');
  if (pm) pm.addEventListener('change', () => pa.value = '');
  const et = document.getElementById('entryType');
  if (et) { const upd = () => { document.getElementById('toAccWrap').style.display = et.value === 'TRANSFER' ? '' : 'none'; document.getElementById('accLbl').textContent = et.value === 'TRANSFER' ? 'From Account' : 'Account'; }; et.onchange = upd; upd(); }
  const pt = <?= json_encode($cfg['ptype']) ?>;
  if (!pt) return;
  const pi = document.getElementById('partyInput'), pid = document.getElementById('partyId');
  async function showParty(id) {
    try {
      const r = await BP.api('party_info', { id }, 'GET');
      const p = r.party;
      document.getElementById('partyInfo').innerHTML = `${BP.esc(p.code)} ${BP.esc(p.mobile || '')} | Outstanding ${pt === 'C' ? 'receivable' : 'payable'}: <b class="${+p.balance > 0 ? 'text-danger' : ''}">${BP.money(p.balance)}</b> <button type="button" class="btn btn-sm" id="fillBal">Use full</button>`;
      document.getElementById('fillBal').onclick = () => { amt.value = Math.max(0, +p.balance).toFixed(2); amt.focus(); };
      const d = await BP.api('due_bills', { id }, 'GET');
      document.getElementById('dueBills').innerHTML = d.items.length ? '<table class="table"><thead><tr><th>Date</th><th>No.</th><th class="num">Total</th><th class="num">Due</th></tr></thead><tbody>' + d.items.map(x => `<tr><td>${BP.esc(x.doc_date)}</td><td>${x.id ? `<a href="index.php?p=doc_view&id=${x.id}">${BP.esc(x.doc_no)}</a>` : BP.esc(x.doc_no)}</td><td class="num">${BP.money(x.grand_total)}</td><td class="num text-danger">${BP.money(x.due_amount)}</td></tr>`).join('') + '</tbody></table><p class="small muted">Outstanding is matched to the latest bills (FIFO) using the running balance.</p>' : '<p class="muted">No unpaid bills.</p>';
    } catch (e) { BP.toast(e.message, 'danger'); }
  }
  BP.autocomplete(pi, { source: BP.partySource(pt), render: BP.partyRender, onSelect: p => { pi.value = p.name; pid.value = p.id; showParty(p.id); amt.focus(); } });
  pi.addEventListener('input', () => { pid.value = 0; });
  if (+pid.value) showParty(pid.value);
})();
</script>
