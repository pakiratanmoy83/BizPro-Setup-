<?php
$title = 'Recycle Bin (Deleted Records)';
$kind = $_GET['k'] ?? 'docs';
$strip = fn($v) => $v === null ? null : preg_replace('/~(DEL)?\d+$/', '', $v);
if (is_post()) {
    $act = in('action'); $id = ini('id');
    if ($act === 'purge' && !is_admin()) throw new AppException('Only an Admin can permanently remove records.');
    if ($act === 'purge' && strtoupper(trim((string)in('confirm_text'))) !== 'DELETE') throw new AppException('Type DELETE to confirm permanent removal.');
    switch (in('k')) {
        case 'docs':
            if ($act === 'restore') { restore_document($id); flash('success', 'Document restored and re-posted to stock and ledgers.'); }
            elseif ($act === 'purge') { purge_document($id); flash('success', 'Document permanently removed. A full copy is kept in the audit log.'); }
            break;
        case 'products':
            $p = row('SELECT * FROM products WHERE id=? AND is_deleted=1', [$id]);
            if (!$p) throw new AppException('Record not found.');
            if ($act === 'restore') {
                $code = $strip($p['code']); $bc = $strip($p['barcode']);
                if (val('SELECT id FROM products WHERE code=? AND id<>?', [$code, $id])) $code = $p['code'];
                if ($bc && val('SELECT id FROM products WHERE barcode=? AND id<>?', [$bc, $id])) $bc = null;
                update('products', ['is_deleted' => 0, 'is_active' => 1, 'deleted_by' => null, 'deleted_at' => null, 'code' => $code, 'barcode' => $bc], 'id=?', [$id]);
                audit('RESTORE', 'product', $id, $code);
                flash('success', 'Product restored.');
            } else {
                if (val('SELECT COUNT(*) FROM document_items WHERE product_id=?', [$id])) throw new AppException('Product is used in documents and cannot be permanently removed.');
                tx(function () use ($id, $p) { q('DELETE FROM stock_transactions WHERE product_id=?', [$id]); q('DELETE FROM products WHERE id=?', [$id]); audit('PURGE', 'product', $id, $p['code'], $p); });
                flash('success', 'Product permanently removed.');
            }
            break;
        case 'parties':
            $p = row('SELECT * FROM parties WHERE id=? AND is_deleted=1', [$id]);
            if (!$p) throw new AppException('Record not found.');
            if ($act === 'restore') {
                $code = $strip($p['code']);
                if (val('SELECT id FROM parties WHERE code=? AND ptype=? AND id<>?', [$code, $p['ptype'], $id])) $code = $p['code'];
                update('parties', ['is_deleted' => 0, 'is_active' => 1, 'deleted_by' => null, 'deleted_at' => null, 'code' => $code], 'id=?', [$id]);
                audit('RESTORE', $p['ptype'] === 'C' ? 'customer' : 'supplier', $id, $code);
                flash('success', 'Record restored.');
            } else {
                if (val('SELECT COUNT(*) FROM documents WHERE party_id=?', [$id]) || val('SELECT COUNT(*) FROM party_ledger WHERE party_id=?', [$id])) throw new AppException('This party has transactions and cannot be permanently removed.');
                q('DELETE FROM parties WHERE id=?', [$id]);
                audit('PURGE', $p['ptype'] === 'C' ? 'customer' : 'supplier', $id, $p['code'], $p);
                flash('success', 'Record permanently removed.');
            }
            break;
        default: throw new AppException('Invalid request.');
    }
    redirect(url('recycle', ['k' => in('k')]));
}
$types = doc_types();
if ($kind === 'products') $list = rows('SELECT id, code, name, barcode, deleted_at, (SELECT username FROM users WHERE id=deleted_by) deleted_by_name FROM products WHERE is_deleted=1 ORDER BY deleted_at DESC LIMIT 500');
elseif ($kind === 'parties') $list = rows('SELECT id, ptype, code, name, mobile, deleted_at, (SELECT username FROM users WHERE id=deleted_by) deleted_by_name FROM parties WHERE is_deleted=1 ORDER BY deleted_at DESC LIMIT 500');
else { $kind = 'docs'; $list = rows('SELECT d.*, p.name party FROM documents d LEFT JOIN parties p ON p.id=d.party_id WHERE d.is_deleted=1 ORDER BY d.deleted_at DESC LIMIT 500'); }
$cnt = ['docs' => val('SELECT COUNT(*) FROM documents WHERE is_deleted=1'), 'products' => val('SELECT COUNT(*) FROM products WHERE is_deleted=1'), 'parties' => val('SELECT COUNT(*) FROM parties WHERE is_deleted=1')];
?>
<div class="tabs"><?php foreach (['docs' => 'Transactions', 'products' => 'Products', 'parties' => 'Customers / Suppliers'] as $k => $l): ?><a class="<?= $k === $kind ? 'active' : '' ?>" href="<?= e(url('recycle', ['k' => $k])) ?>"><?= e($l) ?> (<?= (int)$cnt[$k] ?>)</a><?php endforeach; ?></div>
<div class="card">
  <div class="alert alert-info">Deleted records are kept here (soft delete) with who deleted them and why. <b>Restore</b> re-applies stock and ledger effects. <b>Delete permanently</b> is Admin-only and a full copy is written to the audit log.</div>
  <div class="table-wrap"><table class="table"><thead><tr>
  <?php if ($kind === 'docs'): ?><th>Type</th><th>Doc No</th><th>Date</th><th>Party</th><th class="num">Amount</th><th>Created By</th><th>Deleted By</th><th>Deleted At</th><th>Reason</th><?php else: ?><th>Code</th><th>Name</th><th><?= $kind === 'products' ? 'Barcode' : 'Type / Mobile' ?></th><th>Deleted By</th><th>Deleted At</th><?php endif; ?><th></th></tr></thead><tbody>
  <?php foreach ($list as $r): ?><tr>
    <?php if ($kind === 'docs'): ?><td><?= e($types[$r['dtype']]['label'] ?? $r['dtype']) ?></td><td><a href="<?= e(url('doc_view', ['id' => $r['id']])) ?>"><?= e($r['doc_no']) ?></a></td><td><?= dmy($r['doc_date']) ?></td><td><?= e($r['party']) ?></td><td class="num"><?= money($r['grand_total']) ?></td><td><?= e($r['created_by_name']) ?></td><td><?= e($r['deleted_by_name']) ?></td><td><?= dmyhm($r['deleted_at']) ?></td><td><?= e($r['delete_reason']) ?></td>
    <?php else: ?><td><?= e($strip($r['code'])) ?></td><td><?= e($r['name']) ?></td><td><?= $kind === 'products' ? e($strip($r['barcode'])) : ($r['ptype'] === 'C' ? 'Customer' : 'Supplier') . ' / ' . e($r['mobile']) ?></td><td><?= e($r['deleted_by_name']) ?></td><td><?= $r['deleted_at'] ? dmyhm($r['deleted_at']) : '' ?></td><?php endif; ?>
    <td class="actions nowrap"><form method="post" class="inline" data-confirm="Restore this record?"><?= csrf_field() ?><input type="hidden" name="k" value="<?= e($kind) ?>"><input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-success">Restore</button></form>
      <?php if (is_admin()): ?><button type="button" class="btn btn-sm btn-danger" onclick="purge('<?= e($kind) ?>', <?= (int)$r['id'] ?>)">Delete permanently</button><?php endif; ?></td></tr>
  <?php endforeach; if (!$list) echo '<tr><td colspan="10" class="empty">Recycle bin is empty.</td></tr>'; ?></tbody></table></div>
</div>
<form method="post" id="purgeForm" style="display:none"><?= csrf_field() ?><input type="hidden" name="k"><input type="hidden" name="action" value="purge"><input type="hidden" name="id"><input type="hidden" name="confirm_text"></form>
<script>
async function purge(k, id) {
  const v = await BP.confirm('This permanently removes the record and cannot be undone. Type DELETE to confirm.', { title: 'Permanent delete (Admin)', ok: 'Delete permanently', danger: true, input: 'Type DELETE' });
  if (!v) return;
  const f = document.getElementById('purgeForm');
  f.elements['k'].value = k; f.elements['id'].value = id; f.elements['confirm_text'].value = v; f.submit();
}
</script>
