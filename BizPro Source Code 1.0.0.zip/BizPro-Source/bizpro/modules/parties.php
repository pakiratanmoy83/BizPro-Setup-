<?php
$t = ($_GET['t'] ?? 'C') === 'S' ? 'S' : 'C';
$isC = $t === 'C';
require_perm($isC ? 'customer.view' : 'supplier.view');
$title = $isC ? 'Customers' : 'Suppliers';
$qv = trim((string)($_GET['q'] ?? ''));
$bal = $_GET['bal'] ?? '';
$where = ['p.ptype=?', 'p.is_deleted=0']; $pp = [$t];
if ($qv !== '') { $where[] = '(p.name LIKE ? OR p.code LIKE ? OR p.mobile LIKE ? OR p.company_name LIKE ? OR p.gstin LIKE ?)'; array_push($pp, "%$qv%", "%$qv%", "%$qv%", "%$qv%", "%$qv%"); }
$sign = $isC ? '(l.debit - l.credit)' : '(l.credit - l.debit)';
$sql = "SELECT * FROM (SELECT p.*, p.opening_balance + COALESCE((SELECT SUM($sign) FROM party_ledger l WHERE l.party_id=p.id),0) balance FROM parties p WHERE " . implode(' AND ', $where) . ") x";
if ($bal === 'due') $sql .= ' WHERE balance > 0.009';
if ($bal === 'adv') $sql .= ' WHERE balance < -0.009';
$sql .= ' ORDER BY is_system DESC, name';
[$list, $pager] = paginate($sql, $pp, 50);
$tot = (float)val("SELECT COALESCE(SUM(balance),0) FROM ($sql) z", $pp);
?>
<div class="card">
  <div class="card-head"><h3><?= $isC ? 'Customer' : 'Supplier' ?> Master <span class="muted small">Total <?= $isC ? 'receivable' : 'payable' ?>: <b><?= money($tot) ?></b></span></h3>
    <div class="btn-row">
      <?php if (can($isC ? 'customer.add' : 'supplier.add')): ?><a class="btn btn-primary" href="<?= e(url('party', ['t' => $t, 'edit' => 1])) ?>">+ Add <?= $isC ? 'Customer' : 'Supplier' ?></a><?php endif; ?>
      <button class="btn" data-export="excel" data-table="#pTable" data-file="<?= $isC ? 'customers' : 'suppliers' ?>" data-title="<?= $title ?>">Excel</button>
      <button class="btn" data-export="pdf" data-table="#pTable" data-file="<?= $isC ? 'customers' : 'suppliers' ?>" data-title="<?= $title ?> List">PDF</button>
      <button class="btn" onclick="window.print()">Print</button>
    </div></div>
  <form class="filters" method="get"><input type="hidden" name="p" value="parties"><input type="hidden" name="t" value="<?= $t ?>">
    <div class="fg grow"><label>Search name / code / mobile / GSTIN</label><input name="q" value="<?= e($qv) ?>" autofocus></div>
    <div class="fg"><label>Balance</label><select name="bal"><option value="">All</option><option value="due" <?= $bal === 'due' ? 'selected' : '' ?>>Outstanding only</option><option value="adv" <?= $bal === 'adv' ? 'selected' : '' ?>>Advance only</option></select></div>
    <button class="btn btn-primary">Filter</button><a class="btn" href="<?= e(url('parties', ['t' => $t])) ?>">Reset</a></form>
  <div class="table-wrap"><table class="table" id="pTable">
    <thead><tr><th>ID</th><th>Name</th><?= $isC ? '' : '<th>Company</th>' ?><th>Mobile</th><th>GSTIN</th><th>State</th><th class="num">Credit Limit</th><th class="num">Outstanding</th><th class="no-export"></th></tr></thead><tbody>
    <?php foreach ($list as $p): ?>
      <tr><td><?= e($p['code']) ?></td><td><a href="<?= e(url('party', ['id' => $p['id']])) ?>"><?= e($p['name']) ?></a> <?= $p['is_active'] ? '' : '<span class="badge">Inactive</span>' ?></td>
      <?= $isC ? '' : '<td>' . e($p['company_name']) . '</td>' ?><td><?= e($p['mobile']) ?></td><td><?= e($p['gstin']) ?></td><td><?= e($p['state']) ?></td>
      <td class="num"><?= $p['credit_limit'] > 0 ? money($p['credit_limit']) : '-' ?></td>
      <td class="num <?= $p['balance'] > 0 ? 'text-danger bold' : ($p['balance'] < 0 ? 'text-success' : '') ?>"><?= money($p['balance']) ?></td>
      <td class="actions no-export"><a class="btn btn-sm" href="<?= e(url('party', ['id' => $p['id']])) ?>">Ledger</a>
        <?php if (!$p['is_system'] && can($isC ? 'customer.edit' : 'supplier.edit')): ?><a class="btn btn-sm" href="<?= e(url('party', ['id' => $p['id'], 'edit' => 1])) ?>">Edit</a><?php endif; ?></td></tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="9" class="empty">No records.</td></tr><?php endif; ?>
    </tbody></table></div><?= $pager ?>
</div>
