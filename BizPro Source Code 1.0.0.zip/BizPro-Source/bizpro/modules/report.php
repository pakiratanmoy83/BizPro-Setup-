<?php
$reg = report_registry();
$key = (string)($_GET['r'] ?? '');
if (!isset($reg[$key])) throw new AppException('Unknown report.');
[$group, $rtitle, $perm, $pt, $filters, $builder] = $reg[$key];
$link = $reg[$key][6] ?? null;
require_perm($perm);
if ($link) redirect($link);
$title = $rtitle;
$f = rpt_filters();
if (in_array('to', $filters) && !in_array('date', $filters)) $f['from'] = '1900-01-01';
$res = $builder($f);
audit('REPORT', 'report', null, $key, ['from' => $f['from'], 'to' => $f['to']]);

$partyName = $f['party'] ? val('SELECT name FROM parties WHERE id=?', [$f['party']]) : '';
$prodName = $f['product'] ? val('SELECT name FROM products WHERE id=?', [$f['product']]) : '';
$sub = [];
if (in_array('date', $filters)) $sub[] = dmy($f['from']) . ' to ' . dmy($f['to']);
elseif (in_array('to', $filters)) $sub[] = 'As on ' . dmy($f['to']);
else $sub[] = 'As on ' . dmyhm(now());
if ($f['user']) $sub[] = 'User: ' . val('SELECT username FROM users WHERE id=?', [$f['user']]);
if ($partyName) $sub[] = ($pt === 'S' ? 'Supplier: ' : 'Customer: ') . $partyName;
if ($prodName) $sub[] = 'Product: ' . $prodName;
if ($f['category']) $sub[] = 'Category: ' . val('SELECT name FROM categories WHERE id=?', [$f['category']]);
if ($f['q'] !== '') $sub[] = 'Search: ' . $f['q'];
$subTxt = implode(' | ', $sub);
$file = $key . '_' . date('Ymd');

function rpt_cell($v, string $type, array $r) {
    switch ($type) {
        case 'date': return $v ? dmy($v) : '';
        case 'datetime': return $v ? dmyhm($v) : '';
        case 'month': return $v ? date('M Y', strtotime($v . '-01')) : '';
        case 'money': return $v === null || $v === '' ? '' : money($v);
        case 'qty': return qtyf($v);
        case 'int': return $v === '' || $v === null ? '' : (string)(int)$v;
        case 'pct': return number_format((float)$v, 2) . '%';
        case 'doc': return isset($r['id']) ? '<a href="' . e(url('doc_view', ['id' => $r['id']])) . '">' . e($v) . '</a>' : e($v);
        case 'doclink': return !empty($r['document_id']) ? '<a href="' . e(url('doc_view', ['id' => $r['document_id']])) . '">' . e($v) . '</a>' : e($v);
        default: return e($v);
    }
}
function rpt_table(array $res, string $id): string {
    $numeric = ['money', 'qty', 'int', 'pct'];
    $h = '<div class="table-wrap"><table class="table" id="' . $id . '"><thead><tr>';
    foreach ($res['cols'] as $k => [$l, $t]) $h .= '<th' . (in_array($t, $numeric) ? ' class="num"' : '') . '>' . e($l) . '</th>';
    $h .= '</tr></thead><tbody>';
    $tot = [];
    foreach ($res['rows'] as $r) {
        $bold = !empty($res['boldkey']) && ($r[$res['boldkey']] ?? '') === 'bold';
        $h .= '<tr' . ($bold ? ' class="bold"' : '') . '>';
        $i = 0;
        foreach ($res['cols'] as $k => [$l, $t]) {
            $v = $r[$k] ?? '';
            $cell = rpt_cell($v, $t, $r);
            if ($i === 0 && !empty($res['rowlink'])) $cell = '<a href="' . e(($res['rowlink'])($r)) . '">' . $cell . '</a>';
            if (in_array($t, ['money']) && is_numeric($v) && $v < 0) $cell = '<span class="text-danger">' . $cell . '</span>';
            $h .= '<td' . (in_array($t, $numeric) ? ' class="num"' : '') . '>' . $cell . '</td>';
            $i++;
        }
        $h .= '</tr>';
        foreach ($res['sum'] as $s) if (isset($r[$s]) && is_numeric($r[$s])) $tot[$s] = ($tot[$s] ?? 0) + $r[$s];
    }
    if (!$res['rows']) $h .= '<tr><td colspan="' . count($res['cols']) . '" class="empty">No records found for the selected filters.</td></tr>';
    $h .= '</tbody>';
    if ($res['sum'] && $res['rows']) {
        $h .= '<tfoot><tr>';
        $i = 0;
        foreach ($res['cols'] as $k => [$l, $t]) {
            $v = $i === 0 ? 'Total (' . count($res['rows']) . ')' : (isset($tot[$k]) ? rpt_cell($t === 'int' ? (int)$tot[$k] : $tot[$k], $t === 'pct' ? 'text' : $t, []) : '');
            $h .= '<td' . (in_array($t, $numeric) ? ' class="num"' : '') . '>' . $v . '</td>';
            $i++;
        }
        $h .= '</tr></tfoot>';
    }
    return $h . '</table></div>';
}
$users = rows('SELECT id, username name FROM users WHERE is_deleted=0 ORDER BY username');
?>
<div class="card">
  <div class="card-head"><div><h3><?= e($rtitle) ?></h3><div class="muted small"><?= e($subTxt) ?></div></div>
    <div class="btn-row"><a class="btn" href="<?= e(url('reports')) ?>" data-cancel>All Reports</a><?= $res['extra_btn'] ?? '' ?>
      <?php if ($res['cols']): ?>
      <button class="btn" data-export="excel" data-table="#rptTable" data-file="<?= e($file) ?>" data-title="<?= e($rtitle) ?>" data-sub="<?= e($subTxt) ?>">Excel</button>
      <button class="btn" data-export="pdf" data-table="#rptTable" data-file="<?= e($file) ?>" data-title="<?= e($rtitle) ?>" data-sub="<?= e($subTxt) ?>">PDF</button>
      <button class="btn" onclick="window.print()">Print</button><?php endif; ?></div></div>
  <?php if ($filters): ?>
  <form class="filters" method="get" id="rptForm"><input type="hidden" name="p" value="report"><input type="hidden" name="r" value="<?= e($key) ?>">
    <?php if (in_array('date', $filters)): ?>
      <div class="fg"><label>From</label><input type="date" name="from" value="<?= e($f['from']) ?>"></div><div class="fg"><label>To</label><input type="date" name="to" value="<?= e($f['to']) ?>"></div>
      <div class="fg"><label>Quick</label><select id="rptQuick"><option value="">-</option><option value="today">Today</option><option value="yday">Yesterday</option><option value="week">Last 7 days</option><option value="month">This month</option><option value="lmonth">Last month</option><option value="fy">This financial year</option></select></div>
    <?php elseif (in_array('to', $filters)): ?><div class="fg"><label>As on</label><input type="date" name="to" value="<?= e($f['to']) ?>"></div><?php endif; ?>
    <?php if (in_array('user', $filters)): ?><div class="fg"><label>User</label><select name="user"><?= options($users, $f['user'], 'id', 'name', 'All users') ?></select></div><?php endif; ?>
    <?php if (in_array('party', $filters) && $pt): ?><div class="fg grow"><label><?= $pt === 'S' ? 'Supplier' : 'Customer' ?></label><input type="hidden" name="party" id="rptParty" value="<?= $f['party'] ?: '' ?>"><input id="rptPartyName" value="<?= e($partyName) ?>" placeholder="All - type to search" autocomplete="off" data-pt="<?= $pt ?>"></div><?php endif; ?>
    <?php if (in_array('product', $filters)): ?><div class="fg grow"><label>Product</label><input type="hidden" name="product" id="rptProd" value="<?= $f['product'] ?: '' ?>"><input id="rptProdName" value="<?= e($prodName) ?>" placeholder="All - type to search" autocomplete="off"></div><?php endif; ?>
    <?php if (in_array('category', $filters)): ?><div class="fg"><label>Category</label><select name="category"><?= options(rows('SELECT id,name FROM categories WHERE is_deleted=0 ORDER BY name'), $f['category'], 'id', 'name', 'All') ?></select></div><?php endif; ?>
    <?php if (in_array('ecat', $filters)): ?><div class="fg"><label>Expense Category</label><select name="ecat"><?= options(rows('SELECT id,name FROM expense_categories WHERE is_deleted=0 ORDER BY name'), $_GET['ecat'] ?? '', 'id', 'name', 'All') ?></select></div><?php endif; ?>
    <?php if (in_array('mode', $filters)): ?><div class="fg"><label>Payment Mode</label><select name="mode"><option value="">All</option><?php foreach (payment_modes() as $m) echo '<option' . ($f['mode'] === $m ? ' selected' : '') . '>' . e($m) . '</option>'; ?></select></div><?php endif; ?>
    <?php if (in_array('q', $filters)): ?><div class="fg"><label>Search</label><input name="q" value="<?= e($f['q']) ?>" placeholder="No / name / text"></div><?php endif; ?>
    <?php if ($key === 'stock_movement'): ?><div class="fg"><label class="check"><input type="checkbox" name="all" value="1" <?= !empty($_GET['all']) ? 'checked' : '' ?>> Include products without movement</label></div><?php endif; ?>
    <button class="btn btn-primary">Show Report</button><a class="btn" href="<?= e(url('report', ['r' => $key])) ?>">Reset</a>
  </form>
  <?php endif; ?>
  <div class="print-only"><h2 style="margin:0"><?= e(setting('business_name')) ?></h2><h3 style="margin:4px 0"><?= e($rtitle) ?></h3><div><?= e($subTxt) ?></div><hr></div>
  <?php if (!empty($res['note'])): ?><div class="alert alert-info"><?= e($res['note']) ?></div><?php endif; ?>
  <?= $res['cols'] ? rpt_table($res, 'rptTable') : '' ?>
</div>
<?php if (!empty($res['detail'])): ?>
<div class="card"><div class="card-head"><h3>Product-wise Detail</h3><div class="btn-row">
  <button class="btn" data-export="excel" data-table="#rptDetail" data-file="<?= e($file) ?>_detail" data-title="<?= e($rtitle) ?> - Detail">Excel</button>
  <button class="btn" data-export="pdf" data-table="#rptDetail" data-file="<?= e($file) ?>_detail" data-title="<?= e($rtitle) ?> - Detail" data-sub="<?= e($subTxt) ?>">PDF</button></div></div>
  <?= rpt_table($res['detail'], 'rptDetail') ?></div>
<?php endif; ?>
<script>
(function(){
  const pn = document.getElementById('rptPartyName');
  if (pn) { BP.autocomplete(pn, { source: BP.partySource(pn.dataset.pt), render: BP.partyRender, onSelect: p => { document.getElementById('rptParty').value = p.id; pn.value = p.name; } });
    pn.addEventListener('input', () => { if (!pn.value.trim()) document.getElementById('rptParty').value = ''; }); }
  const pr = document.getElementById('rptProdName');
  if (pr) { BP.autocomplete(pr, { source: BP.productSource, render: BP.productRender, onSelect: p => { document.getElementById('rptProd').value = p.id; pr.value = p.name; } });
    pr.addEventListener('input', () => { if (!pr.value.trim()) document.getElementById('rptProd').value = ''; }); }
  const qk = document.getElementById('rptQuick');
  if (qk) qk.addEventListener('change', () => {
    const f = document.querySelector('[name=from]'), t = document.querySelector('[name=to]');
    const d = new Date(), iso = x => new Date(x.getTime() - x.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    let a = new Date(d), b = new Date(d);
    switch (qk.value) {
      case 'yday': a.setDate(a.getDate() - 1); b = new Date(a); break;
      case 'week': a.setDate(a.getDate() - 6); break;
      case 'month': a = new Date(d.getFullYear(), d.getMonth(), 1); break;
      case 'lmonth': a = new Date(d.getFullYear(), d.getMonth() - 1, 1); b = new Date(d.getFullYear(), d.getMonth(), 0); break;
      case 'fy': a = new Date(<?= json_encode($f['fy_start']) ?>); break;
    }
    if (qk.value) { f.value = iso(a); t.value = iso(b); document.getElementById('rptForm').submit(); }
  });
})();
</script>
