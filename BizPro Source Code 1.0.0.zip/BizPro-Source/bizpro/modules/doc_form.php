<?php
$t = strtoupper((string)($_GET['t'] ?? 'SALE'));
if (!in_array($t, ['SALE', 'PURCHASE', 'SRET', 'PRET', 'ADJ'])) throw new AppException('Invalid form');
$cfg = dt($t);
$id = (int)($_GET['id'] ?? 0);
$doc = null; $items = [];
if ($id) {
    $doc = row('SELECT * FROM documents WHERE id=? AND dtype=? AND is_deleted=0', [$id, $t]);
    if (!$doc) throw new AppException('Document not found.');
    if (!can_edit_doc($doc)) throw new AppException('You do not have permission to edit this ' . $cfg['label'] . '.');
    [$cv, $own] = doc_view_scope($t);
    if ($own && $doc['created_by'] != current_user()['id']) throw new AppException('You can only edit your own entries.');
    $items = rows('SELECT i.*, p.code, p.barcode, p.current_stock, p.purchase_rate FROM document_items i JOIN products p ON p.id=i.product_id WHERE i.document_id=? ORDER BY i.line_no', [$id]);
} else {
    require_perm(perm_for($t, 'add'));
}
$title = ($id ? 'Edit ' : 'New ') . $cfg['label'];
$accounts = rows('SELECT id, name, atype FROM accounts WHERE is_active=1 AND is_deleted=0 ORDER BY id');
$nextNo = $doc['doc_no'] ?? next_number($cfg['series'], false);
$presetParty = null;
$pid = $doc['party_id'] ?? (int)($_GET['party'] ?? 0);
if (!$pid && $t === 'SALE') $pid = (int)val("SELECT id FROM parties WHERE ptype='C' AND is_system=1 ORDER BY id LIMIT 1");
if ($pid) { $presetParty = row('SELECT id, code, name, mobile, state, gstin, credit_limit, is_system FROM parties WHERE id=?', [$pid]); if ($presetParty) $presetParty['balance'] = party_balance($pid); }
$against = null;
if (!empty($doc['against_doc_id'])) $against = row('SELECT id, doc_no, doc_date FROM documents WHERE id=?', [$doc['against_doc_id']]);
$againstPreset = (int)($_GET['against'] ?? 0);
$jsCfg = [
    'dtype' => $t, 'label' => $cfg['label'], 'ptype' => $cfg['ptype'], 'id' => $id ?: null, 'row_version' => (int)($doc['row_version'] ?? 0),
    'rateField' => in_array($t, ['SALE', 'SRET']) ? 'sale_rate' : 'purchase_rate', 'roundOff' => setting('round_off', '1') === '1',
    'bizState' => setting('business_state', ''), 'party' => $presetParty, 'against' => $against, 'againstPreset' => $againstPreset,
    'canQuickAdd' => $cfg['ptype'] ? can($cfg['ptype'] === 'C' ? 'customer.add' : 'supplier.add') : false,
    'stockCheck' => setting('allow_negative_stock', '0') !== '1' && in_array($t, ['SALE', 'PRET']),
    'autoPrint' => setting('auto_print', '0') === '1', 'invoiceFormat' => setting('invoice_format', 'A4'),
    'header' => $doc ? ['doc_date' => $doc['doc_date'], 'ref_invoice_no' => $doc['ref_invoice_no'], 'bill_discount' => (float)$doc['bill_discount'], 'other_charges' => (float)$doc['other_charges'], 'paid_amount' => (float)$doc['paid_amount'], 'payment_mode' => $doc['payment_mode'], 'account_id' => $doc['account_id'], 'remarks' => $doc['remarks'], 'grand_total' => (float)$doc['grand_total']] : null,
    'items' => array_map(fn($i) => ['product_id' => (int)$i['product_id'], 'name' => $i['product_name'], 'code' => $i['code'], 'unit' => $i['unit'], 'qty' => (float)$i['qty'], 'free_qty' => (float)$i['free_qty'], 'rate' => (float)$i['rate'], 'disc_pct' => (float)$i['disc_pct'], 'disc_amt' => (float)$i['disc_amt'], 'gst_pct' => (float)$i['gst_pct'], 'stock' => (float)$i['current_stock'] + ($cfg['stock'] < 0 ? (float)$i['qty'] : 0), 'mrp' => (float)$i['mrp']], $items),
];
$isAdj = $t === 'ADJ';
$isRet = in_array($t, ['SRET', 'PRET']);
?>
<div class="bill-layout" id="billApp">
  <div>
    <div class="card">
      <div class="form-grid cols-4">
        <div class="fg"><label><?= $isAdj ? 'Adjustment No.' : ($t === 'PURCHASE' ? 'Purchase Entry No.' : 'Invoice / Return No.') ?></label><input value="<?= e($nextNo) ?>" readonly title="Final number is assigned when saved"></div>
        <div class="fg"><label class="req">Date</label><input type="date" id="hDate" value="<?= e($doc['doc_date'] ?? today()) ?>" max="<?= e(date('Y-m-d', strtotime('+1 day'))) ?>"></div>
        <?php if ($cfg['ptype']): ?>
        <div class="fg span-2"><label class="req"><?= $cfg['ptype'] === 'C' ? 'Customer' : 'Supplier' ?> <kbd><?= $cfg['ptype'] === 'C' ? 'F3' : 'F4' ?></kbd></label>
          <div class="input-group"><input id="partyInput" placeholder="Search name / mobile / code..." autocomplete="off"><?php if ($jsCfg['canQuickAdd']): ?><button type="button" class="btn btn-sm" id="quickParty" title="Add new">+ New</button><?php endif; ?></div>
          <div class="hint" id="partyInfo"></div></div>
        <?php endif; ?>
        <?php if ($t === 'PURCHASE'): ?><div class="fg"><label>Supplier Invoice No.</label><input id="hRefInv" value="<?= e($doc['ref_invoice_no'] ?? '') ?>"></div><?php endif; ?>
        <?php if ($isRet): ?>
        <div class="fg span-2"><label>Against Invoice (optional)</label><div class="input-group"><input id="againstInput" placeholder="Search original invoice no..." autocomplete="off" value="<?= e($against['doc_no'] ?? '') ?>"><button type="button" class="btn btn-sm" id="clearAgainst">Clear</button></div><div class="hint" id="againstInfo"></div></div>
        <?php endif; ?>
      </div>
      <div class="scan-box fg" style="margin:4px 0 0"><label>Scan Barcode / Search Product <kbd>F2</kbd></label><input id="scanInput" placeholder="Scan barcode and press Enter, or type product name / code" autocomplete="off" autofocus></div>
    </div>
    <div class="card" style="padding:0">
      <div class="table-wrap" style="border:0"><table class="table bill-table" id="itemsTable">
        <thead><tr><th>#</th><th>Product</th><?php if (!$isAdj): ?><th class="num">Stock</th><?php endif; ?>
          <?php if ($isAdj): ?><th>Add / Less</th><?php endif; ?>
          <th class="num">Qty</th><?php if ($t === 'PURCHASE'): ?><th class="num">Free</th><?php endif; ?>
          <th class="num">Rate</th><?php if (!$isAdj): ?><th class="num">Disc %</th><th class="num">GST %</th><?php endif; ?><th class="num">Amount</th><th></th></tr></thead>
        <tbody></tbody>
      </table></div>
      <div class="empty" id="noItems">No products added. Scan a barcode or search above.</div>
    </div>
    <div class="card"><div class="fg" style="margin:0"><label><?= $isAdj ? 'Reason for adjustment' : 'Remarks' ?></label><textarea id="hRemarks" rows="2"><?= e($doc['remarks'] ?? '') ?></textarea></div></div>
  </div>

  <div>
    <div class="card totals-box">
      <?php if (!$isAdj): ?>
      <div class="trow"><span>Items / Qty</span><span id="tCount">0 / 0</span></div>
      <div class="trow"><span>Sub Total</span><span id="tSub">0.00</span></div>
      <div class="trow"><span>Item Discount</span><span id="tDisc">0.00</span></div>
      <div class="trow"><span>Taxable Value</span><span id="tTaxable">0.00</span></div>
      <div class="trow" id="rowCgst"><span>CGST</span><span id="tCgst">0.00</span></div>
      <div class="trow" id="rowSgst"><span>SGST</span><span id="tSgst">0.00</span></div>
      <div class="trow" id="rowIgst" style="display:none"><span>IGST</span><span id="tIgst">0.00</span></div>
      <div class="trow"><span>Bill Discount (-)</span><input type="number" step="0.01" min="0" id="hBillDisc" value="0"></div>
      <div class="trow"><span>Other Charges (+)</span><input type="number" step="0.01" min="0" id="hOther" value="0"></div>
      <div class="trow"><span>Round Off</span><span id="tRound">0.00</span></div>
      <div class="trow grand"><span>Grand Total</span><span id="tGrand">0.00</span></div>
      <div class="trow"><span><?= $t === 'SRET' ? 'Refund Paid' : ($t === 'PRET' ? 'Refund Received' : 'Paid Amount') ?></span><input type="number" step="0.01" min="0" id="hPaid" value="0"></div>
      <div class="trow"><span>Due / Balance</span><b id="tDue">0.00</b></div>
      <div class="fg" style="margin-top:10px"><label>Payment Mode</label><select id="hMode"><?php foreach (payment_modes() as $m) echo '<option>' . e($m) . '</option>'; ?></select></div>
      <div class="fg"><label>Cash / Bank Account</label><select id="hAccount"><option value="">- Auto -</option><?= options($accounts, '', 'id', 'name') ?></select></div>
      <div class="btn-row" style="margin-bottom:8px"><button type="button" class="btn btn-sm" id="btnFull">Full Paid</button><button type="button" class="btn btn-sm" id="btnCredit">Credit (0)</button></div>
      <?php else: ?>
      <div class="trow"><span>Items</span><span id="tCount">0</span></div>
      <div class="trow grand"><span>Adjustment Value</span><span id="tGrand">0.00</span></div>
      <?php endif; ?>
      <div class="btn-row" style="flex-direction:column;align-items:stretch;margin-top:10px">
        <button type="button" class="btn btn-success btn-lg" id="btnSave">Save <kbd>Ctrl+S</kbd></button>
        <?php if (!$isAdj): ?><button type="button" class="btn btn-primary" id="btnSavePrint">Save &amp; Print</button><?php endif; ?>
        <?php if ($t === 'SALE' && !$id): ?><div class="btn-row"><button type="button" class="btn" id="btnHold" style="flex:1">Hold Bill</button><button type="button" class="btn" id="btnResume" style="flex:1">Resume Bill <span class="badge" id="heldCount">0</span></button></div><?php endif; ?>
        <div class="btn-row"><button type="button" class="btn" id="btnClear" style="flex:1">Clear</button><a class="btn" data-cancel style="flex:1" href="<?= e(url('doc_list', ['t' => $t])) ?>">Close <kbd>Esc</kbd></a></div>
      </div>
      <?php if ($id): ?><p class="small muted">Created by <?= e($doc['created_by_name']) ?> on <?= dmyhm($doc['created_at']) ?><?= $doc['modified_at'] ? '<br>Last modified by ' . e($doc['modified_by_name']) . ' on ' . dmyhm($doc['modified_at']) : '' ?></p><?php endif; ?>
    </div>
  </div>
</div>
<script>window.DOC = <?= json_encode($jsCfg, JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="assets/js/bill.js?v=<?= APP_VERSION ?>"></script>
