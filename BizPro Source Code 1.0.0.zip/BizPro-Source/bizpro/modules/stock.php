<?php
$title = 'Stock Management';
$qv = trim((string)($_GET['q'] ?? ''));
$cat = (int)($_GET['cat'] ?? 0); $brand = (int)($_GET['brand'] ?? 0);
$st = $_GET['st'] ?? '';
$w = ['p.is_deleted=0']; $pp = [];
if ($qv !== '') { $w[] = '(p.name LIKE ? OR p.code LIKE ? OR p.barcode=?)'; array_push($pp, "%$qv%", "%$qv%", $qv); }
if ($cat) { $w[] = 'p.category_id=?'; $pp[] = $cat; }
if ($brand) { $w[] = 'p.brand_id=?'; $pp[] = $brand; }
if ($st === 'low') $w[] = 'p.current_stock <= p.min_stock AND p.current_stock > 0';
if ($st === 'out') $w[] = 'p.current_stock <= 0';
if ($st === 'over') $w[] = 'p.max_stock > 0 AND p.current_stock > p.max_stock';
if ($st === 'instock') $w[] = 'p.current_stock > 0';
$where = implode(' AND ', $w);
$sql = "SELECT p.*, c.name category, b.name brand, u.name unit, p.current_stock*p.purchase_rate value_cost, p.current_stock*p.sale_rate value_sale
  FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN brands b ON b.id=p.brand_id LEFT JOIN units u ON u.id=p.unit_id WHERE $where ORDER BY p.name";
[$list, $pager] = paginate($sql, $pp, 100);
$tot = row("SELECT COUNT(*) n, COALESCE(SUM(current_stock),0) q, COALESCE(SUM(CASE WHEN current_stock>0 THEN current_stock*purchase_rate END),0) vc, COALESCE(SUM(CASE WHEN current_stock>0 THEN current_stock*sale_rate END),0) vs,
  SUM(current_stock<=0) out_n, SUM(current_stock>0 AND current_stock<=min_stock) low_n FROM products p WHERE $where", $pp);
$showCost = can('dashboard.profit') || can('report.stock') || can('purchase.add');
?>
<div class="grid grid-4">
  <div class="stat"><div class="label">Products</div><div class="value"><?= (int)$tot['n'] ?></div><div class="sub">Total qty <?= qtyf($tot['q']) ?></div></div>
  <?php if ($showCost): ?><div class="stat blue"><div class="label">Stock Value (Cost)</div><div class="value"><?= money($tot['vc']) ?></div><div class="sub">at purchase rate</div></div><?php endif; ?>
  <div class="stat green"><div class="label">Stock Value (Sale)</div><div class="value"><?= money($tot['vs']) ?></div><div class="sub">at sale rate</div></div>
  <div class="stat red"><div class="label">Alerts</div><div class="value"><?= (int)$tot['low_n'] ?> low / <?= (int)$tot['out_n'] ?> out</div><div class="sub"><a href="<?= e(url('stock', ['st' => 'low'])) ?>">Low</a> &middot; <a href="<?= e(url('stock', ['st' => 'out'])) ?>">Out of stock</a></div></div>
</div>
<div class="card">
  <div class="card-head"><h3>Current Stock</h3><div class="btn-row">
    <?php if (can('stock.adjust')): ?><a class="btn btn-primary" href="<?= e(url('doc_form', ['t' => 'ADJ'])) ?>">+ Stock Adjustment</a><?php endif; ?>
    <a class="btn" href="<?= e(url('stock_ledger')) ?>">Stock Movement / Ledger</a>
    <button class="btn" data-export="excel" data-table="#sTable" data-file="stock_<?= today() ?>" data-title="Current Stock">Excel</button>
    <button class="btn" data-export="pdf" data-table="#sTable" data-file="stock_<?= today() ?>" data-title="Current Stock" data-sub="As on <?= dmyhm(now()) ?>">PDF</button>
    <button class="btn" onclick="window.print()">Print</button></div></div>
  <form class="filters" method="get"><input type="hidden" name="p" value="stock">
    <div class="fg grow"><label>Search / scan barcode</label><input name="q" value="<?= e($qv) ?>" autofocus></div>
    <div class="fg"><label>Category</label><select name="cat"><?= options(rows('SELECT id,name FROM categories WHERE is_deleted=0 ORDER BY name'), $cat, 'id', 'name', 'All') ?></select></div>
    <div class="fg"><label>Brand</label><select name="brand"><?= options(rows('SELECT id,name FROM brands WHERE is_deleted=0 ORDER BY name'), $brand, 'id', 'name', 'All') ?></select></div>
    <div class="fg"><label>Status</label><select name="st"><?php foreach (['' => 'All', 'instock' => 'In stock', 'low' => 'Low stock', 'out' => 'Out of stock', 'over' => 'Above max'] as $k => $v) echo '<option value="' . $k . '"' . ($st === $k ? ' selected' : '') . '>' . $v . '</option>'; ?></select></div>
    <button class="btn btn-primary">Filter</button><a class="btn" href="<?= e(url('stock')) ?>">Reset</a></form>
  <div class="table-wrap"><table class="table" id="sTable"><thead><tr><th>Code</th><th>Product</th><th>Category</th><th>Brand</th><th>Unit</th><th class="num">Min</th><th class="num">Stock</th><?php if ($showCost): ?><th class="num">Cost Rate</th><th class="num">Value (Cost)</th><?php endif; ?><th class="num">Sale Rate</th><th class="num">Value (Sale)</th><th>Status</th><th class="no-export"></th></tr></thead><tbody>
  <?php foreach ($list as $p): $s = (float)$p['current_stock']; ?>
    <tr><td><?= e($p['code']) ?></td><td><a href="<?= e(url('product', ['id' => $p['id'], 'view' => 1])) ?>"><?= e($p['name']) ?></a></td><td><?= e($p['category']) ?></td><td><?= e($p['brand']) ?></td><td><?= e($p['unit']) ?></td>
    <td class="num"><?= qtyf($p['min_stock']) ?></td><td class="num bold <?= $s <= 0 ? 'text-danger' : ($s <= $p['min_stock'] ? 'text-warning' : '') ?>"><?= qtyf($s) ?></td>
    <?php if ($showCost): ?><td class="num"><?= money($p['purchase_rate']) ?></td><td class="num"><?= money($p['value_cost']) ?></td><?php endif; ?>
    <td class="num"><?= money($p['sale_rate']) ?></td><td class="num"><?= money($p['value_sale']) ?></td>
    <td><?= $s <= 0 ? '<span class="badge red">Out</span>' : ($s <= $p['min_stock'] ? '<span class="badge amber">Low</span>' : ($p['max_stock'] > 0 && $s > $p['max_stock'] ? '<span class="badge blue">Over</span>' : '<span class="badge green">OK</span>')) ?><?= $p['is_active'] ? '' : ' <span class="badge">Inactive</span>' ?></td>
    <td class="no-export actions"><a class="btn btn-sm" href="<?= e(url('stock_ledger', ['product' => $p['id']])) ?>">Ledger</a></td></tr>
  <?php endforeach; if (!$list) echo '<tr><td colspan="13" class="empty">No products.</td></tr>'; ?>
  </tbody></table></div><?= $pager ?>
</div>
