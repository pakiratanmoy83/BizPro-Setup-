<?php
$title = 'My Profile';
$me = current_user();
$u = row('SELECT u.*, r.name role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?', [$me['id']]);
if (is_post()) {
    $act = in('action');
    if ($act === 'password') {
        $cur = (string)in('current'); $new = (string)in('new'); $new2 = (string)in('new2');
        if (!password_verify($cur, $u['password_hash'])) { audit('PASSWORD_FAIL', 'user', $u['id'], $u['username']); throw new AppException('Current password is incorrect.'); }
        if ($new !== $new2) throw new AppException('New passwords do not match.');
        if ($e = password_policy($new)) throw new AppException($e);
        if (password_verify($new, $u['password_hash'])) throw new AppException('New password must be different from the current password.');
        update('users', ['password_hash' => password_hash($new, PASSWORD_DEFAULT), 'must_change_pw' => 0, 'modified_by' => $u['id'], 'modified_at' => now()], 'id=?', [$u['id']]);
        // log out other sessions of this user for safety
        q('UPDATE user_sessions SET is_active=0, logout_at=? WHERE user_id=? AND session_token<>? AND is_active=1', [now(), $u['id'], $_SESSION['token'] ?? '']);
        $_SESSION['user']['must_change_pw'] = 0;
        audit('CHANGE_PASSWORD', 'user', $u['id'], $u['username']);
        flash('success', 'Password changed successfully. Other sessions of your account were logged out.');
        redirect(url('dashboard'));
    }
    if ($act === 'profile') {
        $d = ['full_name' => trim((string)in('full_name')), 'email' => trim((string)in('email')) ?: null, 'mobile' => trim((string)in('mobile')) ?: null];
        if ($d['full_name'] === '') throw new AppException('Full name is required.');
        if ($d['email'] && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) throw new AppException('Invalid email.');
        update('users', $d + ['modified_by' => $u['id'], 'modified_at' => now()], 'id=?', [$u['id']]);
        $_SESSION['user']['full_name'] = $d['full_name'];
        audit('EDIT', 'user', $u['id'], $u['username'], ['profile' => $d]);
        flash('success', 'Profile updated.');
        redirect(url('profile'));
    }
}
$sessions = rows('SELECT * FROM user_sessions WHERE user_id=? ORDER BY id DESC LIMIT 10', [$u['id']]);
?>
<?php if ($u['must_change_pw']): ?><div class="alert alert-warning">For security, please set a new password before using the software.</div><?php endif; ?>
<div class="grid grid-2">
  <form method="post" class="card" autocomplete="off"><?= csrf_field() ?><input type="hidden" name="action" value="password"><h3>Change Password</h3>
    <div class="fg"><label class="req">Current password</label><input type="password" name="current" required autofocus></div>
    <div class="fg"><label class="req">New password</label><input type="password" name="new" required minlength="6" autocomplete="new-password"></div>
    <div class="fg"><label class="req">Confirm new password</label><input type="password" name="new2" required minlength="6" autocomplete="new-password"></div>
    <p class="small muted">At least 6 characters with letters and numbers.</p>
    <button class="btn btn-primary">Change Password</button></form>
  <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="action" value="profile"><h3>My Details</h3>
    <table class="table" style="margin-bottom:10px"><tbody><tr><td>Username</td><td class="bold"><?= e($u['username']) ?></td></tr><tr><td>Role</td><td><?= e($u['role']) ?></td></tr><tr><td>Last login</td><td><?= $u['last_login'] ? dmyhm($u['last_login']) : '-' ?></td></tr><tr><td>This computer</td><td><?= e(device_name()) ?></td></tr></tbody></table>
    <div class="fg"><label class="req">Full name</label><input name="full_name" required value="<?= e($u['full_name']) ?>"></div>
    <div class="form-grid cols-2"><div class="fg"><label>Email</label><input type="email" name="email" value="<?= e($u['email']) ?>"></div><div class="fg"><label>Mobile</label><input name="mobile" value="<?= e($u['mobile']) ?>"></div></div>
    <button class="btn">Save Details</button></form>
</div>
<div class="card"><h3>My Recent Logins</h3><table class="table"><thead><tr><th>Login</th><th>Computer</th><th>IP</th><th>Last Activity</th><th>Logout</th><th>Status</th></tr></thead><tbody>
<?php foreach ($sessions as $s): ?><tr><td><?= dmyhm($s['login_at']) ?></td><td><?= e($s['device_name']) ?></td><td><?= e($s['ip_address']) ?></td><td><?= dmyhm($s['last_seen']) ?></td><td><?= $s['logout_at'] ? dmyhm($s['logout_at']) : '' ?></td><td><?= $s['is_active'] ? '<span class="badge green">Active</span>' : '<span class="badge">Closed</span>' ?></td></tr><?php endforeach; ?>
</tbody></table></div>
