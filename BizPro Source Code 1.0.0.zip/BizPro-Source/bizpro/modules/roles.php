<?php
$title = 'Roles & Permissions';
$catalog = perm_catalog();
$rid = (int)($_GET['id'] ?? 0);
if (is_post()) {
    $act = in('action');
    if ($act === 'create') {
        $name = trim((string)in('name'));
        if ($name === '' || mb_strlen($name) > 50) throw new AppException('Role name is required (max 50 characters).');
        if (val('SELECT id FROM roles WHERE name=?', [$name])) throw new AppException('Role already exists.');
        $copy = ini('copy_from');
        $new = tx(function () use ($name, $copy) {
            $id = insert('roles', ['name' => $name, 'description' => trim((string)in('description')), 'is_system' => 0]);
            if ($copy) q('INSERT INTO role_permissions (role_id, perm) SELECT ?, perm FROM role_permissions WHERE role_id=?', [$id, $copy]);
            return $id;
        });
        audit('CREATE', 'role', $new, $name, ['copied_from' => $copy]);
        flash('success', 'Role created. Now choose its permissions.');
        redirect(url('roles', ['id' => $new]));
    }
    $role = row('SELECT * FROM roles WHERE id=?', [ini('id')]);
    if (!$role) throw new AppException('Role not found.');
    if ($act === 'delete') {
        if ($role['is_system']) throw new AppException('Built-in roles cannot be deleted.');
        if (val('SELECT COUNT(*) FROM users WHERE role_id=? AND is_deleted=0', [$role['id']])) throw new AppException('Role is assigned to users. Change their role first.');
        tx(function () use ($role) { q('DELETE FROM role_permissions WHERE role_id=?', [$role['id']]); q('DELETE FROM roles WHERE id=?', [$role['id']]); });
        audit('DELETE', 'role', $role['id'], $role['name']);
        flash('success', 'Role deleted.');
        redirect(url('roles'));
    }
    if ($act === 'save') {
        if ($role['name'] === 'Admin') throw new AppException('Admin role always has full access and cannot be changed.');
        $valid = all_perm_keys();
        $perms = array_values(array_intersect(array_keys((array)($_POST['perm'] ?? [])), $valid));
        $before = array_column(rows('SELECT perm FROM role_permissions WHERE role_id=?', [$role['id']]), 'perm');
        $name = trim((string)in('name')) ?: $role['name'];
        if ($role['is_system']) $name = $role['name'];
        if (val('SELECT id FROM roles WHERE name=? AND id<>?', [$name, $role['id']])) throw new AppException('Role name already exists.');
        tx(function () use ($role, $perms, $name) {
            update('roles', ['name' => $name, 'description' => trim((string)in('description'))], 'id=?', [$role['id']]);
            q('DELETE FROM role_permissions WHERE role_id=?', [$role['id']]);
            foreach ($perms as $p) insert('role_permissions', ['role_id' => $role['id'], 'perm' => $p]);
        });
        audit('PERMISSIONS', 'role', $role['id'], $name, ['added' => array_values(array_diff($perms, $before)), 'removed' => array_values(array_diff($before, $perms))]);
        flash('success', 'Role permissions saved. Logged-in users get the change within a minute.');
        redirect(url('roles', ['id' => $role['id']]));
    }
}
$roles = rows('SELECT r.*, (SELECT COUNT(*) FROM users u WHERE u.role_id=r.id AND u.is_deleted=0) users, (SELECT COUNT(*) FROM role_permissions p WHERE p.role_id=r.id) perms FROM roles r ORDER BY r.id');
$sel = $rid ? row('SELECT * FROM roles WHERE id=?', [$rid]) : null;
$selPerms = $sel ? ($sel['name'] === 'Admin' ? all_perm_keys() : array_column(rows('SELECT perm FROM role_permissions WHERE role_id=?', [$rid]), 'perm')) : [];
?>
<div class="grid" style="grid-template-columns:340px 1fr;align-items:start">
  <div>
    <div class="card"><div class="card-head"><h3>Roles</h3><a class="btn btn-sm" href="<?= e(url('users')) ?>">Users</a></div>
      <table class="table"><tbody><?php foreach ($roles as $r): ?>
        <tr<?= $rid === (int)$r['id'] ? ' style="background:var(--primary-soft)"' : '' ?>><td><a class="bold" href="<?= e(url('roles', ['id' => $r['id']])) ?>"><?= e($r['name']) ?></a><?= $r['is_system'] ? ' <span class="badge">Built-in</span>' : '' ?><div class="small muted"><?= e($r['description']) ?></div></td>
          <td class="num small"><?= (int)$r['users'] ?> users<br><?= $r['name'] === 'Admin' ? 'all' : (int)$r['perms'] ?> perms</td></tr>
      <?php endforeach; ?></tbody></table></div>
    <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="action" value="create"><h3>New Role</h3>
      <div class="fg"><label class="req">Role name</label><input name="name" required maxlength="50"></div>
      <div class="fg"><label>Description</label><input name="description"></div>
      <div class="fg"><label>Copy permissions from</label><select name="copy_from"><?= options($roles, '', 'id', 'name', '- none -') ?></select></div>
      <button class="btn btn-primary">Create Role</button></form>
  </div>
  <div>
  <?php if ($sel): $locked = $sel['name'] === 'Admin'; ?>
    <form method="post" class="card" data-save><?= csrf_field() ?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?= (int)$sel['id'] ?>">
      <div class="card-head"><h3>Permissions: <?= e($sel['name']) ?></h3><div class="btn-row">
        <?php if (!$locked): ?><button type="button" class="btn btn-sm" onclick="document.querySelectorAll('.pchk').forEach(c=>c.checked=true)">Select all</button><button type="button" class="btn btn-sm" onclick="document.querySelectorAll('.pchk').forEach(c=>c.checked=false)">Clear all</button><button class="btn btn-primary">Save (Ctrl+S)</button><?php endif; ?></div></div>
      <?php if ($locked): ?><div class="alert alert-info">The Admin role always has every permission and cannot be restricted.</div><?php endif; ?>
      <div class="form-grid cols-2"><div class="fg"><label>Role name</label><input name="name" value="<?= e($sel['name']) ?>" <?= $sel['is_system'] ? 'readonly' : '' ?>></div><div class="fg"><label>Description</label><input name="description" value="<?= e($sel['description']) ?>" <?= $locked ? 'readonly' : '' ?>></div></div>
      <div class="perm-grid">
      <?php foreach ($catalog as $g => $perms): ?>
        <div class="perm-group"><h4><?= e($g) ?> <?php if (!$locked): ?><a href="#" class="small" onclick="event.preventDefault();const b=this.closest('.perm-group').querySelectorAll('.pchk');const on=[...b].some(c=>!c.checked);b.forEach(c=>c.checked=on)">toggle</a><?php endif; ?></h4>
        <?php foreach ($perms as $pk => $pl): ?><label class="perm-row"><input type="checkbox" class="pchk" name="perm[<?= e($pk) ?>]" value="1" <?= in_array($pk, $selPerms, true) ? 'checked' : '' ?> <?= $locked ? 'disabled' : '' ?>> <?= e($pl) ?></label><?php endforeach; ?></div>
      <?php endforeach; ?></div>
    </form>
    <?php if (!$sel['is_system']): ?><form method="post" class="card" data-confirm="Delete role <?= e($sel['name']) ?>?" data-danger="1"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= (int)$sel['id'] ?>"><button class="btn btn-danger">Delete Role</button></form><?php endif; ?>
  <?php else: ?><div class="card empty">Select a role on the left to view and edit its permissions.</div><?php endif; ?>
  </div>
</div>
