<?php
$title = 'Audit / Activity Log';
$from = ind('from', date('Y-m-d', strtotime('-7 days'))); $to = ind('to');
$user = (int)($_GET['user'] ?? 0);
$action = (string)($_GET['action'] ?? ''); $module = (string)($_GET['module'] ?? '');
$qv = trim((string)($_GET['q'] ?? ''));
$w = ['a.created_at BETWEEN ? AND ?']; $pp = [$from . ' 00:00:00', $to . ' 23:59:59'];
if ($user) { $w[] = 'a.user_id=?'; $pp[] = $user; }
if ($action !== '') { $w[] = 'a.action=?'; $pp[] = $action; }
if ($module !== '') { $w[] = 'a.module=?'; $pp[] = $module; }
if ($qv !== '') { $w[] = '(a.ref_no LIKE ? OR a.details LIKE ? OR a.device_name LIKE ? OR a.ip_address LIKE ?)'; array_push($pp, "%$qv%", "%$qv%", "%$qv%", "%$qv%"); }
[$list, $pager] = paginate('SELECT a.* FROM audit_log a WHERE ' . implode(' AND ', $w) . ' ORDER BY a.id DESC', $pp, 100);
$actions = array_column(rows('SELECT DISTINCT action FROM audit_log ORDER BY action'), 'action');
$modules = array_column(rows('SELECT DISTINCT module FROM audit_log ORDER BY module'), 'module');
$colors = ['CREATE' => 'green', 'EDIT' => 'blue', 'DELETE' => 'red', 'PURGE' => 'red', 'LOGIN_FAIL' => 'red', 'RESTORE' => 'amber', 'RESTORE_DB' => 'amber', 'FORCE_LOGOUT' => 'amber', 'PERMISSIONS' => 'amber', 'RESET_PASSWORD' => 'amber'];
$docLike = array_keys(doc_types());
?>
<div class="card">
  <div class="card-head"><h3>Audit / Activity Log</h3><div class="btn-row">
    <button class="btn" data-export="excel" data-table="#auTable" data-file="audit_<?= $from ?>_<?= $to ?>" data-title="Audit Log">Excel</button>
    <button class="btn" data-export="pdf" data-table="#auTable" data-file="audit_<?= $from ?>_<?= $to ?>" data-title="Audit Log" data-sub="<?= dmy($from) ?> to <?= dmy($to) ?>">PDF</button>
    <button class="btn" onclick="window.print()">Print</button></div></div>
  <form class="filters" method="get"><input type="hidden" name="p" value="audit">
    <div class="fg"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div><div class="fg"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
    <div class="fg"><label>User</label><select name="user"><?= options(rows('SELECT id, username name FROM users ORDER BY username'), $user, 'id', 'name', 'All') ?></select></div>
    <div class="fg"><label>Action</label><select name="action"><option value="">All</option><?php foreach ($actions as $a) echo '<option' . ($a === $action ? ' selected' : '') . '>' . e($a) . '</option>'; ?></select></div>
    <div class="fg"><label>Module</label><select name="module"><option value="">All</option><?php foreach ($modules as $m) echo '<option' . ($m === $module ? ' selected' : '') . '>' . e($m) . '</option>'; ?></select></div>
    <div class="fg grow"><label>Search (ref no, details, computer, IP)</label><input name="q" value="<?= e($qv) ?>"></div>
    <button class="btn btn-primary">Filter</button><a class="btn" href="<?= e(url('audit')) ?>">Reset</a></form>
  <div class="table-wrap"><table class="table" id="auTable"><thead><tr><th>Date &amp; Time</th><th>User</th><th>Action</th><th>Module</th><th>Reference</th><th>Details</th><th>Computer</th><th>IP</th></tr></thead><tbody>
  <?php foreach ($list as $a):
    $det = $a['details']; $j = $det !== null ? json_decode($det, true) : null;
    $short = is_array($j) ? mb_strimwidth(json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 0, 120, '...') : mb_strimwidth((string)$det, 0, 120, '...');
    $ref = e($a['ref_no']);
    if ($a['record_id'] && in_array($a['module'], $docLike, true)) $ref = '<a href="' . e(url('doc_view', ['id' => $a['record_id']])) . '">' . ($ref ?: '#' . $a['record_id']) . '</a>';
  ?>
    <tr><td class="nowrap"><?= dmyhm($a['created_at']) ?></td><td class="bold"><?= e($a['username']) ?></td><td><span class="badge <?= $colors[$a['action']] ?? '' ?>"><?= e($a['action']) ?></span></td><td><?= e($a['module']) ?></td><td><?= $ref ?></td>
      <td class="small"><?php if ($det !== null && mb_strlen((string)$det) > 120): ?><details><summary><?= e($short) ?></summary><pre style="white-space:pre-wrap;max-width:520px"><?= e(is_array($j) ? json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $det) ?></pre></details><?php else: ?><?= e($short) ?><?php endif; ?></td>
      <td class="small"><?= e($a['device_name']) ?></td><td class="small muted"><?= e($a['ip_address']) ?></td></tr>
  <?php endforeach; if (!$list) echo '<tr><td colspan="8" class="empty">No activity found.</td></tr>'; ?>
  </tbody></table></div><?= $pager ?>
</div>
