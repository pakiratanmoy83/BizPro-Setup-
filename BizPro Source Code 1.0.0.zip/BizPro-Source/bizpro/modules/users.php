<?php
$title = 'Users & Sessions';
$me = current_user();
if (is_post()) {
    $act = in('action');
    if ($act === 'kill') {
        $sid = ini('sid');
        $s = row('SELECT s.*, u.username FROM user_sessions s JOIN users u ON u.id=s.user_id WHERE s.id=?', [$sid]);
        if (!$s) throw new AppException('Session not found.');
        if ($s['session_token'] === ($_SESSION['token'] ?? '')) throw new AppException('You cannot force-logout your own current session. Use Logout.');
        q('UPDATE user_sessions SET is_active=0, logout_at=? WHERE id=?', [now(), $sid]);
        audit('FORCE_LOGOUT', 'user', $s['user_id'], $s['username'], ['device' => $s['device_name']]);
        flash('success', 'User ' . $s['username'] . ' has been logged out from ' . $s['device_name'] . '.');
    } elseif ($act === 'toggle') {
        $id = ini('id');
        if ($id === (int)$me['id']) throw new AppException('You cannot disable your own account.');
        $u = row('SELECT * FROM users WHERE id=? AND is_deleted=0', [$id]);
        if (!$u) throw new AppException('User not found.');
        $new = $u['is_active'] ? 0 : 1;
        if (!$new && val("SELECT r.name FROM roles r WHERE r.id=?", [$u['role_id']]) === 'Admin' && (int)val("SELECT COUNT(*) FROM users u JOIN roles r ON r.id=u.role_id WHERE r.name='Admin' AND u.is_active=1 AND u.is_deleted=0") <= 1) throw new AppException('At least one active Admin user is required.');
        update('users', ['is_active' => $new, 'modified_by' => $me['id'], 'modified_at' => now()], 'id=?', [$id]);
        if (!$new) q('UPDATE user_sessions SET is_active=0, logout_at=? WHERE user_id=? AND is_active=1', [now(), $id]);
        audit($new ? 'ENABLE' : 'DISABLE', 'user', $id, $u['username']);
        flash('success', 'User ' . $u['username'] . ($new ? ' enabled.' : ' disabled and logged out.'));
    } elseif ($act === 'unlock') {
        $id = ini('id');
        update('users', ['failed_logins' => 0, 'locked_until' => null], 'id=?', [$id]);
        audit('UNLOCK', 'user', $id, val('SELECT username FROM users WHERE id=?', [$id]));
        flash('success', 'User unlocked.');
    }
    redirect(url('users'));
}
$users = rows('SELECT u.*, r.name role, (SELECT COUNT(*) FROM user_sessions s WHERE s.user_id=u.id AND s.is_active=1) sessions, (SELECT COUNT(*) FROM user_permissions p WHERE p.user_id=u.id) overrides FROM users u JOIN roles r ON r.id=u.role_id WHERE u.is_deleted=0 ORDER BY u.id');
$timeout = (int)setting('session_timeout_min', '480');
$sess = rows('SELECT s.*, u.username, u.full_name FROM user_sessions s JOIN users u ON u.id=s.user_id WHERE s.is_active=1' . ($timeout > 0 ? ' AND s.last_seen >= ?' : '') . ' ORDER BY s.last_seen DESC', $timeout > 0 ? [date('Y-m-d H:i:s', time() - $timeout * 60)] : []);
?>
<div class="card">
  <div class="card-head"><h3>Users</h3><div class="btn-row"><a class="btn btn-primary" href="<?= e(url('user')) ?>">+ New User</a><a class="btn" href="<?= e(url('roles')) ?>">Roles &amp; Permissions</a>
    <button class="btn" data-export="excel" data-table="#uTable" data-file="users">Excel</button></div></div>
  <div class="table-wrap"><table class="table" id="uTable"><thead><tr><th>Username</th><th>Full Name</th><th>Role</th><th>Mobile</th><th>Status</th><th>Last Login</th><th class="num">Online</th><th class="no-export"></th></tr></thead><tbody>
  <?php foreach ($users as $u): $locked = $u['locked_until'] && strtotime($u['locked_until']) > time(); ?>
    <tr><td><a href="<?= e(url('user', ['id' => $u['id']])) ?>" class="bold"><?= e($u['username']) ?></a><?= $u['id'] == $me['id'] ? ' <span class="badge blue">You</span>' : '' ?></td><td><?= e($u['full_name']) ?></td>
      <td><?= e($u['role']) ?><?= $u['overrides'] ? ' <span class="badge amber" title="Individual permission overrides">+' . (int)$u['overrides'] . ' custom</span>' : '' ?></td><td><?= e($u['mobile']) ?></td>
      <td><?= $u['is_active'] ? '<span class="badge green">Active</span>' : '<span class="badge red">Disabled</span>' ?><?= $locked ? ' <span class="badge amber">Locked</span>' : '' ?><?= $u['must_change_pw'] ? ' <span class="badge">Must change PW</span>' : '' ?></td>
      <td><?= $u['last_login'] ? dmyhm($u['last_login']) : '-' ?></td><td class="num"><?= (int)$u['sessions'] ?></td>
      <td class="actions no-export"><a class="btn btn-sm" href="<?= e(url('user', ['id' => $u['id']])) ?>">Edit</a>
        <?php if ($u['id'] != $me['id']): ?><form method="post" class="inline" data-confirm="<?= $u['is_active'] ? 'Disable' : 'Enable' ?> user <?= e($u['username']) ?>?"><?= csrf_field() ?><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= $u['id'] ?>"><button class="btn btn-sm"><?= $u['is_active'] ? 'Disable' : 'Enable' ?></button></form><?php endif; ?>
        <?php if ($locked || $u['failed_logins'] > 0): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="unlock"><input type="hidden" name="id" value="<?= $u['id'] ?>"><button class="btn btn-sm">Unlock</button></form><?php endif; ?></td></tr>
  <?php endforeach; ?></tbody></table></div>
</div>
<div class="card">
  <div class="card-head"><h3>Active Sessions (logged-in computers)</h3></div>
  <div class="table-wrap"><table class="table"><thead><tr><th>User</th><th>Computer</th><th>IP Address</th><th>Login</th><th>Last Activity</th><th>Browser</th><th></th></tr></thead><tbody>
  <?php foreach ($sess as $s): $mine = $s['session_token'] === ($_SESSION['token'] ?? ''); ?>
    <tr><td class="bold"><?= e($s['username']) ?></td><td><?= e($s['device_name']) ?></td><td><?= e($s['ip_address']) ?></td><td><?= dmyhm($s['login_at']) ?></td><td><?= dmyhm($s['last_seen']) ?></td><td class="small muted" style="max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e($s['user_agent']) ?></td>
      <td><?php if ($mine): ?><span class="badge blue">This session</span><?php else: ?><form method="post" class="inline" data-confirm="Force logout <?= e($s['username']) ?> from <?= e($s['device_name']) ?>?" data-danger="1"><?= csrf_field() ?><input type="hidden" name="action" value="kill"><input type="hidden" name="sid" value="<?= $s['id'] ?>"><button class="btn btn-sm btn-danger">Force Logout</button></form><?php endif; ?></td></tr>
  <?php endforeach; if (!$sess) echo '<tr><td colspan="7" class="empty">No active sessions.</td></tr>'; ?></tbody></table></div>
</div>
