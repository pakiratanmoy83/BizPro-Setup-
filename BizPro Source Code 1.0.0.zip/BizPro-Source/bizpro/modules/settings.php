<?php
$title = 'Settings';
$full = can('settings.manage');
$tabs = $full ? ['business' => 'Business', 'invoice' => 'Invoice & Printer', 'numbering' => 'Number Series', 'tax' => 'Tax & Stock Rules', 'security' => 'Security & Lock', 'database' => 'Database / Network', 'backup' => 'Backup'] : ['invoice' => 'Invoice & Printer'];
$tab = $_GET['tab'] ?? array_key_first($tabs);
if (!isset($tabs[$tab])) $tab = array_key_first($tabs);
if ($tab === 'backup') { if (can('backup.manage')) redirect(url('backup')); throw new AppException('Backup requires backup permission.'); }

$fields = [
    'business' => ['business_name', 'business_address', 'business_state', 'business_phone', 'business_email', 'business_gstin', 'fy_start', 'fy_end', 'currency_symbol'],
    'invoice' => ['invoice_format', 'thermal_width', 'invoice_terms', 'invoice_footer', 'auto_print', 'printer_name'],
    'tax' => ['default_gst', 'tax_label', 'round_off', 'allow_negative_stock', 'block_negative_cash', 'update_purchase_rate', 'product_code_prefix', 'barcode_prefix'],
    'security' => ['session_timeout_min', 'lock_date', 'dashboard_refresh_sec'],
];
$checkboxes = ['auto_print', 'round_off', 'allow_negative_stock', 'block_negative_cash', 'update_purchase_rate'];

if (is_post()) {
    $sec = in('section');
    if (!isset($tabs[$sec])) throw new AppException('Access denied.');
    if ($sec === 'numbering') {
        $before = rows('SELECT * FROM number_series');
        tx(function () {
            foreach ((array)($_POST['ns'] ?? []) as $k => $v) {
                $cur = row('SELECT * FROM number_series WHERE skey=? FOR UPDATE', [$k]);
                if (!$cur) continue;
                $prefix = substr(preg_replace('/[^A-Za-z0-9\/_-]/', '', (string)($v['prefix'] ?? '')), 0, 15);
                $next = max(1, (int)($v['next_no'] ?? 1));
                $pad = max(1, min(10, (int)($v['pad'] ?? 5)));
                update('number_series', ['prefix' => $prefix, 'next_no' => $next, 'pad' => $pad], 'skey=?', [$k]);
            }
        });
        audit('EDIT', 'settings', null, 'number_series', ['before' => $before]);
        flash('success', 'Number series saved. New documents will use the new settings.');
        redirect(url('settings', ['tab' => $sec]));
    }
    if ($sec === 'database') {
        $cfg = ['db_host' => trim((string)in('db_host')), 'db_port' => ini('db_port') ?: 3306, 'db_name' => trim((string)in('db_name')), 'db_user' => trim((string)in('db_user')), 'db_pass' => (string)in('db_pass')];
        if ($cfg['db_pass'] === '') $cfg['db_pass'] = $CONFIG['db_pass'];
        try {
            $t = new PDO("mysql:host={$cfg['db_host']};port={$cfg['db_port']};dbname={$cfg['db_name']};charset=utf8mb4", $cfg['db_user'], $cfg['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 5]);
            $ok = $t->query("SHOW TABLES LIKE 'documents'")->fetch();
            if (!$ok) throw new Exception('Connected, but BizPro tables were not found in this database.');
        } catch (Throwable $ex) { throw new AppException('Connection test failed: ' . $ex->getMessage()); }
        if (in('test_only')) { flash('success', 'Connection successful to ' . $cfg['db_host'] . ':' . $cfg['db_port'] . '/' . $cfg['db_name']); redirect(url('settings', ['tab' => $sec])); }
        $new = array_merge($CONFIG, $cfg);
        if (@file_put_contents(BASE_DIR . '/config/config.php', "<?php\nreturn " . var_export($new, true) . ";\n") === false) throw new AppException('Cannot write config/config.php');
        audit('EDIT', 'settings', null, 'database', ['host' => $cfg['db_host'], 'db' => $cfg['db_name'], 'user' => $cfg['db_user']]);
        flash('success', 'Database settings saved.');
        redirect(url('settings', ['tab' => $sec]));
    }
    $changes = [];
    $old = settings_all(true);
    $vals = [];
    foreach ($fields[$sec] as $k) $vals[$k] = in_array($k, $checkboxes) ? (in($k) ? '1' : '0') : trim((string)in($k, ''));
    if ($sec === 'business') {
        if ($vals['business_name'] === '') throw new AppException('Business name is required.');
        if ($vals['business_gstin'] !== '' && !preg_match('/^[0-9]{2}[A-Z0-9]{13}$/', strtoupper($vals['business_gstin']))) throw new AppException('GSTIN must be 15 characters (e.g. 19ABCDE1234F1Z5).');
        $vals['business_gstin'] = strtoupper($vals['business_gstin']);
        if ($vals['business_email'] !== '' && !filter_var($vals['business_email'], FILTER_VALIDATE_EMAIL)) throw new AppException('Invalid email.');
        foreach (['fy_start', 'fy_end'] as $k) if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $vals[$k])) throw new AppException('Financial year dates are required.');
        if ($vals['fy_end'] <= $vals['fy_start']) throw new AppException('Financial year end must be after start.');
        if (!empty($_FILES['logo']['name'])) {
            $f = $_FILES['logo'];
            if ($f['error'] !== UPLOAD_ERR_OK) throw new AppException('Logo upload failed.');
            if ($f['size'] > 2 * 1024 * 1024) throw new AppException('Logo must be under 2 MB.');
            $info = @getimagesize($f['tmp_name']);
            $ext = [IMAGETYPE_PNG => 'png', IMAGETYPE_JPEG => 'jpg', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'][$info[2] ?? 0] ?? null;
            if (!$ext) throw new AppException('Logo must be a PNG, JPG, GIF or WEBP image.');
            if (!is_dir(BASE_DIR . '/uploads')) @mkdir(BASE_DIR . '/uploads', 0775, true);
            $name = 'uploads/logo_' . time() . '.' . $ext;
            if (!move_uploaded_file($f['tmp_name'], BASE_DIR . '/' . $name)) throw new AppException('Could not save logo.');
            if (($old['business_logo'] ?? '') && is_file(BASE_DIR . '/' . $old['business_logo'])) @unlink(BASE_DIR . '/' . $old['business_logo']);
            $vals['business_logo'] = $name;
        } elseif (in('remove_logo')) {
            if (($old['business_logo'] ?? '') && is_file(BASE_DIR . '/' . $old['business_logo'])) @unlink(BASE_DIR . '/' . $old['business_logo']);
            $vals['business_logo'] = '';
        }
    }
    if ($sec === 'invoice') {
        if (!in_array($vals['invoice_format'], ['A4', 'thermal'])) $vals['invoice_format'] = 'A4';
        if (!in_array($vals['thermal_width'], ['58', '80'])) $vals['thermal_width'] = '80';
    }
    if ($sec === 'tax') {
        $vals['default_gst'] = (string)max(0, min(100, (float)$vals['default_gst']));
        if ($vals['product_code_prefix'] !== '') q('UPDATE number_series SET prefix=? WHERE skey=?', [$vals['product_code_prefix'], 'PROD']);
    }
    if ($sec === 'security') {
        $vals['session_timeout_min'] = (string)max(0, (int)$vals['session_timeout_min']);
        $vals['dashboard_refresh_sec'] = (string)max(0, (int)$vals['dashboard_refresh_sec']);
        if ($vals['lock_date'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $vals['lock_date'])) throw new AppException('Invalid lock date.');
    }
    foreach ($vals as $k => $v) if ((string)($old[$k] ?? '') !== (string)$v) { $changes[$k] = [$old[$k] ?? null, $v]; set_setting($k, $v); }
    settings_all(true);
    if ($changes) audit('EDIT', 'settings', null, $sec, $changes);
    flash('success', $changes ? 'Settings saved.' : 'No changes.');
    redirect(url('settings', ['tab' => $sec]));
}
$S = settings_all(true);
$v = fn($k) => e($S[$k] ?? '');
$chk = fn($k) => ($S[$k] ?? '0') === '1' ? 'checked' : '';
$states = ['Andaman and Nicobar Islands', 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'];
?>
<div class="tabs"><?php foreach ($tabs as $k => $l): ?><a class="tab <?= $k === $tab ? 'active' : '' ?>" href="<?= e(url('settings', ['tab' => $k])) ?>"><?= e($l) ?></a><?php endforeach; ?></div>

<?php if ($tab === 'business'): ?>
<form method="post" class="card" enctype="multipart/form-data" data-save><?= csrf_field() ?><input type="hidden" name="section" value="business">
  <h3>Business Details (printed on invoices)</h3>
  <div class="form-grid cols-3">
    <div class="fg"><label class="req">Business Name</label><input name="business_name" required value="<?= $v('business_name') ?>"></div>
    <div class="fg"><label>Phone</label><input name="business_phone" value="<?= $v('business_phone') ?>"></div>
    <div class="fg"><label>Email</label><input type="email" name="business_email" value="<?= $v('business_email') ?>"></div>
    <div class="fg span-2"><label>Address</label><textarea name="business_address" rows="2"><?= $v('business_address') ?></textarea></div>
    <div class="fg"><label>State (for CGST/SGST vs IGST)</label><select name="business_state"><?php foreach ($states as $s) echo '<option' . (($S['business_state'] ?? '') === $s ? ' selected' : '') . '>' . e($s) . '</option>'; ?></select></div>
    <div class="fg"><label>GSTIN</label><input name="business_gstin" maxlength="15" value="<?= $v('business_gstin') ?>" style="text-transform:uppercase"></div>
    <div class="fg"><label>Financial Year Start</label><input type="date" name="fy_start" value="<?= $v('fy_start') ?>"></div>
    <div class="fg"><label>Financial Year End</label><input type="date" name="fy_end" value="<?= $v('fy_end') ?>"></div>
    <div class="fg"><label>Currency Symbol</label><input name="currency_symbol" maxlength="5" value="<?= $v('currency_symbol') ?>"></div>
    <div class="fg"><label>Logo (PNG/JPG, max 2 MB)</label><input type="file" name="logo" accept="image/*">
      <?php if (!empty($S['business_logo'])): ?><div style="margin-top:6px"><img src="<?= $v('business_logo') ?>" style="max-height:60px;border:1px solid var(--border);padding:3px;background:#fff"> <label class="check"><input type="checkbox" name="remove_logo" value="1"> Remove logo</label></div><?php endif; ?></div>
  </div>
  <button class="btn btn-primary">Save (Ctrl+S)</button></form>

<?php elseif ($tab === 'invoice'): ?>
<form method="post" class="card" data-save><?= csrf_field() ?><input type="hidden" name="section" value="invoice">
  <h3>Invoice &amp; Printer</h3>
  <div class="form-grid cols-3">
    <div class="fg"><label>Default invoice format</label><select name="invoice_format"><option value="A4" <?= ($S['invoice_format'] ?? '') === 'A4' ? 'selected' : '' ?>>A4 (laser / inkjet)</option><option value="thermal" <?= ($S['invoice_format'] ?? '') === 'thermal' ? 'selected' : '' ?>>Thermal receipt</option></select></div>
    <div class="fg"><label>Thermal paper width</label><select name="thermal_width"><option value="80" <?= ($S['thermal_width'] ?? '') === '80' ? 'selected' : '' ?>>80 mm</option><option value="58" <?= ($S['thermal_width'] ?? '') === '58' ? 'selected' : '' ?>>58 mm</option></select></div>
    <div class="fg"><label>Printer name (note)</label><input name="printer_name" value="<?= $v('printer_name') ?>" placeholder="e.g. EPSON TM-T82"><div class="small muted">Select this printer as default in Windows, or pick it in the print dialog.</div></div>
    <div class="fg span-2"><label>Terms &amp; Conditions</label><textarea name="invoice_terms" rows="4"><?= $v('invoice_terms') ?></textarea></div>
    <div class="fg"><label>Invoice footer</label><textarea name="invoice_footer" rows="4"><?= $v('invoice_footer') ?></textarea></div>
    <div class="fg"><label class="check"><input type="checkbox" name="auto_print" value="1" <?= $chk('auto_print') ?>> Open print dialog automatically after saving a bill</label></div>
  </div>
  <div class="btn-row"><button class="btn btn-primary">Save (Ctrl+S)</button>
  <?php $lastSale = val("SELECT id FROM documents WHERE dtype='SALE' AND is_deleted=0 ORDER BY id DESC LIMIT 1"); if ($lastSale): ?><a class="btn" target="_blank" href="print.php?id=<?= (int)$lastSale ?>&fmt=A4&noprint=1">Preview A4</a><a class="btn" target="_blank" href="print.php?id=<?= (int)$lastSale ?>&fmt=thermal&noprint=1">Preview Thermal</a><?php endif; ?></div></form>

<?php elseif ($tab === 'numbering'): $ns = rows('SELECT * FROM number_series ORDER BY skey');
$labels = ['SALE' => 'Sales Invoice', 'PUR' => 'Purchase', 'SRET' => 'Sales Return', 'PRET' => 'Purchase Return', 'RCPT' => 'Customer Receipt', 'PAY' => 'Supplier Payment', 'EXP' => 'Expense', 'ADJ' => 'Stock Adjustment', 'CB' => 'Cash/Bank Entry', 'CUST' => 'Customer Code', 'SUPP' => 'Supplier Code', 'PROD' => 'Product Code']; ?>
<form method="post" class="card" data-save><?= csrf_field() ?><input type="hidden" name="section" value="numbering">
  <h3>Invoice / Document Number Series</h3>
  <p class="muted small">Numbers are generated on the server inside a locked transaction, so two computers never get the same number. Tip: add the year to the prefix at the start of a new financial year, e.g. INV/26-27/.</p>
  <table class="table"><thead><tr><th>Document</th><th>Prefix</th><th>Next Number</th><th>Digits</th><th>Preview</th></tr></thead><tbody>
  <?php foreach ($ns as $n): ?><tr><td><?= e($labels[$n['skey']] ?? $n['skey']) ?></td>
    <td><input name="ns[<?= e($n['skey']) ?>][prefix]" value="<?= e($n['prefix']) ?>" maxlength="15" class="ns-in"></td>
    <td><input type="number" min="1" name="ns[<?= e($n['skey']) ?>][next_no]" value="<?= (int)$n['next_no'] ?>" class="ns-in"></td>
    <td><input type="number" min="1" max="10" name="ns[<?= e($n['skey']) ?>][pad]" value="<?= (int)$n['pad'] ?>" class="ns-in" style="width:80px"></td>
    <td class="bold ns-prev"></td></tr><?php endforeach; ?></tbody></table>
  <button class="btn btn-primary">Save (Ctrl+S)</button></form>
<script>
function nsPrev(){ document.querySelectorAll('.ns-prev').forEach(td => { const i = td.parentElement.querySelectorAll('input'); td.textContent = i[0].value + String(i[1].value || 1).padStart(+i[2].value || 1, '0'); }); }
document.querySelectorAll('.ns-in').forEach(x => x.addEventListener('input', nsPrev)); nsPrev();
</script>

<?php elseif ($tab === 'tax'): ?>
<form method="post" class="card" data-save><?= csrf_field() ?><input type="hidden" name="section" value="tax">
  <h3>Tax &amp; Stock Rules</h3>
  <div class="form-grid cols-3">
    <div class="fg"><label>Default GST % for new products</label><select name="default_gst"><?php foreach ([0, 0.25, 3, 5, 12, 18, 28] as $g) echo '<option value="' . $g . '"' . ((float)($S['default_gst'] ?? 18) == $g ? ' selected' : '') . '>' . $g . '%</option>'; ?></select></div>
    <div class="fg"><label>Tax label</label><input name="tax_label" value="<?= $v('tax_label') ?>"></div>
    <div class="fg"><label>Product code prefix</label><input name="product_code_prefix" value="<?= $v('product_code_prefix') ?>" maxlength="6"></div>
    <div class="fg"><label>Auto barcode prefix</label><input name="barcode_prefix" value="<?= $v('barcode_prefix') ?>" maxlength="6"></div>
  </div>
  <label class="check"><input type="checkbox" name="round_off" value="1" <?= $chk('round_off') ?>> Round off bill totals to nearest rupee</label>
  <label class="check"><input type="checkbox" name="allow_negative_stock" value="1" <?= $chk('allow_negative_stock') ?>> Allow selling more than available stock (negative stock)</label>
  <label class="check"><input type="checkbox" name="block_negative_cash" value="1" <?= $chk('block_negative_cash') ?>> Block payments that make the cash balance negative</label>
  <label class="check"><input type="checkbox" name="update_purchase_rate" value="1" <?= $chk('update_purchase_rate') ?>> Update product purchase rate from the latest purchase</label>
  <button class="btn btn-primary">Save (Ctrl+S)</button></form>

<?php elseif ($tab === 'security'): ?>
<form method="post" class="card" data-save><?= csrf_field() ?><input type="hidden" name="section" value="security">
  <h3>Security &amp; Period Lock</h3>
  <div class="form-grid cols-3">
    <div class="fg"><label>Auto logout after inactivity (minutes, 0 = never)</label><input type="number" min="0" name="session_timeout_min" value="<?= $v('session_timeout_min') ?>"></div>
    <div class="fg"><label>Lock transactions on or before</label><input type="date" name="lock_date" value="<?= $v('lock_date') ?>"><div class="small muted">No user can add, edit or delete entries dated on/before this date (e.g. after closing a year or filing GST).</div></div>
    <div class="fg"><label>Dashboard auto-refresh (seconds, 0 = off)</label><input type="number" min="0" name="dashboard_refresh_sec" value="<?= $v('dashboard_refresh_sec') ?>"></div>
  </div>
  <p class="small muted">Passwords are hashed (bcrypt). 5 wrong passwords lock the account for 10 minutes. Deleted documents go to the Recycle Bin and can only be permanently removed by an authorised Admin.</p>
  <button class="btn btn-primary">Save (Ctrl+S)</button></form>

<?php elseif ($tab === 'database'):
  $ver = val('SELECT VERSION()');
  $size = val('SELECT ROUND(SUM(data_length+index_length)/1024/1024,2) FROM information_schema.tables WHERE table_schema=DATABASE()');
  $conns = rows("SELECT host, COUNT(*) n FROM information_schema.processlist WHERE db=DATABASE() GROUP BY host"); ?>
<div class="grid grid-2">
<form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="section" value="database">
  <h3>Central Database Connection</h3>
  <div class="alert alert-info">All computers connect to this one database on the server PC. Client PCs only need the browser shortcut pointing to the server - they do not have their own database.</div>
  <div class="form-grid cols-2">
    <div class="fg"><label>MySQL/MariaDB host</label><input name="db_host" value="<?= e($CONFIG['db_host']) ?>"></div>
    <div class="fg"><label>Port</label><input type="number" name="db_port" value="<?= (int)$CONFIG['db_port'] ?>"></div>
    <div class="fg"><label>Database name</label><input name="db_name" value="<?= e($CONFIG['db_name']) ?>"></div>
    <div class="fg"><label>Database user</label><input name="db_user" value="<?= e($CONFIG['db_user']) ?>"></div>
    <div class="fg"><label>Password (blank = keep current)</label><input type="password" name="db_pass" autocomplete="new-password"></div>
  </div>
  <div class="btn-row"><button class="btn" name="test_only" value="1">Test Connection</button><button class="btn btn-primary">Save</button></div></form>
<div class="card"><h3>Server Information</h3>
  <table class="table"><tbody>
    <tr><td>Application</td><td><?= APP_NAME ?> v<?= APP_VERSION ?></td></tr>
    <tr><td>Database server</td><td><?= e($ver) ?></td></tr>
    <tr><td>Database size</td><td><?= e($size) ?> MB</td></tr>
    <tr><td>PHP version</td><td><?= PHP_VERSION ?></td></tr>
    <tr><td>Server address for clients</td><td class="bold"><?= e(($_SERVER['SERVER_NAME'] ?? '') . ':' . ($_SERVER['SERVER_PORT'] ?? '')) ?></td></tr>
    <tr><td>This computer</td><td><?= e(device_name()) ?> (<?= e(client_ip()) ?>)</td></tr>
    <?php foreach ($conns as $c): ?><tr><td>DB connections</td><td><?= e($c['host']) ?>: <?= (int)$c['n'] ?></td></tr><?php endforeach; ?>
  </tbody></table></div>
</div>
<?php endif; ?>
