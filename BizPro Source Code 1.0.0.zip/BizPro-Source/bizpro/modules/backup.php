<?php
$title = 'Backup & Restore';
if (!empty($_GET['download'])) {
    $b = row('SELECT * FROM backups WHERE id=?', [(int)$_GET['download']]);
    if (!$b || !is_file($b['filepath'])) throw new AppException('Backup file not found on server.');
    audit('DOWNLOAD', 'backup', $b['id'], $b['filename']);
    while (ob_get_level()) ob_end_clean();
    header('Content-Type: application/gzip');
    header('Content-Disposition: attachment; filename="' . basename($b['filename']) . '"');
    header('Content-Length: ' . filesize($b['filepath']));
    readfile($b['filepath']);
    exit;
}
if (is_post()) {
    $act = in('action');
    if ($act === 'backup') {
        $r = create_backup('MANUAL');
        flash('success', 'Backup created: ' . basename($r['file']) . ' (' . number_format($r['size'] / 1024, 1) . ' KB)');
    } elseif ($act === 'settings') {
        $dir = rtrim(str_replace('\\', '/', trim((string)in('backup_dir'))), '/');
        if ($dir === '') $dir = str_replace('\\', '/', BASE_DIR) . '/backups';
        if (!is_dir($dir) && !@mkdir($dir, 0775, true)) throw new AppException('Cannot create folder: ' . $dir . ' (path is on the server PC).');
        if (!is_writable($dir)) throw new AppException('Folder is not writable: ' . $dir);
        set_setting('backup_dir', $dir);
        set_setting('auto_backup', in('auto_backup') ? '1' : '0');
        set_setting('auto_backup_hours', (string)max(1, min(720, ini('auto_backup_hours') ?: 24)));
        set_setting('backup_keep', (string)max(0, ini('backup_keep')));
        audit('EDIT', 'settings', null, 'backup', ['dir' => $dir, 'auto' => in('auto_backup') ? 1 : 0]);
        flash('success', 'Backup settings saved.');
    } elseif ($act === 'restore' || $act === 'restore_upload') {
        if (strtoupper(trim((string)in('confirm_text'))) !== 'RESTORE') throw new AppException('Type RESTORE in the confirmation box to continue.');
        if ($act === 'restore') {
            $b = row('SELECT * FROM backups WHERE id=?', [ini('id')]);
            if (!$b) throw new AppException('Backup not found.');
            $file = $b['filepath'];
        } else {
            $up = $_FILES['file'] ?? null;
            if (!$up || $up['error'] !== UPLOAD_ERR_OK) throw new AppException('Upload failed. Check the file size limit (upload_max_filesize).');
            if (!preg_match('/\.(sql|gz)$/i', $up['name'])) throw new AppException('Select a .sql or .sql.gz BizPro backup file.');
            $file = backup_dir() . '/uploaded_' . date('Ymd_His') . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $up['name']);
            if (!move_uploaded_file($up['tmp_name'], $file)) throw new AppException('Could not save uploaded file.');
        }
        $keep = $_SESSION['token'] ?? '';
        $n = restore_backup($file);
        settings_all(true);
        // keep current admin logged in after restore if their session row survived; otherwise force re-login
        if (!val('SELECT id FROM user_sessions WHERE session_token=? AND is_active=1', [$keep])) {
            destroy_session();
            session_start();
            flash('success', 'Database restored (' . $n . ' statements). Please log in again.');
            redirect('login.php');
        }
        flash('success', 'Database restored successfully (' . $n . ' statements). A safety backup of the previous data was created first.');
    } elseif ($act === 'delete') {
        $b = row('SELECT * FROM backups WHERE id=?', [ini('id')]);
        if ($b) { if (is_file($b['filepath'])) @unlink($b['filepath']); q('DELETE FROM backups WHERE id=?', [$b['id']]); audit('DELETE', 'backup', $b['id'], $b['filename']); }
        flash('success', 'Backup deleted.');
    }
    redirect(url('backup'));
}
$list = rows('SELECT * FROM backups ORDER BY id DESC LIMIT 300');
$dir = setting('backup_dir', str_replace('\\', '/', BASE_DIR) . '/backups');
$last = setting('last_auto_backup', '');
$maxUp = ini_get('upload_max_filesize');
?>
<div class="grid grid-3">
  <div class="stat"><div class="label">Last automatic backup</div><div class="value" style="font-size:1.1rem"><?= $last ? dmyhm($last) : 'Never' ?></div><div class="sub">Every <?= e(setting('auto_backup_hours', '24')) ?> hours <?= setting('auto_backup', '1') === '1' ? '(enabled)' : '(disabled)' ?></div></div>
  <div class="stat blue"><div class="label">Backups stored</div><div class="value"><?= count($list) ?></div><div class="sub"><?= e($dir) ?></div></div>
  <div class="stat green"><div class="label">Manual backup</div><form method="post" style="margin-top:6px"><?= csrf_field() ?><input type="hidden" name="action" value="backup"><button class="btn btn-primary">Backup Now</button></form></div>
</div>
<div class="grid grid-2">
  <form method="post" class="card"><?= csrf_field() ?><input type="hidden" name="action" value="settings"><h3>Backup Settings</h3>
    <div class="fg"><label>Backup folder on server PC</label><input name="backup_dir" value="<?= e($dir) ?>" placeholder="e.g. D:/BizProBackups"><div class="small muted">Use a different drive or a USB / network folder for safety. Path is on the server computer.</div></div>
    <div class="form-grid cols-3">
      <div class="fg"><label class="check"><input type="checkbox" name="auto_backup" value="1" <?= setting('auto_backup', '1') === '1' ? 'checked' : '' ?>> Automatic backup</label></div>
      <div class="fg"><label>Every (hours)</label><input type="number" name="auto_backup_hours" min="1" max="720" value="<?= e(setting('auto_backup_hours', '24')) ?>"></div>
      <div class="fg"><label>Keep last N auto backups (0 = all)</label><input type="number" name="backup_keep" min="0" value="<?= e(setting('backup_keep', '30')) ?>"></div>
    </div>
    <p class="small muted">Automatic backups run in the background when any user is working, and also by the Windows scheduled task installed on the server (daily at 11 PM).</p>
    <button class="btn btn-primary">Save Settings</button></form>
  <form method="post" class="card" enctype="multipart/form-data" data-confirm="Restore database from the uploaded file? ALL current data will be replaced." data-danger="1"><?= csrf_field() ?><input type="hidden" name="action" value="restore_upload"><h3>Restore from File</h3>
    <div class="alert alert-warning">Restoring replaces all current data. A safety backup of the current data is created automatically first. Other users should log out.</div>
    <div class="fg"><label>Backup file (.sql.gz, max <?= e($maxUp) ?>)</label><input type="file" name="file" accept=".gz,.sql" required></div>
    <div class="fg"><label>Type RESTORE to confirm</label><input name="confirm_text" required autocomplete="off"></div>
    <button class="btn btn-danger">Upload &amp; Restore</button></form>
</div>
<div class="card"><div class="card-head"><h3>Backup History</h3></div>
  <div class="table-wrap"><table class="table"><thead><tr><th>Date &amp; Time</th><th>File</th><th>Type</th><th class="num">Size</th><th>By</th><th>Status</th><th></th></tr></thead><tbody>
  <?php foreach ($list as $b): $exists = is_file($b['filepath']); ?>
    <tr><td class="nowrap"><?= dmyhm($b['created_at']) ?></td><td class="small"><?= e($b['filename']) ?></td><td><span class="badge <?= ['MANUAL' => 'blue', 'AUTO' => 'green', 'SAFETY' => 'amber', 'RESTORE' => 'red'][$b['btype']] ?? '' ?>"><?= e($b['btype']) ?></span></td>
      <td class="num"><?= number_format($b['size_bytes'] / 1024, 1) ?> KB</td><td><?= e($b['created_by_name']) ?></td><td><?= $exists ? '<span class="badge green">Available</span>' : '<span class="badge red">File missing</span>' ?></td>
      <td class="actions nowrap"><?php if ($exists && $b['btype'] !== 'RESTORE'): ?><a class="btn btn-sm" href="<?= e(url('backup', ['download' => $b['id']])) ?>">Download</a>
        <button type="button" class="btn btn-sm btn-danger" onclick="restoreB(<?= (int)$b['id'] ?>, <?= e(json_encode($b['filename'])) ?>)">Restore</button><?php endif; ?>
        <?php if ($b['btype'] !== 'RESTORE'): ?><form method="post" class="inline" data-confirm="Delete this backup file permanently?" data-danger="1"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $b['id'] ?>"><button class="btn btn-sm">Delete</button></form><?php endif; ?></td></tr>
  <?php endforeach; if (!$list) echo '<tr><td colspan="7" class="empty">No backups yet.</td></tr>'; ?></tbody></table></div></div>
<form method="post" id="restoreForm" style="display:none"><?= csrf_field() ?><input type="hidden" name="action" value="restore"><input type="hidden" name="id"><input type="hidden" name="confirm_text"></form>
<script>
async function restoreB(id, name) {
  const v = await BP.confirm('Restore database from ' + name + '? ALL current data will be replaced by this backup. Type RESTORE to confirm.', { title: 'Restore Database', ok: 'Restore', danger: true, input: 'Type RESTORE' });
  if (v === false || v === null) return;
  const f = document.getElementById('restoreForm');
  f.elements['id'].value = id; f.elements['confirm_text'].value = typeof v === 'string' ? v : '';
  BP.toast('Restoring... please wait', 'info');
  f.submit();
}
</script>
