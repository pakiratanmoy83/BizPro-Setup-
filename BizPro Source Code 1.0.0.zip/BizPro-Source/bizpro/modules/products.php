<?php
$title = 'Products';
$qv = trim((string)($_GET['q'] ?? ''));
$cat = (int)($_GET['cat'] ?? 0);
$brand = (int)($_GET['brand'] ?? 0);
$status = $_GET['status'] ?? '';
$where = ['p.is_deleted=0']; $pp = [];
if ($qv !== '') { $where[] = '(p.name LIKE ? OR p.code LIKE ? OR p.barcode=? OR p.hsn_code LIKE ?)'; array_push($pp, "%$qv%", "%$qv%", $qv, "$qv%"); }
if ($cat) { $where[] = 'p.category_id=?'; $pp[] = $cat; }
if ($brand) { $where[] = 'p.brand_id=?'; $pp[] = $brand; }
if ($status === 'active') $where[] = 'p.is_active=1';
if ($status === 'inactive') $where[] = 'p.is_active=0';
if ($status === 'low') $where[] = 'p.current_stock>0 AND p.current_stock<=p.min_stock';
if ($status === 'out') $where[] = 'p.current_stock<=0';
$sql = 'SELECT p.*, c.name category, b.name brand, u.name unit FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN brands b ON b.id=p.brand_id LEFT JOIN units u ON u.id=p.unit_id WHERE ' . implode(' AND ', $where) . ' ORDER BY p.name';
[$list, $pager] = paginate($sql, $pp, 50);
$cats = rows('SELECT id, name FROM categories WHERE is_deleted=0 ORDER BY name');
$brands = rows('SELECT id, name FROM brands WHERE is_deleted=0 ORDER BY name');
?>
<div class="card">
  <div class="card-head"><h3>Product Master</h3>
    <div class="btn-row">
      <?php if (can('product.add')): ?><a class="btn btn-primary" href="<?= e(url('product')) ?>">+ Add Product</a><?php endif; ?>
      <button class="btn" data-export="excel" data-table="#prodTable" data-file="products" data-title="Products">Excel</button>
      <button class="btn" data-export="pdf" data-table="#prodTable" data-file="products" data-title="Product List">PDF</button>
      <button class="btn" onclick="window.print()">Print</button>
    </div>
  </div>
  <form class="filters" method="get">
    <input type="hidden" name="p" value="products">
    <div class="fg grow"><label>Search (name / code / barcode / HSN)</label><input name="q" value="<?= e($qv) ?>" autofocus placeholder="Scan barcode or type..."></div>
    <div class="fg"><label>Category</label><select name="cat"><?= options($cats, $cat, 'id', 'name', 'All categories') ?></select></div>
    <div class="fg"><label>Brand</label><select name="brand"><?= options($brands, $brand, 'id', 'name', 'All brands') ?></select></div>
    <div class="fg"><label>Status</label><select name="status"><?php foreach (['' => 'All', 'active' => 'Active', 'inactive' => 'Inactive', 'low' => 'Low stock', 'out' => 'Out of stock'] as $k => $l) echo '<option value="' . $k . '"' . ($status === $k ? ' selected' : '') . '>' . $l . '</option>'; ?></select></div>
    <button class="btn btn-primary">Filter</button><a class="btn" href="<?= e(url('products')) ?>">Reset</a>
  </form>
  <div class="table-wrap"><table class="table" id="prodTable">
    <thead><tr><th>Code</th><th>Barcode</th><th>Product Name</th><th>Category</th><th>Brand</th><th>HSN</th><th class="num">GST%</th><th class="num">Purchase</th><th class="num">Sale</th><th class="num">MRP</th><th class="num">Stock</th><th>Status</th><th class="no-export"></th></tr></thead>
    <tbody>
    <?php foreach ($list as $p): $low = $p['current_stock'] <= $p['min_stock']; ?>
      <tr>
        <td><?= e($p['code']) ?></td><td><?= e($p['barcode']) ?></td>
        <td><a href="<?= e(url('product', ['id' => $p['id'], 'view' => 1])) ?>"><?= e($p['name']) ?></a></td>
        <td><?= e($p['category']) ?></td><td><?= e($p['brand']) ?></td><td><?= e($p['hsn_code']) ?></td>
        <td class="num"><?= (float)$p['gst_pct'] ?></td><td class="num"><?= money($p['purchase_rate']) ?></td><td class="num"><?= money($p['sale_rate']) ?></td><td class="num"><?= money($p['mrp']) ?></td>
        <td class="num <?= $p['current_stock'] <= 0 ? 'text-danger bold' : ($low ? 'text-warning bold' : '') ?>"><?= qtyf($p['current_stock']) ?> <?= e($p['unit']) ?></td>
        <td><?= $p['is_active'] ? '<span class="badge green">Active</span>' : '<span class="badge">Inactive</span>' ?></td>
        <td class="actions no-export">
          <a class="btn btn-sm" href="<?= e(url('product', ['id' => $p['id'], 'view' => 1])) ?>">View</a>
          <?php if (can('product.edit')): ?><a class="btn btn-sm" href="<?= e(url('product', ['id' => $p['id']])) ?>">Edit</a><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="13" class="empty">No products found.</td></tr><?php endif; ?>
    </tbody></table></div>
  <?= $pager ?>
</div>
