<?php
$id = (int)($_GET['id'] ?? 0);
if (is_post()) {
    $act = in('action');
    if ($act === 'delete') {
        require_perm('product.delete');
        $p = row('SELECT * FROM products WHERE id=? AND is_deleted=0', [$id]);
        if (!$p) throw new AppException('Product not found.');
        if (abs((float)$p['current_stock']) > 0.0001 && !is_admin()) throw new AppException('Product has stock (' . qtyf($p['current_stock']) . '). Only Admin can delete a product with stock.');
        $u = current_user();
        update('products', ['is_deleted' => 1, 'is_active' => 0, 'deleted_by' => $u['id'], 'deleted_at' => now(), 'barcode' => $p['barcode'] ? $p['barcode'] . '~' . $p['id'] : null, 'code' => $p['code'] . '~' . $p['id']], 'id=?', [$id]);
        audit('DELETE', 'product', $id, $p['code'], ['name' => $p['name'], 'barcode' => $p['barcode'], 'stock' => $p['current_stock']]);
        flash('success', 'Product "' . $p['name'] . '" deleted.');
        redirect(url('products'));
    }
    require_perm($id ? 'product.edit' : 'product.add');
    $data = [
        'code' => trim((string)in('code')), 'barcode' => trim((string)in('barcode')) ?: null, 'name' => trim((string)in('name')),
        'category_id' => ini('category_id') ?: null, 'brand_id' => ini('brand_id') ?: null, 'unit_id' => ini('unit_id') ?: null,
        'hsn_code' => trim((string)in('hsn_code')) ?: null, 'gst_pct' => inf('gst_pct'), 'purchase_rate' => r2(inf('purchase_rate')),
        'sale_rate' => r2(inf('sale_rate')), 'mrp' => r2(inf('mrp')), 'min_stock' => r3(inf('min_stock')), 'max_stock' => r3(inf('max_stock')),
        'description' => trim((string)in('description')) ?: null, 'is_active' => in('is_active') ? 1 : 0,
    ];
    $opening = r3(inf('opening_stock'));
    if ($data['name'] === '') throw new AppException('Product name is required.');
    if (!in_array((float)$data['gst_pct'], [0, 0.1, 0.25, 1, 1.5, 3, 5, 6, 7.5, 12, 18, 28, 40], true) && ($data['gst_pct'] < 0 || $data['gst_pct'] > 50)) throw new AppException('Invalid GST %.');
    if ($data['sale_rate'] < 0 || $data['purchase_rate'] < 0) throw new AppException('Rates cannot be negative.');
    if ($data['mrp'] > 0 && $data['sale_rate'] > $data['mrp']) throw new AppException('Sale rate cannot be more than MRP.');
    if ($data['max_stock'] > 0 && $data['min_stock'] > $data['max_stock']) throw new AppException('Minimum stock cannot exceed maximum stock.');
    $newId = tx(function () use ($id, $data, $opening) {
        if ($data['code'] === '') {
            do { $data['code'] = next_number('PROD'); } while (val('SELECT id FROM products WHERE code=?', [$data['code']]));
        }
        if (val('SELECT id FROM products WHERE code=? AND id<>?', [$data['code'], $id])) throw new AppException('Product code "' . $data['code'] . '" already exists.');
        if ($data['barcode'] && ($dup = row('SELECT name FROM products WHERE barcode=? AND id<>?', [$data['barcode'], $id]))) throw new AppException('Barcode already used by "' . $dup['name'] . '".');
        if ($id) {
            $old = row('SELECT * FROM products WHERE id=? FOR UPDATE', [$id]);
            if (!$old || $old['is_deleted']) throw new AppException('Product not found.');
            if ((int)in('row_version') !== (int)$old['row_version']) throw new AppException('This product was changed by ' . $old['modified_by_name'] . ' on another PC. Reload and try again.');
            update('products', array_merge($data, stamp_modify(), ['row_version' => $old['row_version'] + 1]), 'id=?', [$id]);
            if ((float)$old['opening_stock'] != $opening) set_opening_stock($id, $opening, $data['purchase_rate']);
            $changes = [];
            foreach ($data as $k => $v) if ((string)$old[$k] !== (string)$v && !((is_numeric($old[$k]) && is_numeric($v)) && (float)$old[$k] == (float)$v)) $changes[$k] = [$old[$k], $v];
            if ((float)$old['opening_stock'] != $opening) $changes['opening_stock'] = [$old['opening_stock'], $opening];
            audit('EDIT', 'product', $id, $data['code'], $changes);
            return $id;
        }
        if (!$data['barcode']) $data['barcode'] = gen_barcode();
        $nid = insert('products', array_merge($data, stamp_create(), ['current_stock' => 0]));
        if ($opening != 0) set_opening_stock($nid, $opening, $data['purchase_rate']);
        audit('CREATE', 'product', $nid, $data['code'], ['name' => $data['name'], 'opening' => $opening]);
        return $nid;
    });
    flash('success', 'Product saved successfully.');
    redirect(in('save_new') ? url('product') : url('product', ['id' => $newId, 'view' => 1]));
}

$p = $id ? row('SELECT p.*, c.name category, b.name brand, u.name unit FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN brands b ON b.id=p.brand_id LEFT JOIN units u ON u.id=p.unit_id WHERE p.id=? AND p.is_deleted=0', [$id]) : null;
if ($id && !$p) throw new AppException('Product not found.');

if ($p && (!empty($_GET['view']) || !can('product.edit'))) {
    $title = 'Product: ' . $p['name'];
    $tab = $_GET['tab'] ?? 'stock';
    $from = ind('from', date('Y-m-d', strtotime('-1 year'))); $to = ind('to');
    ?>
    <div class="card">
      <div class="card-head"><h3><?= e($p['name']) ?> <?= $p['is_active'] ? '' : '<span class="badge">Inactive</span>' ?></h3>
        <div class="btn-row">
          <?php if (can('product.edit')): ?><a class="btn btn-primary" href="<?= e(url('product', ['id' => $id])) ?>">Edit</a><?php endif; ?>
          <?php if ($p['barcode']): ?><button class="btn" onclick="printLabel()">Print Barcode Label</button><?php endif; ?>
          <a class="btn" data-cancel href="<?= e(url('products')) ?>">Back</a>
        </div></div>
      <div class="grid grid-3">
        <dl class="kv"><dt>Code</dt><dd><?= e($p['code']) ?></dd><dt>Barcode</dt><dd><?= e($p['barcode'] ?: '-') ?></dd><dt>Category</dt><dd><?= e($p['category']) ?></dd><dt>Brand</dt><dd><?= e($p['brand']) ?></dd><dt>Unit</dt><dd><?= e($p['unit']) ?></dd><dt>HSN</dt><dd><?= e($p['hsn_code']) ?></dd></dl>
        <dl class="kv"><dt>GST %</dt><dd><?= (float)$p['gst_pct'] ?>%</dd><dt>Purchase Rate</dt><dd><?= money($p['purchase_rate']) ?></dd><dt>Sale Rate</dt><dd><?= money($p['sale_rate']) ?></dd><dt>MRP</dt><dd><?= money($p['mrp']) ?></dd><dt>Min / Max</dt><dd><?= qtyf($p['min_stock']) ?> / <?= qtyf($p['max_stock']) ?></dd></dl>
        <div><div class="stat <?= $p['current_stock'] <= 0 ? 'red' : ($p['current_stock'] <= $p['min_stock'] ? 'amber' : 'green') ?>"><div class="label">Current Stock</div><div class="value"><?= qtyf($p['current_stock']) ?> <?= e($p['unit']) ?></div><div class="sub">Value: <?= money(max(0, $p['current_stock']) * $p['purchase_rate']) ?> &middot; Opening: <?= qtyf($p['opening_stock']) ?></div></div>
          <?php if ($p['barcode']): ?><svg id="bc" style="margin-top:10px;max-width:100%"></svg><?php endif; ?></div>
      </div>
      <?php if ($p['description']): ?><p class="muted"><?= nl2br(e($p['description'])) ?></p><?php endif; ?>
      <p class="muted small">Created by <?= e($p['created_by_name']) ?> on <?= dmyhm($p['created_at']) ?> (<?= e($p['device_name']) ?>)<?= $p['modified_at'] ? ' &middot; Modified by ' . e($p['modified_by_name']) . ' on ' . dmyhm($p['modified_at']) : '' ?></p>
    </div>
    <div class="card">
      <div class="tabs">
        <?php foreach (['stock' => 'Stock History', 'purchase' => 'Purchase History', 'sale' => 'Sales History'] as $k => $l): ?><a class="<?= $tab === $k ? 'active' : '' ?>" href="<?= e(url('product', ['id' => $id, 'view' => 1, 'tab' => $k, 'from' => $from, 'to' => $to])) ?>"><?= $l ?></a><?php endforeach; ?>
      </div>
      <form class="filters" method="get"><?= hidden_get_fields(['p', 'id', 'view', 'tab']) ?>
        <div class="fg"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div><div class="fg"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
        <button class="btn btn-primary">Show</button>
        <button type="button" class="btn" data-export="excel" data-table="#histTable" data-file="product_<?= e($p['code']) ?>_<?= e($tab) ?>" data-title="<?= e($p['name']) ?>">Excel</button>
        <button type="button" class="btn" data-export="pdf" data-table="#histTable" data-file="product_<?= e($p['code']) ?>_<?= e($tab) ?>" data-title="<?= e($p['name'] . ' - ' . ucfirst($tab) . ' history') ?>" data-sub="<?= dmy($from) ?> to <?= dmy($to) ?>">PDF</button>
      </form>
      <div class="table-wrap"><table class="table" id="histTable">
      <?php if ($tab === 'stock'):
          $ob = (float)val('SELECT COALESCE(SUM(qty_in-qty_out),0) FROM stock_transactions WHERE product_id=? AND txn_date<?', [$id, $from]);
          $st = rows("SELECT * FROM stock_transactions WHERE product_id=? AND txn_date BETWEEN ? AND ? ORDER BY txn_date, (txn_type='OPENING') DESC, id", [$id, $from, $to]);
          $bal = $ob; $ti = 0; $to_ = 0; ?>
        <thead><tr><th>Date</th><th>Type</th><th>Doc No</th><th>Particulars</th><th>User</th><th class="num">In</th><th class="num">Out</th><th class="num">Balance</th></tr></thead><tbody>
        <tr><td><?= dmy($from) ?></td><td colspan="6" class="bold">Opening Balance</td><td class="num bold"><?= qtyf($ob) ?></td></tr>
        <?php foreach ($st as $s): $bal += $s['qty_in'] - $s['qty_out']; $ti += $s['qty_in']; $to_ += $s['qty_out']; ?>
          <tr><td><?= dmy($s['txn_date']) ?></td><td><span class="badge"><?= e($s['txn_type']) ?></span></td><td><?= $s['document_id'] ? '<a href="' . e(url('doc_view', ['id' => $s['document_id']])) . '">' . e($s['doc_no']) . '</a>' : '-' ?></td><td><?= e($s['narration']) ?></td><td><?= e($s['user_name']) ?></td><td class="num"><?= $s['qty_in'] > 0 ? qtyf($s['qty_in']) : '' ?></td><td class="num"><?= $s['qty_out'] > 0 ? qtyf($s['qty_out']) : '' ?></td><td class="num"><?= qtyf($bal) ?></td></tr>
        <?php endforeach; ?></tbody>
        <tfoot><tr><td colspan="5">Closing</td><td class="num"><?= qtyf($ti) ?></td><td class="num"><?= qtyf($to_) ?></td><td class="num"><?= qtyf($bal) ?></td></tr></tfoot>
      <?php else:
          $dtp = $tab === 'purchase' ? ['PURCHASE', 'PRET'] : ['SALE', 'SRET'];
          $hist = rows("SELECT d.id, d.dtype, d.doc_no, d.doc_date, d.created_by_name, pa.name party, i.qty, i.free_qty, i.rate, i.disc_amt, i.gst_pct, i.total FROM document_items i JOIN documents d ON d.id=i.document_id LEFT JOIN parties pa ON pa.id=d.party_id WHERE i.product_id=? AND d.dtype IN (?,?) AND d.is_deleted=0 AND d.doc_date BETWEEN ? AND ? ORDER BY d.doc_date DESC, d.id DESC", [$id, $dtp[0], $dtp[1], $from, $to]);
          $tq = 0; $tt = 0; ?>
        <thead><tr><th>Date</th><th>Type</th><th>Doc No</th><th><?= $tab === 'purchase' ? 'Supplier' : 'Customer' ?></th><th>User</th><th class="num">Qty</th><?= $tab === 'purchase' ? '<th class="num">Free</th>' : '' ?><th class="num">Rate</th><th class="num">Disc</th><th class="num">GST%</th><th class="num">Total</th></tr></thead><tbody>
        <?php foreach ($hist as $h): $sg = in_array($h['dtype'], ['SRET', 'PRET']) ? -1 : 1; $tq += $sg * $h['qty']; $tt += $sg * $h['total']; ?>
          <tr><td><?= dmy($h['doc_date']) ?></td><td><?= in_array($h['dtype'], ['SRET', 'PRET']) ? '<span class="badge amber">Return</span>' : '<span class="badge blue">' . ($tab === 'purchase' ? 'Purchase' : 'Sale') . '</span>' ?></td><td><a href="<?= e(url('doc_view', ['id' => $h['id']])) ?>"><?= e($h['doc_no']) ?></a></td><td><?= e($h['party']) ?></td><td><?= e($h['created_by_name']) ?></td><td class="num"><?= qtyf($h['qty']) ?></td><?= $tab === 'purchase' ? '<td class="num">' . qtyf($h['free_qty']) . '</td>' : '' ?><td class="num"><?= money($h['rate']) ?></td><td class="num"><?= money($h['disc_amt']) ?></td><td class="num"><?= (float)$h['gst_pct'] ?></td><td class="num"><?= money($h['total']) ?></td></tr>
        <?php endforeach; if (!$hist) echo '<tr><td colspan="11" class="empty">No records in this period.</td></tr>'; ?></tbody>
        <tfoot><tr><td colspan="5">Net Total</td><td class="num"><?= qtyf($tq) ?></td><?= $tab === 'purchase' ? '<td></td>' : '' ?><td colspan="3"></td><td class="num"><?= money($tt) ?></td></tr></tfoot>
      <?php endif; ?>
      </table></div>
    </div>
    <?php if ($p['barcode']): ?>
    <script src="assets/vendor/JsBarcode.all.min.js"></script>
    <script>
    const BC = <?= json_encode($p['barcode']) ?>;
    const fmt = /^\d{13}$/.test(BC) ? 'EAN13' : 'CODE128';
    try { JsBarcode('#bc', BC, {format: fmt, height: 50, fontSize: 14}); } catch(e) { JsBarcode('#bc', BC, {format: 'CODE128', height: 50}); }
    function printLabel(){
      const n = prompt('How many labels?', '1'); if (!n) return;
      const w = window.open('', '_blank', 'width=600,height=600');
      let h = '<html><head><title>Labels</title><style>body{font-family:Arial;margin:0}.l{display:inline-block;width:48mm;height:25mm;padding:2mm;text-align:center;font-size:9px;overflow:hidden;page-break-inside:avoid}svg{width:100%;height:14mm}</style></head><body>';
      for (let i = 0; i < +n; i++) h += '<div class="l"><div><b>' + <?= json_encode(mb_substr($p['name'], 0, 32)) ?> + '</b></div><svg class="b"></svg><div>MRP: <?= e(setting('currency_symbol', '₹') . money($p['mrp'])) ?> &nbsp; Rate: <?= e(money($p['sale_rate'])) ?></div></div>';
      w.document.write(h + '</body></html>');
      const s = w.document.createElement('script'); s.src = location.origin + location.pathname.replace(/[^\/]*$/, '') + 'assets/vendor/JsBarcode.all.min.js';
      s.onload = () => { w.JsBarcode(w.document.querySelectorAll('.b'), BC, {format: fmt, height: 40, fontSize: 12, margin: 0}); setTimeout(() => w.print(), 300); };
      w.document.body.appendChild(s);
    }
    BP.onPrint = printLabel;
    </script>
    <?php endif;
    return;
}

require_perm($id ? 'product.edit' : 'product.add');
$title = $id ? 'Edit Product' : 'Add Product';
$p = $p ?: ['code' => '', 'barcode' => '', 'name' => '', 'category_id' => '', 'brand_id' => '', 'unit_id' => val("SELECT id FROM units WHERE name='Pcs'"), 'hsn_code' => '', 'gst_pct' => setting('default_gst', '18'), 'purchase_rate' => '', 'sale_rate' => '', 'mrp' => '', 'opening_stock' => 0, 'min_stock' => 0, 'max_stock' => 0, 'description' => '', 'is_active' => 1, 'row_version' => 1];
$cats = rows('SELECT id, name FROM categories WHERE is_deleted=0 ORDER BY name');
$brands = rows('SELECT id, name FROM brands WHERE is_deleted=0 ORDER BY name');
$units = rows('SELECT id, name FROM units WHERE is_deleted=0 ORDER BY name');
?>
<form method="post" class="card" data-save>
  <?= csrf_field() ?><input type="hidden" name="row_version" value="<?= (int)$p['row_version'] ?>">
  <div class="card-head"><h3><?= $id ? 'Edit: ' . e($p['name']) : 'New Product' ?></h3><span class="muted small"><kbd>Ctrl+S</kbd> Save &middot; <kbd>Esc</kbd> Cancel</span></div>
  <div class="form-grid cols-4">
    <div class="fg"><label>Product Code</label><div class="input-group"><input name="code" id="fCode" value="<?= e($p['code']) ?>" placeholder="Auto if blank"><button type="button" class="btn btn-sm" onclick="gen('code','fCode')">Auto</button></div></div>
    <div class="fg"><label>Barcode</label><div class="input-group"><input name="barcode" id="fBarcode" value="<?= e($p['barcode']) ?>" placeholder="Scan or generate"><button type="button" class="btn btn-sm" onclick="gen('barcode','fBarcode')">Generate</button></div></div>
    <div class="fg span-2"><label class="req">Product Name</label><input name="name" required value="<?= e($p['name']) ?>" autofocus></div>
    <div class="fg"><label>Category</label><select name="category_id"><?= options($cats, $p['category_id'], 'id', 'name', '- Select -') ?></select></div>
    <div class="fg"><label>Brand</label><select name="brand_id"><?= options($brands, $p['brand_id'], 'id', 'name', '- Select -') ?></select></div>
    <div class="fg"><label>Unit</label><select name="unit_id"><?= options($units, $p['unit_id'], 'id', 'name', '- Select -') ?></select></div>
    <div class="fg"><label>HSN Code</label><input name="hsn_code" value="<?= e($p['hsn_code']) ?>"></div>
    <div class="fg"><label>GST %</label><select name="gst_pct"><?php foreach ([0, 0.25, 3, 5, 12, 18, 28, 40] as $g) echo '<option value="' . $g . '"' . ((float)$p['gst_pct'] == $g ? ' selected' : '') . '>' . $g . '%</option>'; ?></select></div>
    <div class="fg"><label>Purchase Rate</label><input type="number" step="0.01" min="0" name="purchase_rate" value="<?= e($p['purchase_rate']) ?>"></div>
    <div class="fg"><label>Sale Rate</label><input type="number" step="0.01" min="0" name="sale_rate" value="<?= e($p['sale_rate']) ?>"></div>
    <div class="fg"><label>MRP</label><input type="number" step="0.01" min="0" name="mrp" value="<?= e($p['mrp']) ?>"></div>
    <div class="fg"><label>Opening Stock</label><input type="number" step="0.001" name="opening_stock" value="<?= e(qtyf($p['opening_stock'])) ?>"><span class="hint">Creates an OPENING stock record</span></div>
    <div class="fg"><label>Minimum Stock</label><input type="number" step="0.001" min="0" name="min_stock" value="<?= e(qtyf($p['min_stock'])) ?>"></div>
    <div class="fg"><label>Maximum Stock</label><input type="number" step="0.001" min="0" name="max_stock" value="<?= e(qtyf($p['max_stock'])) ?>"></div>
    <div class="fg"><label>&nbsp;</label><label class="check"><input type="checkbox" name="is_active" value="1" <?= $p['is_active'] ? 'checked' : '' ?>> Active</label></div>
    <div class="fg span-all"><label>Product Description</label><textarea name="description"><?= e($p['description']) ?></textarea></div>
  </div>
  <div class="btn-row">
    <button class="btn btn-primary">Save <kbd>Ctrl+S</kbd></button>
    <?php if (!$id): ?><button class="btn" name="save_new" value="1">Save &amp; New</button><?php endif; ?>
    <a class="btn" data-cancel href="<?= e($id ? url('product', ['id' => $id, 'view' => 1]) : url('products')) ?>">Cancel</a>
  </div>
</form>
<?php if ($id && can('product.delete')): ?>
<form method="post" class="card" data-confirm="Delete this product? It will be hidden from all lists (history is kept)." data-danger="1" data-ok="Delete">
  <?= csrf_field() ?><input type="hidden" name="action" value="delete"><button class="btn btn-danger">Delete Product</button>
</form>
<?php endif; ?>
<script>
async function gen(kind, fid){ try { const j = await BP.api('next_code', {kind}, 'GET'); document.getElementById(fid).value = j.code; } catch(e) { BP.toast(e.message, 'danger'); } }
</script>
