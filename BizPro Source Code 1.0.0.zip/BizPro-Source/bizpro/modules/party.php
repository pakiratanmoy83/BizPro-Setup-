<?php
$id = (int)($_GET['id'] ?? 0);
$p = $id ? row('SELECT * FROM parties WHERE id=? AND is_deleted=0', [$id]) : null;
if ($id && !$p) throw new AppException('Record not found.');
$t = $p ? $p['ptype'] : (($_GET['t'] ?? 'C') === 'S' ? 'S' : 'C');
$isC = $t === 'C';
$L = $isC ? 'Customer' : 'Supplier';
$pm = $isC ? 'customer' : 'supplier';

if (is_post()) {
    if (in('action') === 'delete') {
        require_perm("$pm.delete");
        if ($p['is_system']) throw new AppException('System record cannot be deleted.');
        $cnt = (int)val('SELECT COUNT(*) FROM documents WHERE party_id=? AND is_deleted=0', [$id]);
        if ($cnt) throw new AppException("Cannot delete: $cnt transaction(s) exist for this $pm. Mark it inactive instead.");
        $u = current_user();
        update('parties', ['is_deleted' => 1, 'is_active' => 0, 'deleted_by' => $u['id'], 'deleted_at' => now(), 'code' => $p['code'] . '~' . $id], 'id=?', [$id]);
        audit('DELETE', $pm, $id, $p['code'], ['name' => $p['name']]);
        flash('success', "$L deleted.");
        redirect(url('parties', ['t' => $t]));
    }
    require_perm($id ? "$pm.edit" : "$pm.add");
    if ($p && $p['is_system'] && !is_admin()) throw new AppException('Only Admin can edit the walk-in customer.');
    $data = [
        'name' => trim((string)in('name')), 'company_name' => trim((string)in('company_name')) ?: null, 'address' => trim((string)in('address')) ?: null,
        'state' => trim((string)in('state')) ?: null, 'mobile' => trim((string)in('mobile')) ?: null, 'email' => trim((string)in('email')) ?: null,
        'gstin' => strtoupper(trim((string)in('gstin'))) ?: null, 'opening_balance' => r2(inf('opening_balance')), 'credit_limit' => r2(inf('credit_limit')),
        'remarks' => trim((string)in('remarks')) ?: null, 'is_active' => in('is_active') ? 1 : 0,
    ];
    if ($data['name'] === '') throw new AppException('Name is required.');
    if ($data['mobile'] && !preg_match('/^[0-9+\- ]{6,15}$/', $data['mobile'])) throw new AppException('Invalid mobile number.');
    if ($data['email'] && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) throw new AppException('Invalid email address.');
    if ($data['gstin'] && !preg_match('/^[0-9]{2}[A-Z0-9]{13}$/', $data['gstin'])) throw new AppException('GSTIN must be 15 characters (e.g. 19ABCDE1234F1Z5).');
    if ($data['credit_limit'] < 0) throw new AppException('Credit limit cannot be negative.');
    $nid = tx(function () use ($id, $p, $data, $t, $pm) {
        if ($data['mobile'] && ($dup = row('SELECT name FROM parties WHERE ptype=? AND mobile=? AND id<>? AND is_deleted=0', [$t, $data['mobile'], $id]))) throw new AppException('Mobile number already used by ' . $dup['name'] . '.');
        if ($id) {
            $old = row('SELECT * FROM parties WHERE id=? FOR UPDATE', [$id]);
            if ((int)in('row_version') !== (int)$old['row_version']) throw new AppException('This record was changed by ' . $old['modified_by_name'] . ' on another PC. Reload and try again.');
            update('parties', array_merge($data, stamp_modify(), ['row_version' => $old['row_version'] + 1]), 'id=?', [$id]);
            $ch = [];
            foreach ($data as $k => $v) if ((string)$old[$k] !== (string)$v) $ch[$k] = [$old[$k], $v];
            audit('EDIT', $pm, $id, $old['code'], $ch);
            return $id;
        }
        $code = next_number($t === 'C' ? 'CUST' : 'SUPP');
        $nid = insert('parties', array_merge($data, ['ptype' => $t, 'code' => $code], stamp_create()));
        audit('CREATE', $pm, $nid, $code, ['name' => $data['name'], 'opening' => $data['opening_balance']]);
        return $nid;
    });
    flash('success', "$L saved.");
    redirect(url('party', ['id' => $nid]));
}

if (!$p || !empty($_GET['edit'])) {
    require_perm($id ? "$pm.edit" : "$pm.add");
    $title = $id ? "Edit $L" : "Add $L";
    $p = $p ?: ['code' => '(auto)', 'name' => '', 'company_name' => '', 'address' => '', 'state' => setting('business_state'), 'mobile' => '', 'email' => '', 'gstin' => '', 'opening_balance' => 0, 'credit_limit' => 0, 'remarks' => '', 'is_active' => 1, 'row_version' => 1, 'is_system' => 0];
    $states = ['Andaman and Nicobar Islands', 'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chandigarh', 'Chhattisgarh', 'Dadra and Nagar Haveli and Daman and Diu', 'Delhi', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand', 'Karnataka', 'Kerala', 'Ladakh', 'Lakshadweep', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Puducherry', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'];
    ?>
    <form method="post" class="card" data-save><?= csrf_field() ?><input type="hidden" name="row_version" value="<?= (int)$p['row_version'] ?>">
      <div class="card-head"><h3><?= $title ?></h3><span class="muted small"><kbd>Ctrl+S</kbd> Save</span></div>
      <div class="form-grid cols-3">
        <div class="fg"><label><?= $L ?> ID</label><input value="<?= e($p['code']) ?>" readonly></div>
        <div class="fg"><label class="req"><?= $L ?> Name</label><input name="name" required value="<?= e($p['name']) ?>" autofocus></div>
        <div class="fg"><label>Company Name</label><input name="company_name" value="<?= e($p['company_name']) ?>"></div>
        <div class="fg"><label>Mobile</label><input name="mobile" value="<?= e($p['mobile']) ?>"></div>
        <div class="fg"><label>Email</label><input type="email" name="email" value="<?= e($p['email']) ?>"></div>
        <div class="fg"><label>GST Number</label><input name="gstin" maxlength="15" value="<?= e($p['gstin']) ?>" style="text-transform:uppercase"></div>
        <div class="fg span-2"><label>Address</label><textarea name="address"><?= e($p['address']) ?></textarea></div>
        <div class="fg"><label>State (for CGST/SGST vs IGST)</label><select name="state"><option value="">-</option><?php foreach ($states as $s) echo '<option' . ($s === $p['state'] ? ' selected' : '') . '>' . e($s) . '</option>'; ?></select></div>
        <div class="fg"><label>Opening Balance</label><input type="number" step="0.01" name="opening_balance" value="<?= e($p['opening_balance']) ?>"><span class="hint"><?= $isC ? 'Amount customer owes you (negative = advance)' : 'Amount you owe supplier (negative = advance)' ?></span></div>
        <div class="fg"><label>Credit Limit</label><input type="number" step="0.01" min="0" name="credit_limit" value="<?= e($p['credit_limit']) ?>"><span class="hint">0 = no limit</span></div>
        <div class="fg"><label>&nbsp;</label><label class="check"><input type="checkbox" name="is_active" value="1" <?= $p['is_active'] ? 'checked' : '' ?>> Active</label></div>
        <div class="fg span-all"><label>Remarks</label><textarea name="remarks"><?= e($p['remarks']) ?></textarea></div>
      </div>
      <div class="btn-row"><button class="btn btn-primary">Save</button><a class="btn" data-cancel href="<?= e($id ? url('party', ['id' => $id]) : url('parties', ['t' => $t])) ?>">Cancel</a></div>
    </form>
    <?php if ($id && !$p['is_system'] && can("$pm.delete")): ?>
    <form method="post" class="card" data-confirm="Delete this <?= $pm ?>?" data-danger="1"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><button class="btn btn-danger">Delete <?= $L ?></button></form>
    <?php endif;
    return;
}

// ---- View: summary + ledger ----
$title = "$L: " . $p['name'];
$tab = $_GET['tab'] ?? 'ledger';
[$fyS] = fy_range();
$from = ind('from', $fyS); $to = ind('to');
$docT = $isC ? ['SALE', 'SRET', 'RECEIPT'] : ['PURCHASE', 'PRET', 'PAYMENT'];
$sum = [];
foreach ($docT as $dt_) $sum[$dt_] = (float)val('SELECT COALESCE(SUM(grand_total),0) FROM documents WHERE party_id=? AND dtype=? AND is_deleted=0', [$id, $dt_]);
$paidAtBill = (float)val('SELECT COALESCE(SUM(paid_amount),0) FROM documents WHERE party_id=? AND dtype=? AND is_deleted=0', [$id, $docT[0]]);
$balance = party_balance($id);
$canLedger = can("$pm.ledger") || can("$pm.view");
?>
<div class="card">
  <div class="card-head"><h3><?= e($p['name']) ?> <span class="muted small"><?= e($p['code']) ?></span></h3>
    <div class="btn-row">
      <?php if ($isC && can('sale.add')): ?><a class="btn btn-primary" href="<?= e(url('doc_form', ['t' => 'SALE', 'party' => $id])) ?>">New Sale</a><?php endif; ?>
      <?php if ($isC && can('receipt.add')): ?><a class="btn" href="<?= e(url('voucher_form', ['t' => 'RECEIPT', 'party' => $id])) ?>">Receive Payment</a><?php endif; ?>
      <?php if (!$isC && can('purchase.add')): ?><a class="btn btn-primary" href="<?= e(url('doc_form', ['t' => 'PURCHASE', 'party' => $id])) ?>">New Purchase</a><?php endif; ?>
      <?php if (!$isC && can('payment.add')): ?><a class="btn" href="<?= e(url('voucher_form', ['t' => 'PAYMENT', 'party' => $id])) ?>">Make Payment</a><?php endif; ?>
      <?php if (!$p['is_system'] && can("$pm.edit")): ?><a class="btn" href="<?= e(url('party', ['id' => $id, 'edit' => 1])) ?>">Edit</a><?php endif; ?>
      <a class="btn" data-cancel href="<?= e(url('parties', ['t' => $t])) ?>">Back</a>
    </div></div>
  <div class="grid grid-4">
    <dl class="kv" style="grid-column:span 2"><dt>Mobile</dt><dd><?= e($p['mobile'] ?: '-') ?></dd><dt>Email</dt><dd><?= e($p['email'] ?: '-') ?></dd><dt>GSTIN</dt><dd><?= e($p['gstin'] ?: '-') ?></dd><dt>Address</dt><dd><?= nl2br(e($p['address'] ?: '-')) ?> <?= e($p['state']) ?></dd><?php if (!$isC): ?><dt>Company</dt><dd><?= e($p['company_name']) ?></dd><?php endif; ?><dt>Credit Limit</dt><dd><?= $p['credit_limit'] > 0 ? money($p['credit_limit']) : 'No limit' ?></dd></dl>
    <div class="stat"><div class="label">Total <?= $isC ? 'Sales' : 'Purchase' ?></div><div class="value"><?= money($sum[$docT[0]]) ?></div><div class="sub">Returns: <?= money($sum[$docT[1]]) ?> &middot; Opening: <?= money($p['opening_balance']) ?></div></div>
    <div class="stat <?= $balance > 0 ? 'red' : 'green' ?>"><div class="label">Outstanding <?= $isC ? 'Receivable' : 'Payable' ?></div><div class="value"><?= money($balance) ?></div><div class="sub">Total <?= $isC ? 'received' : 'paid' ?>: <?= money($sum[$docT[2]] + $paidAtBill) ?></div></div>
  </div>
</div>
<div class="card">
  <div class="tabs"><?php foreach (['ledger' => 'Ledger / Statement', 'bills' => ($isC ? 'Sales History' : 'Purchase History'), 'pays' => ($isC ? 'Receipts' : 'Payments')] as $k => $l): ?><a class="<?= $tab === $k ? 'active' : '' ?>" href="<?= e(url('party', ['id' => $id, 'tab' => $k, 'from' => $from, 'to' => $to])) ?>"><?= $l ?></a><?php endforeach; ?></div>
  <form class="filters" method="get"><?= hidden_get_fields(['p', 'id', 'tab']) ?>
    <div class="fg"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div><div class="fg"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
    <button class="btn btn-primary">Show</button>
    <?php if ($tab === 'ledger'): ?><a class="btn" target="_blank" href="print.php?type=statement&id=<?= $id ?>&from=<?= e($from) ?>&to=<?= e($to) ?>">Print Statement</a><?php endif; ?>
    <button type="button" class="btn" data-export="excel" data-table="#lTable" data-file="<?= e($p['code']) ?>_<?= $tab ?>" data-title="<?= e($p['name']) ?>">Excel</button>
    <button type="button" class="btn" data-export="pdf" data-table="#lTable" data-file="<?= e($p['code']) ?>_<?= $tab ?>" data-title="<?= e($L . ' Statement - ' . $p['name']) ?>" data-sub="Period <?= dmy($from) ?> to <?= dmy($to) ?>">PDF</button>
  </form>
  <div class="table-wrap"><table class="table" id="lTable">
  <?php if ($tab === 'ledger'):
      [$ob, $lines] = party_statement($id, $from, $to);
      $bal = $ob; $td = 0; $tc = 0; ?>
    <thead><tr><th>Date</th><th>Doc No</th><th>Particulars</th><th>User</th><th class="num">Debit</th><th class="num">Credit</th><th class="num">Balance</th></tr></thead><tbody>
    <tr class="bold"><td><?= dmy($from) ?></td><td></td><td>Opening Balance</td><td></td><td></td><td></td><td class="num"><?= money($ob) ?></td></tr>
    <?php foreach ($lines as $l): $bal += $isC ? $l['debit'] - $l['credit'] : $l['credit'] - $l['debit']; $td += $l['debit']; $tc += $l['credit']; ?>
      <tr><td><?= dmy($l['txn_date']) ?></td><td><?= $l['document_id'] ? '<a href="' . e(url('doc_view', ['id' => $l['document_id']])) . '">' . e($l['doc_no']) . '</a>' : '' ?></td><td><?= e($l['narration']) ?></td><td><?= e($l['user_name']) ?></td><td class="num"><?= $l['debit'] > 0 ? money($l['debit']) : '' ?></td><td class="num"><?= $l['credit'] > 0 ? money($l['credit']) : '' ?></td><td class="num"><?= money($bal) ?></td></tr>
    <?php endforeach; ?></tbody>
    <tfoot><tr><td colspan="4">Closing Balance (<?= $isC ? 'Receivable' : 'Payable' ?>)</td><td class="num"><?= money($td) ?></td><td class="num"><?= money($tc) ?></td><td class="num"><?= money($bal) ?></td></tr></tfoot>
  <?php elseif ($tab === 'bills'):
      $bills = rows('SELECT * FROM documents WHERE party_id=? AND dtype IN (?,?) AND is_deleted=0 AND doc_date BETWEEN ? AND ? ORDER BY doc_date DESC, id DESC', [$id, $docT[0], $docT[1], $from, $to]);
      $a = $b = $c = 0; ?>
    <thead><tr><th>Date</th><th>Type</th><th>Doc No</th><?= $isC ? '' : '<th>Supplier Bill</th>' ?><th>User</th><th class="num">Grand Total</th><th class="num">Paid</th><th class="num">Due</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($bills as $d): $r = in_array($d['dtype'], ['SRET', 'PRET']); $s = $r ? -1 : 1; $a += $s * $d['grand_total']; $b += $s * $d['paid_amount']; $c += $s * $d['due_amount']; ?>
      <tr><td><?= dmy($d['doc_date']) ?></td><td><?= $r ? '<span class="badge amber">Return</span>' : '<span class="badge blue">Invoice</span>' ?></td><td><a href="<?= e(url('doc_view', ['id' => $d['id']])) ?>"><?= e($d['doc_no']) ?></a></td><?= $isC ? '' : '<td>' . e($d['ref_invoice_no']) . '</td>' ?><td><?= e($d['created_by_name']) ?></td><td class="num"><?= money($d['grand_total']) ?></td><td class="num"><?= money($d['paid_amount']) ?></td><td class="num"><?= money($d['due_amount']) ?></td><td><?= $r ? '' : status_badge((float)$d['due_amount'], (float)$d['grand_total']) ?></td></tr>
    <?php endforeach; if (!$bills) echo '<tr><td colspan="9" class="empty">No records.</td></tr>'; ?></tbody>
    <tfoot><tr><td colspan="<?= $isC ? 4 : 5 ?>">Net Total</td><td class="num"><?= money($a) ?></td><td class="num"><?= money($b) ?></td><td class="num"><?= money($c) ?></td><td></td></tr></tfoot>
  <?php else:
      $pays = rows('SELECT d.*, a.name account FROM documents d LEFT JOIN accounts a ON a.id=d.account_id WHERE d.party_id=? AND d.dtype=? AND d.is_deleted=0 AND d.doc_date BETWEEN ? AND ? ORDER BY d.doc_date DESC, d.id DESC', [$id, $docT[2], $from, $to]);
      $a = 0; ?>
    <thead><tr><th>Date</th><th>No.</th><th>Mode</th><th>Account</th><th>Reference</th><th>User</th><th>Remarks</th><th class="num">Amount</th></tr></thead><tbody>
    <?php foreach ($pays as $d): $a += $d['grand_total']; ?>
      <tr><td><?= dmy($d['doc_date']) ?></td><td><a href="<?= e(url('doc_view', ['id' => $d['id']])) ?>"><?= e($d['doc_no']) ?></a></td><td><?= e($d['payment_mode']) ?></td><td><?= e($d['account']) ?></td><td><?= e($d['reference_no']) ?></td><td><?= e($d['created_by_name']) ?></td><td><?= e($d['remarks']) ?></td><td class="num"><?= money($d['grand_total']) ?></td></tr>
    <?php endforeach; if (!$pays) echo '<tr><td colspan="8" class="empty">No records.</td></tr>'; ?></tbody>
    <tfoot><tr><td colspan="7">Total</td><td class="num"><?= money($a) ?></td></tr></tfoot>
  <?php endif; ?>
  </table></div>
</div>
