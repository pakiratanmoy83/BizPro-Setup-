<?php
$accs = rows('SELECT id, name, atype, opening_balance FROM accounts WHERE is_deleted=0 ORDER BY id');
$acc = (int)($_GET['acc'] ?? 0);
$kind = $_GET['kind'] ?? '';
if (!$acc && !$kind) $kind = 'CASH';
$from = ind('from', date('Y-m-01')); $to = ind('to');
$user = (int)($_GET['user'] ?? 0);
$ids = $acc ? [$acc] : array_column(array_filter($accs, fn($a) => $kind === 'ALL' || $a['atype'] === $kind), 'id');
if (!$ids) $ids = [0];
$in = implode(',', array_map('intval', $ids));
$accName = $acc ? val('SELECT name FROM accounts WHERE id=?', [$acc]) : ['CASH' => 'Cash Book', 'BANK' => 'Bank Book', 'UPI' => 'UPI Book', 'OTHER' => 'Other Accounts', 'ALL' => 'All Accounts'][$kind] ?? '';
$title = 'Cash / Bank Book - ' . $accName;
$openBase = (float)val("SELECT COALESCE(SUM(opening_balance),0) FROM accounts WHERE id IN ($in)");
$pre = (float)val("SELECT COALESCE(SUM(amount_in-amount_out),0) FROM account_transactions WHERE account_id IN ($in) AND txn_date<?", [$from]);
$ob = r2($openBase + $pre);
$w = "t.account_id IN ($in) AND t.txn_date BETWEEN ? AND ?"; $pp = [$from, $to];
if ($user) { $w .= ' AND t.user_id=?'; $pp[] = $user; }
$lines = rows("SELECT t.*, a.name acc, p.name party FROM account_transactions t JOIN accounts a ON a.id=t.account_id LEFT JOIN parties p ON p.id=t.party_id WHERE $w ORDER BY t.txn_date, t.id", $pp);
$daily = rows("SELECT t.txn_date, SUM(amount_in) i, SUM(amount_out) o FROM account_transactions t WHERE $w GROUP BY t.txn_date ORDER BY t.txn_date", $pp);
$typeL = ['SALE' => 'Sale', 'PURCHASE' => 'Purchase', 'SRET' => 'Sales Return', 'PRET' => 'Purchase Return', 'RECEIPT' => 'Receipt', 'PAYMENT' => 'Payment', 'EXPENSE' => 'Expense', 'CASH' => 'Cash/Bank Entry'];
?>
<div class="card">
  <div class="card-head"><h3><?= e($accName) ?> <span class="muted small"><?= dmy($from) ?> to <?= dmy($to) ?></span></h3>
    <div class="btn-row"><a class="btn" href="<?= e(url('accounts')) ?>" data-cancel>Back</a>
      <button class="btn" data-export="excel" data-table="#bkTable" data-file="book_<?= $from ?>_<?= $to ?>" data-title="<?= e($accName) ?>">Excel</button>
      <button class="btn" data-export="pdf" data-table="#bkTable" data-file="book_<?= $from ?>_<?= $to ?>" data-title="<?= e($accName) ?>" data-sub="<?= dmy($from) ?> to <?= dmy($to) ?>">PDF</button>
      <button class="btn" onclick="window.print()">Print</button></div></div>
  <form class="filters" method="get"><input type="hidden" name="p" value="book">
    <div class="fg"><label>Book</label><select name="kind"><option value="">- Specific account -</option><?php foreach (['CASH' => 'Cash Book', 'BANK' => 'Bank Book', 'UPI' => 'UPI Book', 'OTHER' => 'Other', 'ALL' => 'All accounts'] as $k => $v) echo '<option value="' . $k . '"' . (!$acc && $kind === $k ? ' selected' : '') . '>' . $v . '</option>'; ?></select></div>
    <div class="fg"><label>Account</label><select name="acc"><?= options($accs, $acc, 'id', 'name', '- All in book -') ?></select></div>
    <div class="fg"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div><div class="fg"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
    <div class="fg"><label>User</label><select name="user"><?= options(rows('SELECT id, username name FROM users ORDER BY username'), $user, 'id', 'name', 'All') ?></select></div>
    <button class="btn btn-primary">Show</button></form>
  <div class="table-wrap"><table class="table" id="bkTable"><thead><tr><th>Date</th><th>Account</th><th>Type</th><th>Doc No</th><th>Particulars</th><th>User</th><th class="num">Receipt (In)</th><th class="num">Payment (Out)</th><th class="num">Balance</th></tr></thead><tbody>
    <tr class="bold"><td><?= dmy($from) ?></td><td colspan="5">Opening Balance</td><td></td><td></td><td class="num"><?= money($ob) ?></td></tr>
    <?php $bal = $ob; $ti = $tout = 0; foreach ($lines as $l): $bal += $l['amount_in'] - $l['amount_out']; $ti += $l['amount_in']; $tout += $l['amount_out']; ?>
    <tr><td class="nowrap"><?= dmy($l['txn_date']) ?></td><td><?= e($l['acc']) ?></td><td><?= e($typeL[$l['txn_type']] ?? $l['txn_type']) ?></td><td><?= $l['document_id'] ? '<a href="' . e(url('doc_view', ['id' => $l['document_id']])) . '">' . e($l['doc_no']) . '</a>' : '' ?></td><td><?= e($l['narration']) ?></td><td><?= e($l['user_name']) ?></td>
      <td class="num text-success"><?= $l['amount_in'] > 0 ? money($l['amount_in']) : '' ?></td><td class="num text-danger"><?= $l['amount_out'] > 0 ? money($l['amount_out']) : '' ?></td><td class="num"><?= money($bal) ?></td></tr>
    <?php endforeach; if (!$lines) echo '<tr><td colspan="9" class="empty">No transactions in this period.</td></tr>'; ?>
  </tbody><tfoot><tr><td colspan="6">Closing Balance</td><td class="num"><?= money($ti) ?></td><td class="num"><?= money($tout) ?></td><td class="num"><?= money($bal) ?></td></tr></tfoot></table></div>
</div>
<?php if (count($daily) > 1): ?>
<div class="card"><h3>Day-wise Summary</h3><div class="table-wrap"><table class="table" id="bkDaily"><thead><tr><th>Date</th><th class="num">In</th><th class="num">Out</th><th class="num">Net</th></tr></thead><tbody>
<?php foreach ($daily as $d): ?><tr><td><?= dmy($d['txn_date']) ?></td><td class="num"><?= money($d['i']) ?></td><td class="num"><?= money($d['o']) ?></td><td class="num"><?= money($d['i'] - $d['o']) ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php endif; ?>
