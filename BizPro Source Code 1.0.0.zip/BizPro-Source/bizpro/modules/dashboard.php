<?php
$title = 'Dashboard';
if (!can('dashboard.view')) {
    $u = current_user();
    echo '<div class="card"><h3>Welcome, ' . e($u['full_name']) . '</h3><p class="muted">Use the menu on the left to open the modules you have access to.</p></div>';
    return;
}
$d = dashboard_data();
$refresh = max(15, (int)setting('dashboard_refresh_sec', '60'));
$cur = setting('currency_symbol', '₹');
?>
<div class="card-head"><div class="muted small">Live data from central server &middot; auto refresh every <?= $refresh ?>s &middot; last updated <span id="dUpdated"><?= e($d['updated']) ?></span></div>
<div class="btn-row">
<?php if (can('sale.add')): ?><a class="btn btn-primary" href="<?= e(url('doc_form', ['t' => 'SALE'])) ?>">New Sale <kbd>F5</kbd></a><?php endif; ?>
<?php if (can('purchase.add')): ?><a class="btn" href="<?= e(url('doc_form', ['t' => 'PURCHASE'])) ?>">New Purchase <kbd>F6</kbd></a><?php endif; ?>
<?php if (can('receipt.add')): ?><a class="btn" href="<?= e(url('voucher_form', ['t' => 'RECEIPT'])) ?>">Receipt <kbd>F7</kbd></a><?php endif; ?>
<?php if (can('payment.add')): ?><a class="btn" href="<?= e(url('voucher_form', ['t' => 'PAYMENT'])) ?>">Payment <kbd>F8</kbd></a><?php endif; ?>
</div></div>

<div class="grid grid-4" style="margin-bottom:14px">
  <?php if (isset($d['today_sales'])): ?><div class="stat green"><div class="label"><?= $d['scope_sales'] === 'own' ? 'My Sales Today' : "Today's Sales" ?></div><div class="value" data-k="today_sales" data-m="1"><?= $cur . money($d['today_sales']) ?></div><div class="sub"><span data-k="today_sales_count"><?= $d['today_sales_count'] ?></span> invoices</div></div><?php endif; ?>
  <?php if (isset($d['today_purchase'])): ?><div class="stat"><div class="label"><?= $d['scope_purchase'] === 'own' ? 'My Purchases Today' : "Today's Purchase" ?></div><div class="value" data-k="today_purchase" data-m="1"><?= $cur . money($d['today_purchase']) ?></div><div class="sub"><span data-k="today_purchase_count"><?= $d['today_purchase_count'] ?></span> bills</div></div><?php endif; ?>
  <?php if (isset($d['today_collection'])): ?><div class="stat cyan"><div class="label">Today's Collection</div><div class="value" data-k="today_collection" data-m="1"><?= $cur . money($d['today_collection']) ?></div><div class="sub">Sales cash + customer receipts</div></div><?php endif; ?>
  <?php if (isset($d['today_payment'])): ?><div class="stat amber"><div class="label">Today's Payment</div><div class="value" data-k="today_payment" data-m="1"><?= $cur . money($d['today_payment']) ?></div><div class="sub">Expense today: <span data-k="today_expense" data-m="1"><?= $cur . money($d['today_expense']) ?></span></div></div><?php endif; ?>
  <a class="stat violet" href="<?= e(url('products')) ?>"><div class="label">Total Products</div><div class="value" data-k="total_products"><?= $d['total_products'] ?></div><div class="sub">Total stock qty: <span data-k="total_stock"><?= e($d['total_stock']) ?></span></div></a>
  <?php if (isset($d['stock_value'])): ?><a class="stat" href="<?= e(url('stock')) ?>"><div class="label">Total Stock Value</div><div class="value" data-k="stock_value" data-m="1"><?= $cur . money($d['stock_value']) ?></div><div class="sub">At purchase rate</div></a><?php endif; ?>
  <?php if (isset($d['customer_outstanding'])): ?><a class="stat green" href="<?= e(url('parties', ['t' => 'C'])) ?>"><div class="label">Customer Outstanding</div><div class="value" data-k="customer_outstanding" data-m="1"><?= $cur . money($d['customer_outstanding']) ?></div><div class="sub"><span data-k="total_customers"><?= $d['total_customers'] ?></span> customers</div></a><?php endif; ?>
  <?php if (isset($d['supplier_outstanding'])): ?><a class="stat red" href="<?= e(url('parties', ['t' => 'S'])) ?>"><div class="label">Supplier Outstanding</div><div class="value" data-k="supplier_outstanding" data-m="1"><?= $cur . money($d['supplier_outstanding']) ?></div><div class="sub"><span data-k="total_suppliers"><?= $d['total_suppliers'] ?></span> suppliers</div></a><?php endif; ?>
</div>

<div class="grid grid-2">
  <?php if (isset($d['month_sales'])): ?><div class="card"><div class="card-head"><h3><?= $d['scope_sales'] === 'own' ? 'My Monthly Sales' : 'Monthly Sales' ?></h3></div><div class="chart-box"><canvas id="chSales"></canvas></div></div><?php endif; ?>
  <?php if (isset($d['month_purchase'])): ?><div class="card"><div class="card-head"><h3><?= $d['scope_purchase'] === 'own' ? 'My Monthly Purchases' : 'Monthly Purchase' ?></h3></div><div class="chart-box"><canvas id="chPur"></canvas></div></div><?php endif; ?>
</div>

<div class="grid grid-3">
<?php if (isset($d['profit_month'])): ?>
  <div class="card"><div class="card-head"><h3>Profit Summary</h3><?php if (can('report.financial')): ?><a class="btn btn-sm" href="<?= e(url('report', ['r' => 'pnl'])) ?>">P&amp;L</a><?php endif; ?></div>
    <table class="table compact" id="profitTbl"><thead><tr><th></th><th class="num">Today</th><th class="num">This Month</th><th class="num">This FY</th></tr></thead><tbody></tbody></table></div>
<?php endif; ?>
  <div class="card"><div class="card-head"><h3>Stock Alerts</h3><a class="btn btn-sm" href="<?= e(url('stock', ['st' => 'low'])) ?>">View all</a></div>
    <div class="btn-row" style="margin-bottom:8px"><span class="badge amber">Low: <b data-k="low_stock"><?= $d['low_stock'] ?></b></span><span class="badge red">Out of stock: <b data-k="out_of_stock"><?= $d['out_of_stock'] ?></b></span></div>
    <table class="table compact"><thead><tr><th>Product</th><th class="num">Stock</th><th class="num">Min</th></tr></thead><tbody id="lowList"></tbody></table></div>
  <?php if (isset($d['online_users'])): ?><div class="card"><div class="card-head"><h3>Users Online</h3></div><table class="table compact"><thead><tr><th>User</th><th>Computer</th><th>Last active</th></tr></thead><tbody id="onlineList"></tbody></table></div><?php endif; ?>
</div>

<div class="grid grid-2">
  <?php if ($d['recent_sales'] || can('sale.view') || can('sale.view_all')): ?>
  <div class="card"><div class="card-head"><h3>Recent Sales</h3><a class="btn btn-sm" href="<?= e(url('doc_list', ['t' => 'SALE'])) ?>">All sales</a></div>
    <div class="table-wrap"><table class="table compact"><thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>User</th><th class="num">Total</th><th class="num">Due</th></tr></thead><tbody id="recentSales"></tbody></table></div></div>
  <?php endif; ?>
  <?php if (can('purchase.view') || can('purchase.view_all')): ?>
  <div class="card"><div class="card-head"><h3>Recent Purchases</h3><a class="btn btn-sm" href="<?= e(url('doc_list', ['t' => 'PURCHASE'])) ?>">All purchases</a></div>
    <div class="table-wrap"><table class="table compact"><thead><tr><th>No.</th><th>Date</th><th>Supplier</th><th>User</th><th class="num">Total</th><th class="num">Due</th></tr></thead><tbody id="recentPur"></tbody></table></div></div>
  <?php endif; ?>
</div>

<script src="assets/vendor/chart.umd.min.js"></script>
<script>
(function(){
  const cur = BP.currency; let chS, chP;
  const mk = (id, label, color, labels, data) => new Chart(document.getElementById(id), {type:'bar', data:{labels, datasets:[{label, data, backgroundColor:color, borderRadius:4}]}, options:{maintainAspectRatio:false, plugins:{legend:{display:false}}, scales:{y:{beginAtZero:true, ticks:{callback:v=>cur+Number(v).toLocaleString('en-IN')}}}}});
  function render(d){
    document.getElementById('dUpdated').textContent = d.updated;
    document.querySelectorAll('[data-k]').forEach(el => { const v = d[el.dataset.k]; if (v !== undefined) el.textContent = el.dataset.m ? cur + BP.money(v) : v; });
    if (d.month_sales && document.getElementById('chSales')) { if (!chS) chS = mk('chSales','Sales','#2563eb',d.months,d.month_sales); else { chS.data.datasets[0].data = d.month_sales; chS.update(); } }
    if (d.month_purchase && document.getElementById('chPur')) { if (!chP) chP = mk('chPur','Purchase','#0891b2',d.months,d.month_purchase); else { chP.data.datasets[0].data = d.month_purchase; chP.update(); } }
    const row = (r, t) => `<tr><td><a href="index.php?p=doc_view&id=${r.id}">${BP.esc(r.doc_no)}</a></td><td>${BP.esc(r.doc_date.split('-').reverse().join('-'))}</td><td>${BP.esc(r.party||'')}</td><td>${BP.esc(r.created_by_name||'')}</td><td class="num">${BP.money(r.grand_total)}</td><td class="num ${+r.due_amount>0?'text-danger':''}">${BP.money(r.due_amount)}</td></tr>`;
    const rs = document.getElementById('recentSales'); if (rs) rs.innerHTML = d.recent_sales.map(row).join('') || '<tr><td colspan="6" class="empty">No sales yet</td></tr>';
    const rp = document.getElementById('recentPur'); if (rp) rp.innerHTML = d.recent_purchases.map(row).join('') || '<tr><td colspan="6" class="empty">No purchases yet</td></tr>';
    document.getElementById('lowList').innerHTML = d.low_list.map(p => `<tr><td><a href="index.php?p=product&id=${p.id}&view=1">${BP.esc(p.name)}</a></td><td class="num ${+p.current_stock<=0?'text-danger bold':'text-warning'}">${+p.current_stock} ${BP.esc(p.unit||'')}</td><td class="num">${+p.min_stock}</td></tr>`).join('') || '<tr><td colspan="3" class="empty">All stock levels OK</td></tr>';
    if (d.online_users && document.getElementById('onlineList')) document.getElementById('onlineList').innerHTML = d.online_users.map(u => `<tr><td>${BP.esc(u.full_name)}</td><td>${BP.esc(u.device_name||'')}</td><td>${BP.esc(u.last_seen.substring(11,16))}</td></tr>`).join('');
    const pt = document.querySelector('#profitTbl tbody');
    if (pt && d.profit_month) {
      const L = [['Net Sales','net_sales'],['Cost of Goods','cogs'],['Gross Profit','gross_profit'],['Expenses','expenses'],['Net Profit','net_profit']];
      pt.innerHTML = L.map(([l,k]) => `<tr${k.includes('profit')?' class="bold"':''}><td>${l}</td>${['profit_today','profit_month','profit_fy'].map(p=>`<td class="num ${k==='net_profit'&&d[p][k]<0?'text-danger':''}">${BP.money(d[p][k])}</td>`).join('')}</tr>`).join('');
    }
  }
  render(<?= json_encode($d) ?>);
  setInterval(() => BP.api('dashboard', {}, 'GET').then(j => render(j.data)).catch(()=>{}), <?= $refresh * 1000 ?>);
})();
</script>
