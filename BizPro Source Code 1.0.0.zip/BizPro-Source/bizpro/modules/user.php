<?php
$me = current_user();
$id = (int)($_GET['id'] ?? 0);
$u = $id ? row('SELECT * FROM users WHERE id=? AND is_deleted=0', [$id]) : null;
if ($id && !$u) throw new AppException('User not found.');
$roles = rows('SELECT * FROM roles ORDER BY id');
$catalog = perm_catalog();
$adminRoleId = (int)val("SELECT id FROM roles WHERE name='Admin'");
$countAdmins = fn() => (int)val('SELECT COUNT(*) FROM users WHERE role_id=? AND is_active=1 AND is_deleted=0', [$adminRoleId]);

if (is_post()) {
    if (in('action') === 'delete') {
        if (!$u) throw new AppException('User not found.');
        if ($id === (int)$me['id']) throw new AppException('You cannot delete your own account.');
        if ((int)$u['role_id'] === $adminRoleId && $countAdmins() <= 1) throw new AppException('At least one active Admin user is required.');
        update('users', ['is_deleted' => 1, 'is_active' => 0, 'username' => $u['username'] . '~del' . $id, 'modified_by' => $me['id'], 'modified_at' => now()], 'id=?', [$id]);
        q('UPDATE user_sessions SET is_active=0, logout_at=? WHERE user_id=? AND is_active=1', [now(), $id]);
        audit('DELETE', 'user', $id, $u['username']);
        flash('success', 'User ' . $u['username'] . ' deleted. Their past transactions are preserved.');
        redirect(url('users'));
    }
    $data = [
        'username' => strtolower(trim((string)in('username'))), 'full_name' => trim((string)in('full_name')),
        'email' => trim((string)in('email')) ?: null, 'mobile' => trim((string)in('mobile')) ?: null,
        'role_id' => ini('role_id'), 'is_active' => in('is_active') ? 1 : 0, 'must_change_pw' => in('must_change_pw') ? 1 : 0,
    ];
    $errs = [];
    if (!preg_match('/^[a-z0-9._-]{3,50}$/', $data['username'])) $errs[] = 'Username must be 3-50 characters (letters, numbers, . _ -).';
    if ($data['full_name'] === '') $errs[] = 'Full name is required.';
    if (!val('SELECT id FROM roles WHERE id=?', [$data['role_id']])) $errs[] = 'Select a role.';
    if ($data['email'] && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) $errs[] = 'Invalid email.';
    if (val('SELECT id FROM users WHERE username=? AND id<>?', [$data['username'], $id])) $errs[] = 'Username already exists.';
    $pw = (string)in('password');
    if (!$u && $pw === '') $errs[] = 'Password is required for a new user.';
    if ($pw !== '') { if ($pe = password_policy($pw)) $errs[] = $pe; if ($pw !== (string)in('password2')) $errs[] = 'Passwords do not match.'; }
    if ($u && $id === (int)$me['id'] && (!$data['is_active'] || $data['role_id'] !== (int)$u['role_id'])) $errs[] = 'You cannot disable yourself or change your own role.';
    if ($u && (int)$u['role_id'] === $adminRoleId && ($data['role_id'] !== $adminRoleId || !$data['is_active']) && $countAdmins() <= 1) $errs[] = 'At least one active Admin user is required.';
    if ($errs) throw new AppException(implode(' ', $errs));

    tx(function () use (&$id, $u, $data, $pw, $me, $catalog) {
        if ($pw !== '') $data['password_hash'] = password_hash($pw, PASSWORD_DEFAULT);
        if ($u) {
            $data += ['modified_by' => $me['id'], 'modified_at' => now()];
            if ($pw !== '') $data += ['failed_logins' => 0, 'locked_until' => null];
            update('users', $data, 'id=?', [$id]);
            $diff = [];
            foreach (['username', 'full_name', 'email', 'mobile', 'role_id', 'is_active', 'must_change_pw'] as $k) if ((string)$u[$k] !== (string)$data[$k]) $diff[$k] = [$u[$k], $data[$k]];
            audit('EDIT', 'user', $id, $data['username'], $diff);
            if ($pw !== '') audit('RESET_PASSWORD', 'user', $id, $data['username']);
            if (!$data['is_active']) q('UPDATE user_sessions SET is_active=0, logout_at=? WHERE user_id=? AND is_active=1', [now(), $id]);
        } else {
            $id = insert('users', $data + ['created_by' => $me['id'], 'created_at' => now()]);
            audit('CREATE', 'user', $id, $data['username'], ['role_id' => $data['role_id']]);
        }
        // individual permission overrides
        $before = [];
        foreach (rows('SELECT perm, allow FROM user_permissions WHERE user_id=?', [$id]) as $o) $before[$o['perm']] = (int)$o['allow'];
        q('DELETE FROM user_permissions WHERE user_id=?', [$id]);
        $after = [];
        $valid = all_perm_keys();
        foreach ((array)($_POST['ov'] ?? []) as $perm => $v) {
            if (!in_array($perm, $valid, true) || !in_array($v, ['1', '0'], true)) continue;
            insert('user_permissions', ['user_id' => $id, 'perm' => $perm, 'allow' => (int)$v]);
            $after[$perm] = (int)$v;
        }
        if ($before != $after) audit('PERMISSIONS', 'user', $id, $data['username'], ['before' => $before, 'after' => $after]);
    });
    if ($id === (int)$me['id']) $_SESSION['user']['perms'] = load_user_perms($id, (int)$data['role_id']);
    flash('success', 'User saved.');
    redirect(url('user', ['id' => $id]));
}
$title = $u ? 'Edit User: ' . $u['username'] : 'New User';
$ov = [];
if ($u) foreach (rows('SELECT perm, allow FROM user_permissions WHERE user_id=?', [$id]) as $o) $ov[$o['perm']] = (string)$o['allow'];
$rolePerms = [];
foreach (rows('SELECT role_id, perm FROM role_permissions') as $rp) $rolePerms[$rp['role_id']][] = $rp['perm'];
$rolePerms[$adminRoleId] = all_perm_keys();
$curRole = (int)($u['role_id'] ?? ($roles[1]['id'] ?? $roles[0]['id']));
?>
<form method="post" class="card" autocomplete="off"><?= csrf_field() ?>
  <div class="card-head"><h3><?= e($title) ?></h3><div class="btn-row"><a class="btn" href="<?= e(url('users')) ?>" data-cancel>Back</a><button class="btn btn-primary">Save User (Ctrl+S)</button></div></div>
  <div class="form-grid cols-4">
    <div class="fg"><label class="req">Username</label><input name="username" required value="<?= e($u['username'] ?? '') ?>" pattern="[A-Za-z0-9._-]{3,50}"></div>
    <div class="fg"><label class="req">Full Name</label><input name="full_name" required value="<?= e($u['full_name'] ?? '') ?>"></div>
    <div class="fg"><label>Email</label><input type="email" name="email" value="<?= e($u['email'] ?? '') ?>"></div>
    <div class="fg"><label>Mobile</label><input name="mobile" value="<?= e($u['mobile'] ?? '') ?>"></div>
    <div class="fg"><label class="req">Role</label><select name="role_id" id="roleSel"><?php foreach ($roles as $r) echo '<option value="' . $r['id'] . '"' . ($curRole === (int)$r['id'] ? ' selected' : '') . '>' . e($r['name']) . '</option>'; ?></select></div>
    <div class="fg"><label <?= $u ? '' : 'class="req"' ?>><?= $u ? 'Reset Password (leave blank to keep)' : 'Password' ?></label><input type="password" name="password" autocomplete="new-password" <?= $u ? '' : 'required' ?>></div>
    <div class="fg"><label>Confirm Password</label><input type="password" name="password2" autocomplete="new-password"></div>
    <div class="fg"><label class="check"><input type="checkbox" name="is_active" value="1" <?= ($u['is_active'] ?? 1) ? 'checked' : '' ?>> Active</label>
      <label class="check"><input type="checkbox" name="must_change_pw" value="1" <?= ($u['must_change_pw'] ?? 1) ? 'checked' : '' ?>> Must change password at next login</label></div>
  </div>
  <p class="muted small">Password: minimum 6 characters with letters and numbers. Passwords are stored as secure one-way hashes.</p>
  <h3>Individual Permissions</h3>
  <p class="muted small">Each permission follows the selected role by default. Choose <b>Allow</b> or <b>Deny</b> to override it for this user only. Admin role always has full access.</p>
  <div class="btn-row" style="margin-bottom:8px"><button type="button" class="btn btn-sm" onclick="document.querySelectorAll('.ovsel').forEach(s=>s.value='')">Reset all to role default</button></div>
  <div class="perm-grid">
  <?php foreach ($catalog as $g => $perms): ?>
    <div class="perm-group"><h4><?= e($g) ?></h4>
    <?php foreach ($perms as $pk => $pl): ?>
      <div class="perm-row"><select name="ov[<?= e($pk) ?>]" class="ovsel"><option value="">Role</option><option value="1" <?= ($ov[$pk] ?? '') === '1' ? 'selected' : '' ?>>Allow</option><option value="0" <?= ($ov[$pk] ?? '') === '0' ? 'selected' : '' ?>>Deny</option></select>
        <span><?= e($pl) ?></span> <span class="from-role" data-perm="<?= e($pk) ?>"></span></div>
    <?php endforeach; ?></div>
  <?php endforeach; ?>
  </div>
</form>
<?php if ($u && $id !== (int)$me['id']): ?>
<form method="post" class="card" data-confirm="Delete user <?= e($u['username']) ?>? Their transactions will be kept." data-danger="1"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><button class="btn btn-danger">Delete User</button></form>
<?php endif; ?>
<script>
const ROLE_PERMS = <?= json_encode($rolePerms) ?>;
function showRole() {
  const rp = ROLE_PERMS[document.getElementById('roleSel').value] || [];
  document.querySelectorAll('.from-role').forEach(s => { const on = rp.includes(s.dataset.perm); s.textContent = on ? '(role: yes)' : '(role: no)'; s.style.color = on ? 'var(--success)' : 'var(--muted)'; });
}
document.getElementById('roleSel').addEventListener('change', showRole); showRole();
BP.onSave = () => document.querySelector('form.card').requestSubmit();
</script>
