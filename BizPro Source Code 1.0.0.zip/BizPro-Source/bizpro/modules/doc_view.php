<?php
$id = (int)($_GET['id'] ?? 0);
$d = row('SELECT d.*, pa.name party, pa.code party_code, pa.mobile, pa.gstin party_gstin, pa.address party_address, pa.state party_state, a.name account, a2.name to_account, ec.name exp_cat
  FROM documents d LEFT JOIN parties pa ON pa.id=d.party_id LEFT JOIN accounts a ON a.id=d.account_id LEFT JOIN accounts a2 ON a2.id=d.to_account_id LEFT JOIN expense_categories ec ON ec.id=d.expense_category_id WHERE d.id=?', [$id]);
if (!$d) throw new AppException('Document not found.');
[$canView, $own] = doc_view_scope($d['dtype']);
if (!$canView && !can(perm_for($d['dtype'], 'add'))) throw new AppException('Access denied.');
if ($own && $d['created_by'] != current_user()['id']) throw new AppException('You can only view entries created by you.');
if ($d['is_deleted'] && !can('recycle.manage')) throw new AppException('This document has been deleted.');
$cfg = dt($d['dtype']);
$title = $cfg['label'] . ' ' . $d['doc_no'];
$items = rows('SELECT * FROM document_items WHERE document_id=? ORDER BY line_no', [$id]);
$returns = rows('SELECT id, dtype, doc_no, doc_date, grand_total FROM documents WHERE against_doc_id=? AND is_deleted=0', [$id]);
$against = $d['against_doc_id'] ? row('SELECT id, doc_no FROM documents WHERE id=?', [$d['against_doc_id']]) : null;
$trail = can('audit.view') || is_admin() ? rows('SELECT * FROM audit_log WHERE record_id=? AND module=? ORDER BY id', [$id, $d['dtype']]) : [];
$autoPrint = ($_SESSION['auto_print'] ?? 0) == $id; unset($_SESSION['auto_print']);
$isItem = $cfg['items'];
$isAdj = $d['dtype'] === 'ADJ';
?>
<?php if ($d['is_deleted']): ?><div class="alert alert-danger">DELETED by <?= e($d['deleted_by_name']) ?> on <?= dmyhm($d['deleted_at']) ?>. Reason: <?= e($d['delete_reason'] ?: '-') ?>. <a href="<?= e(url('recycle')) ?>">Open Recycle Bin</a></div><?php endif; ?>
<div class="card">
  <div class="card-head"><h3><?= e($cfg['label']) ?> <span class="badge blue"><?= e($d['doc_no']) ?></span> <?php if ($d['dtype'] === 'SALE' || $d['dtype'] === 'PURCHASE') echo status_badge((float)$d['due_amount'], (float)$d['grand_total']); ?></h3>
    <div class="btn-row">
      <?php if (!$isAdj): ?>
        <a class="btn btn-primary" target="_blank" href="print.php?id=<?= $id ?>">Print A4</a>
        <?php if ($isItem): ?><a class="btn" target="_blank" href="print.php?id=<?= $id ?>&fmt=thermal">Print Thermal</a><?php endif; ?>
        <a class="btn" target="_blank" href="print.php?id=<?= $id ?>&pdf=1">PDF</a>
      <?php else: ?><button class="btn" onclick="window.print()">Print</button><?php endif; ?>
      <?php if ($d['dtype'] === 'SALE' && can('sret.add') && !$d['is_deleted']): ?><a class="btn" href="<?= e(url('doc_form', ['t' => 'SRET', 'against' => $id])) ?>">Sales Return</a><?php endif; ?>
      <?php if ($d['dtype'] === 'PURCHASE' && can('pret.add') && !$d['is_deleted']): ?><a class="btn" href="<?= e(url('doc_form', ['t' => 'PRET', 'against' => $id])) ?>">Purchase Return</a><?php endif; ?>
      <?php if ($d['dtype'] === 'SALE' && $d['due_amount'] > 0 && can('receipt.add')): ?><a class="btn" href="<?= e(url('voucher_form', ['t' => 'RECEIPT', 'party' => $d['party_id']])) ?>">Receive Payment</a><?php endif; ?>
      <?php if ($d['dtype'] === 'PURCHASE' && $d['due_amount'] > 0 && can('payment.add')): ?><a class="btn" href="<?= e(url('voucher_form', ['t' => 'PAYMENT', 'party' => $d['party_id']])) ?>">Make Payment</a><?php endif; ?>
      <?php if (can_edit_doc($d)): ?><a class="btn" href="<?= e(url(doc_form_page($d['dtype']), ['t' => $d['dtype'], 'id' => $id])) ?>">Edit</a><?php endif; ?>
      <?php if (can_delete_doc($d)): ?><form method="post" action="<?= e(url('doc_list', ['t' => $d['dtype']])) ?>" style="display:inline" data-confirm="Delete <?= e($cfg['label'] . ' ' . $d['doc_no']) ?>? Stock and balances will be reversed." data-danger="1" data-reason="1" data-ok="Delete"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $id ?>"><button class="btn btn-danger">Delete</button></form><?php endif; ?>
      <a class="btn" data-cancel href="<?= e(url('doc_list', ['t' => $d['dtype']])) ?>">Back</a>
    </div></div>
  <div class="grid grid-3">
    <dl class="kv">
      <dt>Date</dt><dd><?= dmy($d['doc_date']) ?></dd>
      <?php if ($d['party_id']): ?><dt><?= $cfg['ptype'] === 'C' ? 'Customer' : 'Supplier' ?></dt><dd><a href="<?= e(url('party', ['id' => $d['party_id']])) ?>"><?= e($d['party']) ?></a> <span class="muted"><?= e($d['party_code']) ?></span><br><span class="small muted"><?= e($d['mobile']) ?> <?= $d['party_gstin'] ? 'GSTIN ' . e($d['party_gstin']) : '' ?></span></dd><?php endif; ?>
      <?php if ($d['ref_invoice_no']): ?><dt>Supplier Bill No.</dt><dd><?= e($d['ref_invoice_no']) ?></dd><?php endif; ?>
      <?php if ($against): ?><dt>Against Invoice</dt><dd><a href="<?= e(url('doc_view', ['id' => $against['id']])) ?>"><?= e($against['doc_no']) ?></a></dd><?php endif; ?>
      <?php if ($d['exp_cat']): ?><dt>Expense Category</dt><dd><?= e($d['exp_cat']) ?></dd><?php endif; ?>
      <?php if ($d['entry_type']): ?><dt>Entry Type</dt><dd><?= e($d['entry_type']) ?><?= $d['to_account'] ? ' &rarr; ' . e($d['to_account']) : '' ?></dd><?php endif; ?>
      <?php if ($d['description']): ?><dt>Description</dt><dd><?= e($d['description']) ?></dd><?php endif; ?>
    </dl>
    <dl class="kv">
      <?php if (!$isAdj): ?><dt>Payment Mode</dt><dd><?= e($d['payment_mode'] ?: '-') ?></dd><dt>Account</dt><dd><?= e($d['account'] ?: '-') ?></dd><?php endif; ?>
      <?php if ($d['reference_no']): ?><dt>Reference</dt><dd><?= e($d['reference_no']) ?></dd><?php endif; ?>
      <dt><?= $isAdj ? 'Reason' : 'Remarks' ?></dt><dd><?= nl2br(e($d['remarks'] ?: '-')) ?></dd>
      <?php if ($isItem && !$isAdj): ?><dt>Tax Type</dt><dd><?= $d['is_interstate'] ? 'IGST (Inter-state)' : 'CGST + SGST' ?></dd><?php endif; ?>
    </dl>
    <dl class="kv">
      <dt>Created By</dt><dd><?= e($d['created_by_name']) ?> &middot; <?= dmyhm($d['created_at']) ?></dd>
      <dt>Computer</dt><dd><?= e($d['device_name'] ?: '-') ?></dd>
      <dt>Modified By</dt><dd><?= $d['modified_by_name'] ? e($d['modified_by_name']) . ' &middot; ' . dmyhm($d['modified_at']) . ($d['modified_device'] ? ' (' . e($d['modified_device']) . ')' : '') : '-' ?></dd>
      <dt>Version</dt><dd><?= (int)$d['row_version'] ?></dd>
    </dl>
  </div>
</div>
<?php if ($isItem): ?>
<div class="card"><div class="table-wrap"><table class="table" id="itTable">
  <thead><tr><th>#</th><th>Product</th><th>HSN</th><th class="num">Qty</th><?= $d['dtype'] === 'PURCHASE' ? '<th class="num">Free</th>' : '' ?><th>Unit</th><th class="num">Rate</th><?php if (!$isAdj): ?><th class="num">Disc</th><th class="num">Taxable</th><th class="num">GST %</th><th class="num">GST</th><?php endif; ?><th class="num">Total</th></tr></thead><tbody>
  <?php foreach ($items as $it): ?>
    <tr><td><?= $it['line_no'] ?></td><td><a href="<?= e(url('product', ['id' => $it['product_id'], 'view' => 1])) ?>"><?= e($it['product_name']) ?></a></td><td><?= e($it['hsn_code']) ?></td>
    <td class="num"><?= $isAdj ? ($it['qty'] > 0 ? '+' : '') : '' ?><?= qtyf($it['qty']) ?></td><?= $d['dtype'] === 'PURCHASE' ? '<td class="num">' . qtyf($it['free_qty']) . '</td>' : '' ?><td><?= e($it['unit']) ?></td><td class="num"><?= money($it['rate']) ?></td>
    <?php if (!$isAdj): ?><td class="num"><?= money($it['disc_amt']) ?><?= $it['disc_pct'] > 0 ? ' <small class="muted">(' . (float)$it['disc_pct'] . '%)</small>' : '' ?></td><td class="num"><?= money($it['taxable']) ?></td><td class="num"><?= (float)$it['gst_pct'] ?></td><td class="num"><?= money($it['gst_amt']) ?></td><?php endif; ?>
    <td class="num"><?= money($isAdj ? $it['amount'] : $it['total']) ?></td></tr>
  <?php endforeach; ?></tbody></table></div>
  <?php if (!$isAdj): ?>
  <div class="grid" style="grid-template-columns:1fr 340px;margin-top:10px">
    <div class="muted small"><b>Amount in words:</b> <?= e(amount_in_words((float)$d['grand_total'])) ?></div>
    <table class="table totals"><tbody>
      <tr><td>Sub Total</td><td class="num"><?= money($d['subtotal']) ?></td></tr>
      <tr><td>Item Discount</td><td class="num">- <?= money($d['item_discount']) ?></td></tr>
      <tr><td>Taxable Value</td><td class="num"><?= money($d['taxable_amount']) ?></td></tr>
      <?php if ($d['is_interstate']): ?><tr><td>IGST</td><td class="num"><?= money($d['igst']) ?></td></tr><?php else: ?><tr><td>CGST</td><td class="num"><?= money($d['cgst']) ?></td></tr><tr><td>SGST</td><td class="num"><?= money($d['sgst']) ?></td></tr><?php endif; ?>
      <?php if ($d['bill_discount'] > 0): ?><tr><td>Bill Discount</td><td class="num">- <?= money($d['bill_discount']) ?></td></tr><?php endif; ?>
      <?php if ($d['other_charges'] > 0): ?><tr><td>Other Charges</td><td class="num"><?= money($d['other_charges']) ?></td></tr><?php endif; ?>
      <tr><td>Round Off</td><td class="num"><?= money($d['round_off']) ?></td></tr>
      <tr class="bold"><td>Grand Total</td><td class="num"><?= money($d['grand_total']) ?></td></tr>
      <tr><td>Paid</td><td class="num"><?= money($d['paid_amount']) ?></td></tr>
      <tr class="bold"><td>Due</td><td class="num <?= $d['due_amount'] > 0 ? 'text-danger' : '' ?>"><?= money($d['due_amount']) ?></td></tr>
      <?php if (can('dashboard.profit') && in_array($d['dtype'], ['SALE'])): ?><tr class="small muted"><td>Cost / Gross margin</td><td class="num"><?= money($d['cost_total']) ?> / <?= money($d['taxable_amount'] - $d['bill_discount'] - $d['cost_total']) ?></td></tr><?php endif; ?>
    </tbody></table>
  </div>
  <?php endif; ?>
</div>
<?php else: ?>
<div class="card"><div class="stat" style="max-width:360px"><div class="label">Amount</div><div class="value"><?= money($d['grand_total']) ?></div><div class="sub"><?= e(amount_in_words((float)$d['grand_total'])) ?></div></div></div>
<?php endif; ?>
<?php if ($returns): ?>
<div class="card"><h3>Returns against this invoice</h3><table class="table"><thead><tr><th>Date</th><th>No.</th><th class="num">Amount</th></tr></thead><tbody>
<?php foreach ($returns as $r): ?><tr><td><?= dmy($r['doc_date']) ?></td><td><a href="<?= e(url('doc_view', ['id' => $r['id']])) ?>"><?= e($r['doc_no']) ?></a></td><td class="num"><?= money($r['grand_total']) ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php endif; ?>
<?php if ($trail): ?>
<div class="card"><h3>Audit Trail</h3><div class="table-wrap"><table class="table"><thead><tr><th>Date / Time</th><th>User</th><th>Computer</th><th>Action</th><th>Details</th></tr></thead><tbody>
<?php foreach ($trail as $a): ?><tr><td class="nowrap"><?= dmyhm($a['created_at']) ?></td><td><?= e($a['username']) ?></td><td><?= e($a['device_name']) ?></td><td><span class="badge"><?= e($a['action']) ?></span></td><td class="small"><details><summary>view</summary><pre style="white-space:pre-wrap;max-height:260px;overflow:auto"><?= e(json_encode(json_decode((string)$a['details'], true), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) ?></pre></details></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php endif; ?>
<?php if ($autoPrint): ?><script>window.open('print.php?id=<?= $id ?>', '_blank');</script><?php endif; ?>
