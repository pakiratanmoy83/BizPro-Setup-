<?php
// Command-line installer used by the Windows setup program.
// php cli/install.php --host=127.0.0.1 --port=3306 --db=bizpro --user=root --pass= --admin=admin --adminpass=admin123 --business="My Shop"
if (PHP_SAPI !== 'cli') exit('CLI only');
require dirname(__DIR__) . '/install/setup_lib.php';
$a = getopt('', ['host::', 'port::', 'db::', 'user::', 'pass::', 'admin::', 'adminpass::', 'business::', 'backupdir::', 'force']);
if (is_file(dirname(__DIR__) . '/config/config.php') && !isset($a['force'])) { echo "Already installed (config exists). Use --force to re-run.\n"; exit(0); }
try {
    $log = bp_run_install([
        'db_host' => $a['host'] ?? '127.0.0.1', 'db_port' => $a['port'] ?? 3306, 'db_name' => $a['db'] ?? 'bizpro',
        'db_user' => $a['user'] ?? 'root', 'db_pass' => $a['pass'] ?? '', 'admin_user' => $a['admin'] ?? 'admin',
        'admin_pass' => $a['adminpass'] ?? 'admin123', 'business_name' => $a['business'] ?? 'My Business',
    ]);
    echo implode("\n", $log), "\n";
    if (!empty($a['backupdir'])) {
        require dirname(__DIR__) . '/inc/bootstrap.php';
        @mkdir($a['backupdir'], 0775, true);
        set_setting('backup_dir', str_replace('\\', '/', $a['backupdir']));
        echo "Backup folder: {$a['backupdir']}\n";
    }
} catch (Throwable $e) { fwrite(STDERR, 'ERROR: ' . $e->getMessage() . "\n"); exit(1); }
