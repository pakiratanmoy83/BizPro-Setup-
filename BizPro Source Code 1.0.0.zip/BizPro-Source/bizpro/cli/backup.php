<?php
// Scheduled backup - run by Windows Task Scheduler on the server PC:
//   php.exe C:\BizPro\app\cli\backup.php
if (PHP_SAPI !== 'cli') exit('CLI only');
require dirname(__DIR__) . '/inc/bootstrap.php';
require dirname(__DIR__) . '/inc/backup_lib.php';
$GLOBALS['CLI_USER'] = ['id' => null, 'username' => 'scheduler', 'full_name' => 'Scheduled Task', 'role_name' => 'System', 'perms' => all_perm_keys()];
try {
    $r = create_backup('AUTO');
    echo 'Backup OK: ', $r['file'], ' (', number_format($r['size'] / 1024, 1), " KB)\n";
    exit(0);
} catch (Throwable $e) {
    try { insert('backups', ['filename' => '-', 'filepath' => '-', 'size_bytes' => 0, 'btype' => 'AUTO', 'status' => 'FAILED', 'created_by_name' => 'scheduler', 'created_at' => now()]); } catch (Throwable $x) {}
    fwrite(STDERR, 'Backup FAILED: ' . $e->getMessage() . "\n");
    exit(1);
}
