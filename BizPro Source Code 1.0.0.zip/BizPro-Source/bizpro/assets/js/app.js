/* BizPro common client script */
(function () {
  'use strict';
  const BP = window.BP || {};
  window.BP = BP;

  BP.esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  BP.money = n => (Math.round((+n || 0) * 100) / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  BP.r2 = n => Math.round(((+n || 0) + 1e-9) * 100) / 100;

  BP.toast = function (msg, type = 'success', ms = 3500) {
    const box = document.getElementById('toastBox');
    if (!box) return alert(msg);
    const t = document.createElement('div');
    t.className = 'toast ' + type; t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.remove(), ms);
  };

  BP.api = async function (action, data = {}, method = 'POST') {
    let url = 'api.php?a=' + encodeURIComponent(action);
    const opt = { method, headers: { 'X-CSRF-Token': BP.csrf } };
    if (method === 'GET') url += '&' + new URLSearchParams(data).toString();
    else { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(data); }
    const r = await fetch(url, opt);
    let j;
    try { j = await r.json(); } catch (e) { throw new Error('Server error (' + r.status + ')'); }
    if (r.status === 401) { location.href = 'login.php?timeout=1'; throw new Error('Session expired'); }
    if (!j.ok) throw new Error(j.error || 'Request failed');
    return j;
  };

  /* Modal */
  BP.modal = function ({ title, body, foot = '', wide = false, onClose }) {
    const root = document.getElementById('modalRoot');
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `<div class="modal ${wide ? 'wide' : ''}"><div class="modal-head"><h3>${BP.esc(title)}</h3><button class="icon-btn" data-close>&times;</button></div><div class="modal-body"></div>${foot ? '<div class="modal-foot"></div>' : ''}</div>`;
    const mb = back.querySelector('.modal-body');
    if (typeof body === 'string') mb.innerHTML = body; else mb.appendChild(body);
    if (foot) { const f = back.querySelector('.modal-foot'); if (typeof foot === 'string') f.innerHTML = foot; else f.appendChild(foot); }
    const close = () => { back.remove(); onClose && onClose(); };
    back.addEventListener('click', e => { if (e.target === back || e.target.hasAttribute('data-close')) close(); });
    back._close = close;
    root.appendChild(back);
    return back;
  };
  BP.closeTopModal = function () {
    const m = document.querySelectorAll('#modalRoot .modal-back');
    if (m.length) { m[m.length - 1]._close(); return true; }
    return false;
  };
  BP.confirm = function (msg, { title = 'Please confirm', ok = 'Yes, continue', danger = false, input = false } = {}) {
    return new Promise(resolve => {
      const foot = document.createElement('div');
      foot.className = 'btn-row';
      foot.innerHTML = `<button class="btn" data-no>Cancel</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-yes>${BP.esc(ok)}</button>`;
      const body = `<p>${BP.esc(msg)}</p>` + (input ? `<div class="fg"><label>${BP.esc(input)}</label><input data-inp></div>` : '');
      let done = false;
      const m = BP.modal({ title, body, foot, onClose: () => { if (!done) resolve(false); } });
      const inp = m.querySelector('[data-inp]');
      (inp || m.querySelector('[data-yes]')).focus();
      m.querySelector('[data-no]').onclick = () => m._close();
      m.querySelector('[data-yes]').onclick = () => { done = true; const v = inp ? inp.value : true; m._close(); resolve(input ? (v || ' ') : true); };
      if (inp) inp.addEventListener('keydown', e => { if (e.key === 'Enter') m.querySelector('[data-yes]').click(); });
    });
  };

  /* Confirm for forms / links marked data-confirm */
  document.addEventListener('submit', async e => {
    const f = e.target;
    if (f.dataset.confirm && !f._confirmed) {
      e.preventDefault();
      const r = await BP.confirm(f.dataset.confirm, { danger: f.dataset.danger === '1', input: f.dataset.reason ? 'Reason' : false, ok: f.dataset.ok || 'Yes, continue' });
      if (!r) return;
      if (f.dataset.reason) { let h = f.querySelector('input[name=reason]'); if (!h) { h = document.createElement('input'); h.type = 'hidden'; h.name = 'reason'; f.appendChild(h); } h.value = r.trim(); }
      f._confirmed = true;
      f.submit();
    }
  });

  /* Autocomplete */
  BP.autocomplete = function (input, { source, render, onSelect, minLen = 1, delay = 180 }) {
    const wrap = document.createElement('div');
    wrap.className = 'ac-wrap';
    input.parentNode.insertBefore(wrap, input);
    wrap.appendChild(input);
    const list = document.createElement('div');
    list.className = 'ac-list';
    wrap.appendChild(list);
    let items = [], idx = -1, timer = null, seq = 0;
    const hide = () => { clearTimeout(timer); seq++; list.classList.remove('show'); idx = -1; };
    const draw = () => {
      list.innerHTML = items.length ? items.map((it, i) => `<div class="ac-item ${i === idx ? 'active' : ''}" data-i="${i}">${render(it)}</div>`).join('') : '<div class="ac-item muted">No match</div>';
      list.classList.add('show');
      const a = list.querySelector('.active'); if (a) a.scrollIntoView({ block: 'nearest' });
    };
    const pick = i => { if (items[i]) { hide(); onSelect(items[i]); } };
    input.addEventListener('input', () => {
      const v = input.value.trim();
      hide(); // stale suggestions must never be picked by Enter
      if (v.length < minLen) return;
      timer = setTimeout(async () => { const my = ++seq; const r = await source(v); if (my !== seq) return; items = r; idx = items.length ? 0 : -1; draw(); }, delay);
    });
    input.addEventListener('keydown', e => {
      if (!list.classList.contains('show')) return;
      if (e.key === 'ArrowDown') { idx = Math.min(items.length - 1, idx + 1); draw(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { idx = Math.max(0, idx - 1); draw(); e.preventDefault(); }
      else if (e.key === 'Enter') { if (idx >= 0) { e.preventDefault(); e.stopPropagation(); pick(idx); } }
      else if (e.key === 'Escape') { hide(); e.stopPropagation(); }
    });
    list.addEventListener('mousedown', e => { const it = e.target.closest('[data-i]'); if (it) { e.preventDefault(); pick(+it.dataset.i); } });
    input.addEventListener('blur', () => setTimeout(hide, 150));
    return { hide, refresh: () => input.dispatchEvent(new Event('input')) };
  };

  BP.productSource = async q => (await BP.api('product_search', { q }, 'GET')).items;
  BP.productRender = p => `<span><b>${BP.esc(p.name)}</b> <small>${BP.esc(p.code)}${p.barcode ? ' | ' + BP.esc(p.barcode) : ''}</small></span><small>Stock: <b class="${+p.current_stock <= 0 ? 'text-danger' : ''}">${BP.esc(p.stock_fmt)}</b> | ${BP.money(p.sale_rate)}</small>`;
  BP.partySource = t => async q => (await BP.api('party_search', { q, t }, 'GET')).items;
  BP.partyRender = p => `<span><b>${BP.esc(p.name)}</b> <small>${BP.esc(p.code)} ${BP.esc(p.mobile || '')}</small></span><small>Bal: ${BP.money(p.balance)}</small>`;

  /* Quick lookup modals (F2/F3/F4) */
  BP.lookup = function (kind) {
    const labels = { product: 'Search Product (F2)', C: 'Customer Search (F3)', S: 'Supplier Search (F4)' };
    const body = document.createElement('div');
    body.innerHTML = `<input placeholder="Type name, code, barcode or mobile..." data-q><div style="margin-top:10px" data-res class="table-wrap"><div class="empty">Start typing to search</div></div>`;
    const m = BP.modal({ title: labels[kind], body, wide: true });
    const inp = body.querySelector('[data-q]'), res = body.querySelector('[data-res]');
    inp.focus();
    let t;
    inp.addEventListener('input', () => {
      clearTimeout(t);
      t = setTimeout(async () => {
        const q = inp.value.trim();
        if (!q) return;
        try {
          if (kind === 'product') {
            const items = await BP.productSource(q);
            res.innerHTML = `<table class="table"><thead><tr><th>Code</th><th>Barcode</th><th>Product</th><th>Category</th><th class="num">Stock</th><th class="num">Sale Rate</th><th class="num">MRP</th><th></th></tr></thead><tbody>${items.map(p => `<tr><td>${BP.esc(p.code)}</td><td>${BP.esc(p.barcode || '')}</td><td>${BP.esc(p.name)}</td><td>${BP.esc(p.category || '')}</td><td class="num ${+p.current_stock <= +p.min_stock ? 'text-danger bold' : ''}">${BP.esc(p.stock_fmt)}</td><td class="num">${BP.money(p.sale_rate)}</td><td class="num">${BP.money(p.mrp)}</td><td><a class="btn btn-sm" href="index.php?p=product&id=${p.id}&view=1">Open</a></td></tr>`).join('') || '<tr><td colspan="8" class="empty">No products found</td></tr>'}</tbody></table>`;
          } else {
            const items = await BP.partySource(kind)(q);
            res.innerHTML = `<table class="table"><thead><tr><th>Code</th><th>Name</th><th>Mobile</th><th>GSTIN</th><th class="num">Balance</th><th></th></tr></thead><tbody>${items.map(p => `<tr><td>${BP.esc(p.code)}</td><td>${BP.esc(p.name)}</td><td>${BP.esc(p.mobile || '')}</td><td>${BP.esc(p.gstin || '')}</td><td class="num">${BP.money(p.balance)}</td><td><a class="btn btn-sm" href="index.php?p=party&id=${p.id}">Ledger</a></td></tr>`).join('') || '<tr><td colspan="6" class="empty">No match</td></tr>'}</tbody></table>`;
          }
        } catch (e) { res.innerHTML = `<div class="alert alert-danger">${BP.esc(e.message)}</div>`; }
      }, 200);
    });
    return m;
  };

  /* Keyboard shortcuts */
  const go = u => location.href = u;
  document.addEventListener('keydown', e => {
    const k = e.key;
    if (k === 'F1') { e.preventDefault(); go('index.php?p=help'); }
    else if (k === 'F2') { e.preventDefault(); if (BP.onF2) BP.onF2(); else if (BP.perms.product) BP.lookup('product'); }
    else if (k === 'F3') { e.preventDefault(); if (BP.perms.customer) BP.lookup('C'); }
    else if (k === 'F4') { e.preventDefault(); if (BP.perms.supplier) BP.lookup('S'); }
    else if (k === 'F5') { e.preventDefault(); if (BP.perms.sale) go('index.php?p=doc_form&t=SALE'); else BP.toast('No permission for sales', 'warning'); }
    else if (k === 'F6') { e.preventDefault(); if (BP.perms.purchase) go('index.php?p=doc_form&t=PURCHASE'); else BP.toast('No permission for purchase', 'warning'); }
    else if (k === 'F7') { e.preventDefault(); if (BP.perms.receipt) go('index.php?p=voucher_form&t=RECEIPT'); else BP.toast('No permission for receipts', 'warning'); }
    else if (k === 'F8') { e.preventDefault(); if (BP.perms.payment) go('index.php?p=voucher_form&t=PAYMENT'); else BP.toast('No permission for payments', 'warning'); }
    else if ((e.ctrlKey || e.metaKey) && k.toLowerCase() === 's') {
      e.preventDefault();
      if (BP.onSave) return BP.onSave();
      const f = document.querySelector('form[data-save]');
      if (f) { if (f.requestSubmit) f.requestSubmit(); else f.submit(); }
    }
    else if ((e.ctrlKey || e.metaKey) && k.toLowerCase() === 'p') {
      if (BP.onPrint) { e.preventDefault(); BP.onPrint(); }
    }
    else if (k === 'Escape') {
      if (BP.closeTopModal()) { e.preventDefault(); return; }
      document.querySelectorAll('.user-menu.open').forEach(x => x.classList.remove('open'));
      const c = document.querySelector('[data-cancel]');
      if (c && !document.querySelector('.ac-list.show')) { e.preventDefault(); c.click(); }
    }
  });
  document.addEventListener('click', e => { if (!e.target.closest('.user-menu')) document.querySelectorAll('.user-menu.open').forEach(x => x.classList.remove('open')); });

  /* Global product search in topbar */
  const initGlobal = () => {
    const gs = document.getElementById('globalProductSearch');
    if (!gs) return;
    if (!BP.perms.product) gs.parentNode.style.display = 'none';
    else BP.autocomplete(gs, { source: BP.productSource, render: BP.productRender, onSelect: p => go('index.php?p=product&id=' + p.id + '&view=1') });
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initGlobal); else initGlobal();

  /* Lazy load vendor scripts */
  const loaded = {};
  BP.load = src => loaded[src] || (loaded[src] = new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); }));

  /* Export any table to Excel / PDF */
  BP.exportExcel = async function (tableSel, filename, title) {
    await BP.load('assets/vendor/xlsx.full.min.js');
    const t = document.querySelector(tableSel);
    const clone = t.cloneNode(true);
    clone.querySelectorAll('.no-export').forEach(n => n.remove());
    clone.querySelectorAll('td.num, th.num').forEach(td => { const v = td.textContent.replace(/,/g, '').trim(); if (v !== '' && !isNaN(v)) td.setAttribute('data-v', v), td.setAttribute('t', 'n'); });
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.table_to_sheet(clone, { raw: false });
    XLSX.utils.sheet_add_aoa(ws, [], { origin: -1 });
    XLSX.utils.book_append_sheet(wb, ws, (title || 'Report').substring(0, 30).replace(/[\\/?*\[\]:]/g, ''));
    XLSX.writeFile(wb, (filename || 'report') + '.xlsx');
  };
  BP.exportPDF = async function (tableSel, filename, title, subtitle) {
    await BP.load('assets/vendor/jspdf.umd.min.js');
    await BP.load('assets/vendor/jspdf.plugin.autotable.min.js');
    const { jsPDF } = window.jspdf;
    const t = document.querySelector(tableSel);
    const cols = t.querySelectorAll('thead th:not(.no-export)').length;
    const doc = new jsPDF({ orientation: cols > 7 ? 'landscape' : 'portrait', unit: 'pt', format: 'a4' });
    doc.setFontSize(14); doc.text(BP.biz || 'BizPro', 40, 36);
    doc.setFontSize(11); doc.text(title || '', 40, 54);
    if (subtitle) { doc.setFontSize(9); doc.setTextColor(100); doc.text(subtitle, 40, 68); doc.setTextColor(0); }
    const clone = t.cloneNode(true);
    clone.querySelectorAll('.no-export').forEach(n => n.remove());
    clone.querySelectorAll('td,th').forEach(c => c.textContent = c.textContent.replace(/₹/g, 'Rs.'));
    const numIdx = [...clone.querySelectorAll('thead th')].map((th, i) => th.classList.contains('num') ? i : -1).filter(i => i >= 0);
    const colStyles = {}; numIdx.forEach(i => colStyles[i] = { halign: 'right' });
    doc.autoTable({ html: clone, startY: 78, styles: { fontSize: 8, cellPadding: 3 }, headStyles: { fillColor: [29, 78, 216] }, footStyles: { fillColor: [241, 245, 249], textColor: 20, fontStyle: 'bold' }, columnStyles: colStyles, showFoot: 'lastPage',
      didDrawPage: d => { doc.setFontSize(8); doc.setTextColor(120); doc.text('Printed ' + new Date().toLocaleString('en-IN') + '  |  Page ' + doc.internal.getNumberOfPages(), 40, doc.internal.pageSize.height - 20); doc.setTextColor(0); } });
    doc.save((filename || 'report') + '.pdf');
  };
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-export]');
    if (!b) return;
    e.preventDefault();
    const fn = b.dataset.export === 'pdf' ? BP.exportPDF : BP.exportExcel;
    fn(b.dataset.table || '#reportTable', b.dataset.file, b.dataset.title, b.dataset.sub).catch(err => BP.toast('Export failed: ' + err.message, 'danger'));
  });

  /* Auto hide flash messages */
  setTimeout(() => document.querySelectorAll('.alert.flash.alert-success').forEach(a => a.style.display = 'none'), 5000);

  /* Session keep-alive / check every 2 minutes */
  setInterval(() => { BP.api('ping', {}, 'GET').catch(() => {}); }, 120000);
})();
