/* Billing / item-entry screen for Sales, Purchase, Returns and Stock Adjustment */
(function () {
  'use strict';
  const C = window.DOC, T = C.dtype;
  const $ = id => document.getElementById(id);
  const isAdj = T === 'ADJ', isRet = T === 'SRET' || T === 'PRET', isPur = T === 'PURCHASE';
  const state = { items: [], party: C.party || null, against: C.against || null, holdId: null, saving: false, interstate: false, returnable: null };
  const tbody = document.querySelector('#itemsTable tbody');
  const r2 = BP.r2, r3 = n => Math.round((+n || 0) * 1000) / 1000;

  /* ---------- party ---------- */
  function setParty(p) {
    state.party = p;
    const inp = $('partyInput'); if (!inp) return;
    inp.value = p ? p.name + (p.mobile ? ' (' + p.mobile + ')' : '') : '';
    const info = $('partyInfo');
    if (p) {
      const biz = (C.bizState || '').trim().toLowerCase(), st = (p.state || '').trim().toLowerCase();
      state.interstate = !!(biz && st && biz !== st);
      const lim = +p.credit_limit > 0 ? ' | Credit limit: ' + BP.money(p.credit_limit) : '';
      info.innerHTML = `${BP.esc(p.code)} ${p.gstin ? '| GSTIN ' + BP.esc(p.gstin) : ''} | ${C.ptype === 'C' ? 'Receivable' : 'Payable'}: <b class="${+p.balance > 0 ? 'text-danger' : ''}">${BP.money(p.balance)}</b>${lim}${state.interstate ? ' | <span class="badge amber">Inter-state (IGST)</span>' : ''}${+p.is_system ? ' | <span class="badge">Cash customer - full payment required</span>' : ''}`;
    } else { info.textContent = ''; state.interstate = false; }
    calc();
  }
  if ($('partyInput')) {
    BP.autocomplete($('partyInput'), { source: BP.partySource(C.ptype), render: BP.partyRender, onSelect: p => { setParty(p); $('scanInput').focus(); } });
    $('partyInput').addEventListener('focus', e => e.target.select());
    BP.onF3 = null;
  }
  if ($('quickParty')) $('quickParty').onclick = quickParty;
  function quickParty() {
    const lbl = C.ptype === 'C' ? 'Customer' : 'Supplier';
    const body = `<div class="form-grid cols-2"><div class="fg"><label class="req">Name</label><input data-f="name"></div><div class="fg"><label>Mobile</label><input data-f="mobile"></div><div class="fg"><label>GSTIN</label><input data-f="gstin" maxlength="15"></div><div class="fg"><label>State</label><input data-f="state" value="${BP.esc(C.bizState)}"></div><div class="fg span-2"><label>Address</label><input data-f="address"></div></div>`;
    const foot = '<div class="btn-row"><button class="btn" data-close>Cancel</button><button class="btn btn-primary" data-ok>Save ' + lbl + '</button></div>';
    const m = BP.modal({ title: 'New ' + lbl, body, foot });
    const f = k => m.querySelector(`[data-f="${k}"]`);
    f('name').value = ($('partyInput').value || '').replace(/\s*\(.*$/, ''); f('name').focus();
    m.querySelector('[data-ok]').onclick = async () => {
      try {
        const data = { ptype: C.ptype }; ['name', 'mobile', 'gstin', 'state', 'address'].forEach(k => data[k] = f(k).value);
        const r = await BP.api('party_quick_add', data);
        const info = await BP.api('party_info', { id: r.id }, 'GET');
        m._close(); setParty(info.party); BP.toast(lbl + ' created'); $('scanInput').focus();
      } catch (e) { BP.toast(e.message, 'danger'); }
    };
  }

  /* ---------- against invoice (returns) ---------- */
  if (isRet) {
    const src = T === 'SRET' ? 'SALE' : 'PURCHASE';
    BP.autocomplete($('againstInput'), {
      source: async q => (await BP.api('invoice_search', { q, t: src, party_id: state.party ? state.party.id : '' }, 'GET')).items,
      render: d => `<span><b>${BP.esc(d.doc_no)}</b> <small>${BP.esc(d.ref_invoice_no || '')} ${BP.esc(d.party)}</small></span><small>${BP.esc(d.doc_date)} | ${BP.money(d.grand_total)}</small>`,
      onSelect: d => loadAgainst(d.id, true), minLen: 1,
    });
    $('clearAgainst').onclick = () => { state.against = null; state.returnable = null; $('againstInput').value = ''; $('againstInfo').textContent = ''; render(); };
  }
  async function loadAgainst(id, fill) {
    try {
      const r = await BP.api('doc_items', { id }, 'GET');
      state.against = { id: r.doc.id, doc_no: r.doc.doc_no };
      state.returnable = {};
      r.items.forEach(i => state.returnable[i.product_id] = (state.returnable[i.product_id] || 0) + (+i.returnable));
      if (C.id) C.items.forEach(i => state.returnable[i.product_id] = (state.returnable[i.product_id] || 0) + (+i.qty)); // editing: own qty counts
      $('againstInput').value = r.doc.doc_no;
      $('againstInfo').textContent = 'Invoice ' + r.doc.doc_no + ' dated ' + r.doc.doc_date + '. Returnable quantities shown.';
      if (!state.party || state.party.id != r.doc.party_id) { const pi = await BP.api('party_info', { id: r.doc.party_id }, 'GET'); setParty(pi.party); }
      if (fill) {
        state.items = r.items.filter(i => +i.returnable > 0).map(i => ({ product_id: +i.product_id, name: i.name, code: i.code, unit: i.unit, qty: +i.returnable, free_qty: 0, rate: +i.rate, disc_pct: +i.disc_pct, disc_amt: 0, gst_pct: +i.gst_pct, stock: +i.current_stock }));
        if (!state.items.length) BP.toast('All items of this invoice are already returned', 'warning');
      }
      render();
    } catch (e) { BP.toast(e.message, 'danger'); }
  }

  /* ---------- products ---------- */
  function addProduct(p, qty = 1) {
    const ex = state.items.find(i => i.product_id == p.id);
    if (ex && !isAdj) { ex.qty = r3(+ex.qty + qty); render(state.items.indexOf(ex)); flash(state.items.indexOf(ex)); return; }
    const rate = isAdj ? +p.purchase_rate : +p[C.rateField];
    state.items.push({ product_id: +p.id, name: p.name, code: p.code, unit: p.unit || '', qty: qty, adj_sign: 1, free_qty: 0, rate: rate, disc_pct: 0, disc_amt: 0, gst_pct: +p.gst_pct, stock: +p.current_stock, mrp: +p.mrp });
    render(state.items.length - 1);
    if (C.stockCheck && +p.current_stock <= 0) BP.toast(p.name + ': out of stock (' + p.current_stock + ')', 'warning');
  }
  function flash(i) { const tr = tbody.children[i]; if (tr) { tr.classList.add('flash-row'); setTimeout(() => tr.classList.remove('flash-row'), 600); } }
  const scan = $('scanInput');
  const ac = BP.autocomplete(scan, { source: BP.productSource, render: BP.productRender, onSelect: p => { addProduct(p); scan.value = ''; } });
  scan.addEventListener('keydown', async e => {
    if (e.key !== 'Enter' || document.querySelector('.ac-list.show .ac-item.active')) return;
    e.preventDefault();
    let v = scan.value.trim(); if (!v) return;
    let qty = 1; const m = v.match(/^(\d+(?:\.\d+)?)\*(.+)$/); if (m) { qty = +m[1]; v = m[2].trim(); } // 5*barcode = qty 5
    try {
      ac.hide();
      const r = await BP.api('product_by_code', { code: v }, 'GET');
      let item = r.item;
      if (!item) { const s = await BP.productSource(v); if (s.length === 1) item = s[0]; else if (s.length > 1) { ac.refresh(); return; } }
      if (item) { addProduct(item, qty); scan.value = ''; ac.hide(); }
      else { BP.toast('No product with barcode/code "' + v + '"', 'warning'); scan.select(); }
    } catch (err) { BP.toast(err.message, 'danger'); }
  });
  BP.onF2 = () => { scan.focus(); scan.select(); };

  /* ---------- grid ---------- */
  function lineCalc(it) {
    const q = Math.abs(+it.qty || 0);
    const amount = r2(q * (+it.rate || 0));
    let disc = +it.disc_pct > 0 ? r2(amount * Math.min(100, +it.disc_pct) / 100) : 0;
    if (disc > amount) disc = amount;
    const taxable = r2(amount - disc);
    const gst = isAdj ? 0 : r2(taxable * (+it.gst_pct || 0) / 100);
    return { amount, disc, taxable, gst, total: r2(taxable + gst) };
  }
  function render(focusIdx) {
    tbody.innerHTML = state.items.map((it, i) => {
      const lc = lineCalc(it);
      const low = C.stockCheck && (+it.qty) > (+it.stock);
      const rq = state.returnable && state.returnable[it.product_id] !== undefined ? state.returnable[it.product_id] : null;
      const over = rq !== null && +it.qty > rq;
      return `<tr data-i="${i}">
        <td>${i + 1}</td>
        <td><b>${BP.esc(it.name)}</b><br><small class="muted">${BP.esc(it.code)}${it.unit ? ' | ' + BP.esc(it.unit) : ''}${rq !== null ? ' | Returnable: ' + rq : ''}</small></td>
        ${isAdj ? '' : `<td class="num ${low ? 'text-danger bold' : ''}">${+it.stock}</td>`}
        ${isAdj ? `<td><select data-k="adj_sign"><option value="1" ${it.adj_sign > 0 ? 'selected' : ''}>+ Add</option><option value="-1" ${it.adj_sign < 0 ? 'selected' : ''}>- Less</option></select><br><small class="muted">Stock: ${+it.stock}</small></td>` : ''}
        <td><input type="number" step="any" min="0" data-k="qty" value="${Math.abs(+it.qty)}" class="${low || over ? 'is-invalid' : ''}" style="width:80px"></td>
        ${isPur ? `<td><input type="number" step="any" min="0" data-k="free_qty" value="${+it.free_qty}" style="width:64px"></td>` : ''}
        <td><input type="number" step="0.01" min="0" data-k="rate" value="${+it.rate}" style="width:95px"></td>
        ${isAdj ? '' : `<td><input type="number" step="0.01" min="0" max="100" data-k="disc_pct" value="${+it.disc_pct}" style="width:64px"></td><td><input type="number" step="0.01" min="0" data-k="gst_pct" value="${+it.gst_pct}" style="width:60px"></td>`}
        <td class="num">${BP.money(isAdj ? lc.amount : lc.total)}</td>
        <td><button type="button" class="icon-btn text-danger" data-del title="Remove">&times;</button></td></tr>`;
    }).join('');
    $('noItems').style.display = state.items.length ? 'none' : 'block';
    if (focusIdx !== undefined) { const q = tbody.querySelector(`tr[data-i="${focusIdx}"] [data-k="qty"]`); if (q) { q.focus(); q.select(); } }
    calc();
  }
  tbody.addEventListener('input', e => {
    const k = e.target.dataset.k; if (!k) return;
    const i = +e.target.closest('tr').dataset.i, it = state.items[i];
    it[k] = k === 'adj_sign' ? +e.target.value : (+e.target.value || 0);
    const lc = lineCalc(it), tr = e.target.closest('tr');
    tr.children[tr.children.length - 2].textContent = BP.money(isAdj ? lc.amount : lc.total);
    calc();
  });
  tbody.addEventListener('change', e => {
    const k = e.target.dataset.k; if (!k) return;
    if (k === 'adj_sign') return render();
    if (k === 'qty') {
      const it = state.items[+e.target.closest('tr').dataset.i];
      const rq = state.returnable && state.returnable[it.product_id] !== undefined ? state.returnable[it.product_id] : null;
      const bad = (C.stockCheck && +it.qty > +it.stock) || (rq !== null && +it.qty > rq);
      e.target.classList.toggle('is-invalid', bad);
      if (bad) BP.toast(rq !== null && +it.qty > rq ? 'Quantity exceeds returnable quantity (' + rq + ')' : 'Quantity exceeds available stock (' + it.stock + ')', 'warning');
    }
  });
  tbody.addEventListener('click', e => { if (e.target.closest('[data-del]')) { state.items.splice(+e.target.closest('tr').dataset.i, 1); render(); scan.focus(); } });
  tbody.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.dataset.k) { e.preventDefault(); scan.focus(); } });

  /* ---------- totals ---------- */
  function calc() {
    let sub = 0, disc = 0, taxable = 0, gst = 0, qty = 0, val = 0;
    state.items.forEach(it => { const lc = lineCalc(it); sub += lc.amount; disc += lc.disc; taxable += lc.taxable; gst += lc.gst; qty += Math.abs(+it.qty); val += (it.adj_sign || 1) * lc.amount; });
    sub = r2(sub); disc = r2(disc); taxable = r2(taxable); gst = r2(gst);
    if (isAdj) { $('tCount').textContent = state.items.length; $('tGrand').textContent = BP.money(val); return; }
    const bd = +$('hBillDisc').value || 0, oc = +$('hOther').value || 0;
    const gross = r2(taxable + gst - bd + oc);
    const ro = C.roundOff ? r2(Math.round(gross) - gross) : 0;
    const grand = r2(gross + ro);
    $('tCount').textContent = state.items.length + ' / ' + r3(qty);
    $('tSub').textContent = BP.money(sub); $('tDisc').textContent = BP.money(disc); $('tTaxable').textContent = BP.money(taxable);
    const cg = r2(gst / 2);
    $('tCgst').textContent = BP.money(cg); $('tSgst').textContent = BP.money(r2(gst - cg)); $('tIgst').textContent = BP.money(gst);
    $('rowCgst').style.display = $('rowSgst').style.display = state.interstate ? 'none' : '';
    $('rowIgst').style.display = state.interstate ? '' : 'none';
    $('tRound').textContent = BP.money(ro); $('tGrand').textContent = BP.money(grand);
    const paidEl = $('hPaid');
    // Auto-follow: if paid was equal to previous grand total (full payment), keep it full
    if (paidEl.dataset.auto === '1') paidEl.value = grand;
    const due = r2(grand - (+paidEl.value || 0));
    $('tDue').textContent = BP.money(due);
    $('tDue').className = due > 0 ? 'text-danger' : (due < 0 ? 'text-danger' : 'text-success');
    state.grand = grand;
  }
  if (!isAdj) {
    ['hBillDisc', 'hOther'].forEach(id => $(id).addEventListener('input', calc));
    $('hPaid').addEventListener('input', e => { e.target.dataset.auto = '0'; calc(); syncMode(); });
    $('btnFull').onclick = () => { $('hPaid').value = state.grand || 0; $('hPaid').dataset.auto = '1'; if ($('hMode').value === 'Credit') $('hMode').value = 'Cash'; calc(); };
    $('btnCredit').onclick = () => { $('hPaid').value = 0; $('hPaid').dataset.auto = '0'; $('hMode').value = 'Credit'; calc(); };
    $('hMode').addEventListener('change', () => { if ($('hMode').value === 'Credit') { $('hPaid').value = 0; $('hPaid').dataset.auto = '0'; } else if (+$('hPaid').value === 0) { $('hPaid').value = state.grand || 0; $('hPaid').dataset.auto = '1'; } $('hAccount').value = ''; calc(); });
  }
  function syncMode() { if (+$('hPaid').value > 0 && $('hMode').value === 'Credit') $('hMode').value = 'Cash'; }

  /* ---------- payload / save ---------- */
  function payload() {
    const p = { dtype: T, id: C.id, row_version: C.row_version, doc_date: $('hDate').value, remarks: $('hRemarks').value, from_hold: state.holdId || 0,
      items: state.items.map(it => ({ product_id: it.product_id, qty: isAdj ? (it.adj_sign || 1) * Math.abs(+it.qty) : +it.qty, free_qty: +it.free_qty || 0, rate: +it.rate, disc_pct: +it.disc_pct || 0, gst_pct: +it.gst_pct || 0 })) };
    if (C.ptype) p.party_id = state.party ? state.party.id : null;
    if (isPur) p.ref_invoice_no = $('hRefInv').value;
    if (isRet) p.against_doc_id = state.against ? state.against.id : null;
    if (!isAdj) { p.bill_discount = +$('hBillDisc').value || 0; p.other_charges = +$('hOther').value || 0; p.paid_amount = +$('hPaid').value || 0; p.payment_mode = $('hMode').value; p.account_id = $('hAccount').value || null; }
    return p;
  }
  function validate(p) {
    if (C.ptype && !p.party_id) { BP.toast('Please select a ' + (C.ptype === 'C' ? 'customer' : 'supplier'), 'warning'); $('partyInput').focus(); return false; }
    if (!p.items.length) { BP.toast('Add at least one product', 'warning'); scan.focus(); return false; }
    if (p.items.some(i => !(Math.abs(i.qty) > 0))) { BP.toast('Quantity must be greater than zero for every item', 'warning'); return false; }
    if (!isAdj && p.paid_amount > state.grand + 0.001) { BP.toast('Paid amount cannot exceed grand total', 'warning'); $('hPaid').focus(); return false; }
    if (isAdj && !p.remarks.trim()) { BP.toast('Enter the reason for adjustment', 'warning'); $('hRemarks').focus(); return false; }
    if (!isAdj && p.paid_amount > 0 && p.payment_mode === 'Credit') p.payment_mode = 'Cash';
    return true;
  }
  async function save(print) {
    if (state.saving) return;
    const p = payload();
    if (!validate(p)) return;
    state.saving = true;
    const btns = document.querySelectorAll('#btnSave,#btnSavePrint'); btns.forEach(b => b.disabled = true);
    try {
      const r = await BP.api('save_doc', p);
      BP.toast(C.label + ' ' + r.doc_no + ' saved' + (r.grand_total !== undefined && !isAdj ? ' - ' + BP.money(r.grand_total) : ''), 'success', 5000);
      if (print || (C.autoPrint && !isAdj && !C.id)) window.open('print.php?id=' + r.id + (print === 'thermal' ? '&fmt=thermal' : ''), '_blank');
      if (C.id) { location.href = 'index.php?p=doc_view&id=' + r.id; return; }
      afterSave(r);
    } catch (e) {
      BP.toast(e.message, 'danger', 7000);
    } finally { state.saving = false; btns.forEach(b => b.disabled = false); }
  }
  function afterSave(r) {
    const foot = `<div class="btn-row"><a class="btn" href="index.php?p=doc_view&id=${r.id}">View</a>${isAdj ? '' : `<a class="btn" target="_blank" href="print.php?id=${r.id}">Print A4</a><a class="btn" target="_blank" href="print.php?id=${r.id}&fmt=thermal">Print Thermal</a><a class="btn" target="_blank" href="print.php?id=${r.id}&pdf=1">PDF</a>`}<button class="btn btn-primary" data-new>New ${BP.esc(C.label)} (Enter)</button></div>`;
    const m = BP.modal({ title: 'Saved successfully', body: `<p style="font-size:16px">${BP.esc(C.label)} <b>${BP.esc(r.doc_no)}</b> saved.${isAdj ? '' : ' Grand total: <b>' + BP.money(r.grand_total) + '</b>'}</p>`, foot, onClose: reset });
    const nb = m.querySelector('[data-new]'); nb.focus(); nb.onclick = () => m._close();
  }
  function reset() {
    if (T === 'SALE' || !C.party) { state.items = []; state.holdId = null; }
    location.href = 'index.php?p=doc_form&t=' + T; // fresh number & state
  }
  $('btnSave').onclick = () => save(false);
  if ($('btnSavePrint')) $('btnSavePrint').onclick = () => save(true);
  BP.onSave = () => save(false);
  BP.onPrint = () => { if (!isAdj) save(true); };
  $('btnClear').onclick = async () => { if (state.items.length && !(await BP.confirm('Clear all items from this bill?'))) return; state.items = []; state.holdId = null; render(); scan.focus(); };

  /* ---------- hold / resume ---------- */
  async function refreshHeld() { if (!$('heldCount')) return; try { const r = await BP.api('hold_list', {}, 'GET'); $('heldCount').textContent = r.items.length; return r.items; } catch (e) { return []; } }
  if ($('btnHold')) {
    $('btnHold').onclick = async () => {
      if (!state.items.length) return BP.toast('Nothing to hold', 'warning');
      const label = await BP.confirm('Hold this bill and start a new one? You can resume it later from any PC.', { title: 'Hold Bill', input: 'Label / note (optional)', ok: 'Hold' });
      if (label === false) return;
      try {
        const p = payload();
        p.party = state.party; p.items_full = state.items; p.against = state.against;
        await BP.api('hold_save', { payload: p, label: (label || '').trim(), grand_total: state.grand });
        if (state.holdId) await BP.api('hold_delete', { id: state.holdId });
        BP.toast('Bill held');
        state.items = []; state.holdId = null; setParty(C.party); render(); refreshHeld(); scan.focus();
      } catch (e) { BP.toast(e.message, 'danger'); }
    };
    $('btnResume').onclick = async () => {
      const items = await refreshHeld();
      if (!items || !items.length) return BP.toast('No held bills', 'info');
      const body = `<table class="table"><thead><tr><th>Label</th><th>User / PC</th><th>Held at</th><th class="num">Total</th><th></th></tr></thead><tbody>${items.map(h => `<tr><td>${BP.esc(h.label)}</td><td>${BP.esc(h.user_name)} / ${BP.esc(h.device_name || '')}</td><td>${BP.esc(h.created_at)}</td><td class="num">${BP.money(h.grand_total)}</td><td class="actions"><button class="btn btn-sm btn-primary" data-res="${h.id}">Resume</button> <button class="btn btn-sm btn-danger" data-hdel="${h.id}">Discard</button></td></tr>`).join('')}</tbody></table>`;
      const m = BP.modal({ title: 'Held Bills', body, wide: true });
      m.addEventListener('click', async e => {
        const rb = e.target.closest('[data-res]'), db = e.target.closest('[data-hdel]');
        try {
          if (rb) {
            if (state.items.length && !(await BP.confirm('Current bill has items. Replace with the held bill?'))) return;
            const r = await BP.api('hold_get', { id: rb.dataset.res }, 'GET');
            const p = r.payload;
            state.holdId = r.id;
            state.items = p.items_full || [];
            if (p.party) setParty(p.party);
            $('hBillDisc').value = p.bill_discount || 0; $('hOther').value = p.other_charges || 0; $('hRemarks').value = p.remarks || '';
            if (p.payment_mode) $('hMode').value = p.payment_mode;
            $('hPaid').dataset.auto = '1';
            m._close(); render(); BP.toast('Bill resumed'); scan.focus();
          } else if (db) {
            if (!(await BP.confirm('Discard this held bill?', { danger: true }))) return;
            await BP.api('hold_delete', { id: db.dataset.hdel }); db.closest('tr').remove(); refreshHeld();
          }
        } catch (err) { BP.toast(err.message, 'danger'); }
      });
    };
    refreshHeld();
  }

  /* ---------- init ---------- */
  if (C.header) {
    const h = C.header;
    if (!isAdj) { $('hBillDisc').value = h.bill_discount; $('hOther').value = h.other_charges; $('hPaid').value = h.paid_amount; $('hPaid').dataset.auto = Math.abs(h.paid_amount - h.grand_total) < 0.005 ? '1' : '0'; if (h.payment_mode) $('hMode').value = h.payment_mode; if (h.account_id) $('hAccount').value = h.account_id; }
  } else if (!isAdj) {
    $('hPaid').dataset.auto = (T === 'SALE') ? '1' : '0';
    if (T !== 'SALE') $('hMode').value = 'Credit';
  }
  state.items = (C.items || []).map(i => Object.assign({ adj_sign: +i.qty < 0 ? -1 : 1 }, i, { qty: Math.abs(+i.qty) }));
  if (C.party) setParty(C.party);
  if (isRet && C.against) loadAgainst(C.against.id, false);
  else if (isRet && C.againstPreset) loadAgainst(C.againstPreset, true);
  render();
  if (C.ptype && !C.party) $('partyInput').focus(); else scan.focus();
})();
