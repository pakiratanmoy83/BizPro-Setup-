<?php
require __DIR__ . '/inc/bootstrap.php';
require __DIR__ . '/inc/layout.php';
require __DIR__ . '/inc/posting.php';
require __DIR__ . '/inc/backup_lib.php';
require __DIR__ . '/inc/dashboard_lib.php';
require __DIR__ . '/inc/reports_lib.php';

if (!validate_session()) redirect('login.php' . (isset($_SESSION) && !empty($_COOKIE['BIZPROSESS']) ? '?timeout=1' : ''));
maybe_auto_backup();

$routes = [
    'dashboard' => [], 'profile' => [], 'help' => [],
    'products' => ['product.view'], 'product' => ['product.view'], 'masters' => ['master.manage'],
    'parties' => ['customer.view', 'supplier.view'], 'party' => ['customer.view', 'supplier.view', 'customer.ledger', 'supplier.ledger'],
    'doc_list' => [], 'doc_form' => [], 'doc_view' => [], 'voucher_form' => [],
    'stock' => ['stock.view', 'report.stock'], 'stock_ledger' => ['stock.view', 'report.stock'],
    'accounts' => ['cash.view'], 'book' => ['cash.view', 'report.financial'],
    'reports' => [], 'report' => [],
    'users' => ['user.manage'], 'user' => ['user.manage'], 'roles' => ['user.manage'],
    'audit' => ['audit.view'], 'backup' => ['backup.manage'], 'settings' => ['settings.manage', 'settings.limited'], 'recycle' => ['recycle.manage'],
];
$page = preg_replace('/[^a-z_]/', '', (string)($_GET['p'] ?? 'dashboard'));
if (!isset($routes[$page])) $page = 'dashboard';
$u = current_user();
if (!empty($u['must_change_pw']) && $page !== 'profile') { flash('warning', 'Please change your password before continuing.'); redirect(url('profile')); }

$title = 'Dashboard';
ob_start();
try {
    if ($routes[$page]) require_perm(...$routes[$page]);
    if (is_post()) csrf_check();
    require __DIR__ . '/modules/' . $page . '.php';
} catch (Throwable $ex) {
    $msg = $ex instanceof AppException ? $ex->getMessage() : 'Error: ' . $ex->getMessage();
    if (!$ex instanceof AppException) error_log($ex->__toString());
    if (is_post() && empty($_POST['_ajax'])) {
        ob_end_clean();
        flash('danger', $msg);
        redirect($_SERVER['HTTP_REFERER'] ?? url('dashboard'));
    }
    ob_clean();
    $title = 'Notice';
    echo '<div class="card"><div class="alert alert-danger">' . e($msg) . '</div><a class="btn" href="javascript:history.back()">Go Back</a></div>';
}
$content = ob_get_clean();
render_layout($title, $content, $page);
