<?php
require __DIR__ . '/inc/bootstrap.php';
$err = '';
if (!empty($_SESSION['user']) && validate_session()) redirect('index.php');
$remembered = $_COOKIE['bp_user'] ?? '';
// The desktop shortcut created by the installer opens login.php?pc=<Windows computer name>
if (!empty($_GET['pc']) && preg_match('/^[A-Za-z0-9._ -]{1,60}$/', (string)$_GET['pc'])) { $pcn = strtoupper((string)$_GET['pc']); setcookie('bp_device', $pcn, time() + 86400 * 365, '/'); $_COOKIE['bp_device'] = $pcn; }
$device = $_COOKIE['bp_device'] ?? detect_device_name();
if (is_post()) {
    try {
        csrf_check();
        $u = trim((string)in('username'));
        $p = (string)in('password');
        $device = mb_substr(trim((string)in('device_name')) ?: detect_device_name(), 0, 90);
        [$ok, $msg] = attempt_login($u, $p, $device);
        if ($ok) {
            $exp = time() + 86400 * 365;
            if (in('remember')) setcookie('bp_user', $u, $exp, '/'); else setcookie('bp_user', '', time() - 3600, '/');
            setcookie('bp_device', $device, $exp, '/');
            redirect('index.php');
        }
        $err = $msg;
        $remembered = $u;
    } catch (Throwable $e) { $err = $e instanceof AppException ? $e->getMessage() : 'Login failed: ' . $e->getMessage(); }
}
$biz = setting('business_name', 'BizPro');
$logo = setting('business_logo', '');
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login - <?= e($biz) ?></title><link rel="stylesheet" href="assets/css/app.css"></head>
<body class="login-body">
<div class="login-card">
  <div class="login-brand">
    <?php if ($logo): ?><img src="<?= e($logo) ?>" class="login-logo" alt=""><?php else: ?><div class="logo-mark">B</div><?php endif; ?>
    <div><h1><?= e($biz) ?></h1><p>Business, Inventory, Purchase &amp; Sales</p></div>
  </div>
  <?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
  <?php if (!empty($_GET['timeout'])): ?><div class="alert alert-warning">Your session ended. Please log in again.</div><?php endif; ?>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?>
    <div class="fg"><label>Username</label><input name="username" value="<?= e($remembered) ?>" required <?= $remembered ? '' : 'autofocus' ?>></div>
    <div class="fg"><label>Password</label><input type="password" name="password" required <?= $remembered ? 'autofocus' : '' ?>></div>
    <div class="fg"><label>Computer / Device Name</label><input name="device_name" value="<?= e($device) ?>" maxlength="90" title="Recorded with every transaction entered from this PC"></div>
    <label class="check"><input type="checkbox" name="remember" value="1" <?= $remembered ? 'checked' : '' ?>> Remember username</label>
    <button class="btn btn-primary btn-block btn-lg">Login</button>
  </form>
  <p class="muted small center" style="margin-top:14px">Forgot password? Ask the Administrator to reset it from Users.</p>
  <p class="muted small center">v<?= APP_VERSION ?> &middot; Server: <?= e(gethostname()) ?></p>
</div>
</body></html>
