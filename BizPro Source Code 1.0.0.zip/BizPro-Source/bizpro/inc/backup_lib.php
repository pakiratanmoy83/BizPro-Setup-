<?php
/** Full database backup / restore implemented in pure PHP (no external tools required). */

function backup_dir(): string {
    $d = rtrim(str_replace('\\', '/', setting('backup_dir', BASE_DIR . '/backups')), '/');
    if (!is_dir($d)) @mkdir($d, 0775, true);
    if (!is_dir($d) || !is_writable($d)) throw new AppException('Backup folder is not writable: ' . $d);
    return $d;
}

function create_backup(string $type = 'MANUAL'): array {
    global $CONFIG;
    @set_time_limit(0);
    $dir = backup_dir();
    $file = sprintf('%s/bizpro_%s_%s.sql.gz', $dir, strtolower($type), date('Ymd_His'));
    $gz = gzopen($file, 'wb6');
    if (!$gz) throw new AppException('Cannot create backup file.');
    $pdo = db();
    gzwrite($gz, "-- BizPro database backup\n-- Database: {$CONFIG['db_name']}\n-- Created: " . now() . "\n-- Version: " . APP_VERSION . "\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS=0;\nSET UNIQUE_CHECKS=0;\n\n");
    $tables = $pdo->query('SHOW FULL TABLES WHERE Table_type = "BASE TABLE"')->fetchAll(PDO::FETCH_NUM);
    $pdo->exec('START TRANSACTION WITH CONSISTENT SNAPSHOT');
    foreach ($tables as [$t]) {
        $create = $pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM)[1];
        gzwrite($gz, "DROP TABLE IF EXISTS `$t`;\n$create;\n\n");
        $st = $pdo->query("SELECT * FROM `$t`", PDO::FETCH_NUM);
        $batch = [];
        while ($r = $st->fetch()) {
            $batch[] = '(' . implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), $r)) . ')';
            if (count($batch) >= 200) { gzwrite($gz, "INSERT INTO `$t` VALUES\n" . implode(",\n", $batch) . ";\n"); $batch = []; }
        }
        if ($batch) gzwrite($gz, "INSERT INTO `$t` VALUES\n" . implode(",\n", $batch) . ";\n");
        gzwrite($gz, "\n");
    }
    $pdo->exec('COMMIT');
    gzwrite($gz, "SET FOREIGN_KEY_CHECKS=1;\nSET UNIQUE_CHECKS=1;\n-- END OF BACKUP\n");
    gzclose($gz);
    $u = current_user();
    $size = filesize($file);
    insert('backups', ['filename' => basename($file), 'filepath' => $file, 'size_bytes' => $size, 'btype' => $type, 'status' => 'OK', 'created_by' => $u['id'] ?? null, 'created_by_name' => $u['username'] ?? 'system', 'created_at' => now()]);
    if ($type === 'AUTO') set_setting('last_auto_backup', now());
    audit('BACKUP', 'backup', null, basename($file), ['type' => $type, 'size' => $size]);
    cleanup_old_backups();
    return ['file' => $file, 'size' => $size];
}

function cleanup_old_backups(): void {
    $keep = (int)setting('backup_keep', '30');
    if ($keep <= 0) return;
    $old = rows("SELECT id, filepath FROM backups WHERE btype='AUTO' ORDER BY id DESC LIMIT 100000 OFFSET $keep");
    foreach ($old as $o) { if (is_file($o['filepath'])) @unlink($o['filepath']); q('DELETE FROM backups WHERE id=?', [$o['id']]); }
}

function restore_backup(string $file): int {
    @set_time_limit(0);
    if (!is_file($file)) throw new AppException('Backup file not found.');
    $head = file_get_contents($file, false, null, 0, 2);
    $isGz = $head === "\x1f\x8b";
    $fh = $isGz ? gzopen($file, 'rb') : fopen($file, 'rb');
    $first = $isGz ? gzgets($fh) : fgets($fh);
    if (strpos((string)$first, 'BizPro database backup') === false) throw new AppException('This file is not a BizPro backup.');
    // safety backup of current data first
    $safety = create_backup('SAFETY');
    $pdo = db();
    $buf = ''; $n = 0; $inStr = false;
    $read = fn() => $isGz ? gzgets($fh, 1 << 20) : fgets($fh, 1 << 20);
    while (($line = $read()) !== false) {
        if ($buf === '' && (str_starts_with($line, '--') || trim($line) === '')) continue;
        $buf .= $line;
        // statement ends with ";\n" outside of string literal
        for ($i = strlen($buf) - strlen($line); $i < strlen($buf); $i++) {
            $c = $buf[$i];
            if ($c === '\\' && $inStr) { $i++; continue; }
            if ($c === "'") $inStr = !$inStr;
        }
        if (!$inStr && preg_match('/;\s*$/', $line)) { $pdo->exec($buf); $buf = ''; $n++; }
    }
    $isGz ? gzclose($fh) : fclose($fh);
    if (trim($buf) !== '') { $pdo->exec($buf); $n++; }
    // record restore in the (restored) backups table
    $u = current_user();
    if (!val('SELECT id FROM backups WHERE filepath=?', [$safety['file']])) insert('backups', ['filename' => basename($safety['file']), 'filepath' => $safety['file'], 'size_bytes' => $safety['size'], 'btype' => 'SAFETY', 'status' => 'OK', 'created_by' => $u['id'] ?? null, 'created_by_name' => $u['username'] ?? 'system', 'created_at' => now()]);
    insert('backups', ['filename' => basename($file), 'filepath' => $file, 'size_bytes' => filesize($file), 'btype' => 'RESTORE', 'status' => 'OK', 'created_by' => $u['id'] ?? null, 'created_by_name' => $u['username'] ?? 'system', 'created_at' => now()]);
    audit('RESTORE_DB', 'backup', null, basename($file), ['statements' => $n, 'safety_backup' => basename($safety['file'])]);
    return $n;
}

/** Called on page loads: runs automatic backup when the interval has passed */
function maybe_auto_backup(): void {
    if (setting('auto_backup', '1') !== '1') return;
    $hours = max(1, (int)setting('auto_backup_hours', '24'));
    $last = setting('last_auto_backup', '');
    if ($last && time() - strtotime($last) < $hours * 3600) return;
    // prevent concurrent runs from several PCs using a named DB lock
    if (!val("SELECT GET_LOCK('bizpro_auto_backup', 0)")) return;
    try {
        settings_all(true);
        $last = setting('last_auto_backup', '');
        if (!$last || time() - strtotime($last) >= $hours * 3600) create_backup('AUTO');
    } catch (Throwable $e) { error_log('Auto backup failed: ' . $e->getMessage()); }
    finally { val("SELECT RELEASE_LOCK('bizpro_auto_backup')"); }
}
