<?php
function menu_items(): array {
    return [
        ['Dashboard', 'dashboard', [], 'M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z'],
        ['section', 'Transactions'],
        ['New Sale (F5)', 'doc_form', ['t' => 'SALE'], 'M7 18c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45C4.52 15.37 5.48 17 7 17h12v-2H7l1.1-2h7.45c.75 0 1.41-.41 1.75-1.03L21 4H5.21l-.94-2H1z', 'sale.add'],
        ['Sales List', 'doc_list', ['t' => 'SALE'], 'M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z', 'sale.view|sale.view_all'],
        ['New Purchase (F6)', 'doc_form', ['t' => 'PURCHASE'], 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z', 'purchase.add'],
        ['Purchase List', 'doc_list', ['t' => 'PURCHASE'], 'M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z', 'purchase.view|purchase.view_all'],
        ['Sales Return', 'doc_list', ['t' => 'SRET'], 'M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z', 'sret.view|sret.add'],
        ['Purchase Return', 'doc_list', ['t' => 'PRET'], 'M11.5 8c2.65 0 5.05.99 6.9 2.6L22 7v9h-9l3.62-3.62c-1.39-1.16-3.16-1.88-5.12-1.88-3.54 0-6.55 2.31-7.6 5.5l-2.37-.78C2.92 11.03 6.85 8 11.5 8z', 'pret.view|pret.add'],
        ['Customer Receipt (F7)', 'doc_list', ['t' => 'RECEIPT'], 'M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z', 'receipt.view|receipt.add'],
        ['Supplier Payment (F8)', 'doc_list', ['t' => 'PAYMENT'], 'M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z', 'payment.view|payment.add'],
        ['Expenses', 'doc_list', ['t' => 'EXPENSE'], 'M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z', 'expense.view|expense.add'],
        ['section', 'Masters'],
        ['Products', 'products', [], 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z', 'product.view'],
        ['Customers', 'parties', ['t' => 'C'], 'M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z', 'customer.view'],
        ['Suppliers', 'parties', ['t' => 'S'], 'M20 8h-3V4H3c-1.1 0-2 .9-2 2v11h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1.5 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z', 'supplier.view'],
        ['Categories & Units', 'masters', [], 'M12 2l-5.5 9h11L12 2zm5.5 11c-2.49 0-4.5 2.01-4.5 4.5s2.01 4.5 4.5 4.5 4.5-2.01 4.5-4.5-2.01-4.5-4.5-4.5zM3 21.5h8v-8H3v8z', 'master.manage'],
        ['section', 'Inventory & Accounts'],
        ['Stock', 'stock', [], 'M20 2H4c-1 0-2 .9-2 2v3.01c0 .72.43 1.34 1 1.69V20c0 1.1 1.1 2 2 2h14c.9 0 2-.9 2-2V8.7c.57-.35 1-.97 1-1.69V4c0-1.1-1-2-2-2zm-5 12H9v-2h6v2zm5-7H4V4h16v3z', 'stock.view'],
        ['Stock Adjustment', 'doc_list', ['t' => 'ADJ'], 'M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z', 'stock.adjust'],
        ['Cash & Bank', 'accounts', [], 'M4 10v7h3v-7H4zm6 0v7h3v-7h-3zM2 22h19v-3H2v3zm14-12v7h3v-7h-3zm-4.5-9L2 6v2h19V6l-9.5-5z', 'cash.view'],
        ['Reports', 'reports', [], 'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z', 'report.sales|report.purchase|report.stock|report.customer|report.supplier|report.financial|report.user'],
        ['section', 'Administration'],
        ['Users & Roles', 'users', [], 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z', 'user.manage'],
        ['Audit Log', 'audit', [], 'M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9zm-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8H12z', 'audit.view'],
        ['Recycle Bin', 'recycle', [], 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z', 'recycle.manage'],
        ['Backup & Restore', 'backup', [], 'M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM14 13v4h-4v-4H7l5-5 5 5h-3z', 'backup.manage'],
        ['Settings', 'settings', [], 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z', 'settings.manage|settings.limited'],
        ['Help (F1)', 'help', [], 'M11 18h2v-2h-2v2zm1-16C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm0-14c-2.21 0-4 1.79-4 4h2c0-1.1.9-2 2-2s2 .9 2 2c0 2-3 1.75-3 5h2c0-2.25 3-2.5 3-5 0-2.21-1.79-4-4-4z'],
    ];
}

function render_sidebar(string $page): string {
    $h = '';
    $pendingSection = null;
    foreach (menu_items() as $m) {
        if ($m[0] === 'section') { $pendingSection = $m[1]; continue; }
        [$label, $p, $params, $icon] = $m;
        $perm = $m[4] ?? '';
        if ($perm && !can_any(explode('|', $perm))) continue;
        if ($p === 'dashboard' && !can('dashboard.view')) continue;
        if ($pendingSection) { $h .= '<div class="nav-section">' . e($pendingSection) . '</div>'; $pendingSection = null; }
        $active = ($p === $page && (empty($params['t']) || ($params['t'] ?? '') === ($_GET['t'] ?? ''))) ? ' active' : '';
        $h .= '<a class="nav-link' . $active . '" href="' . e(url($p, $params)) . '"><svg viewBox="0 0 24 24"><path d="' . $icon . '"/></svg><span>' . e($label) . '</span></a>';
    }
    return $h;
}

function render_layout(string $title, string $content, string $page): void {
    $u = current_user();
    $biz = setting('business_name', 'BizPro');
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    $perms = json_encode(['sale' => can('sale.add'), 'purchase' => can('purchase.add'), 'receipt' => can('receipt.add'), 'payment' => can('payment.add'), 'product' => can('product.view'), 'customer' => can('customer.view'), 'supplier' => can('supplier.view')]);
    ?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> - <?= e($biz) ?></title>
<link rel="stylesheet" href="assets/css/app.css?v=<?= APP_VERSION ?>">
<script>window.BP = {csrf: <?= json_encode(csrf_token()) ?>, perms: <?= $perms ?>, page: <?= json_encode($page) ?>, currency: <?= json_encode(setting('currency_symbol', '₹')) ?>, biz: <?= json_encode($biz) ?>};</script>
<script src="assets/js/app.js?v=<?= APP_VERSION ?>"></script>
</head><body>
<aside class="sidebar" id="sidebar">
  <div class="brand"><div class="logo-mark sm">B</div><div class="brand-text"><strong><?= e($biz) ?></strong><small>BizPro v<?= APP_VERSION ?></small></div></div>
  <nav><?= render_sidebar($page) ?></nav>
</aside>
<div class="main">
  <header class="topbar">
    <button class="icon-btn" onclick="document.body.classList.toggle('nav-collapsed')" title="Toggle menu">&#9776;</button>
    <h2 class="page-title"><?= e($title) ?></h2>
    <div class="topbar-search"><input id="globalProductSearch" placeholder="Search product / barcode (F2)" autocomplete="off"></div>
    <div class="topbar-right">
      <span class="chip" title="This computer"><?= e(device_name()) ?></span>
      <div class="user-menu">
        <button class="user-btn" onclick="this.parentNode.classList.toggle('open')"><span class="avatar"><?= e(strtoupper(substr($u['full_name'], 0, 1))) ?></span><span><?= e($u['full_name']) ?><small><?= e($u['role_name']) ?></small></span></button>
        <div class="user-dropdown">
          <a href="<?= e(url('profile')) ?>">Change Password</a>
          <a href="<?= e(url('help')) ?>">Help &amp; Shortcuts</a>
          <a href="logout.php" class="danger">Logout</a>
        </div>
      </div>
    </div>
  </header>
  <main class="content">
    <?php foreach ($flashes as [$t, $m]): ?><div class="alert alert-<?= e($t) ?> flash"><?= e($m) ?></div><?php endforeach; ?>
    <?= $content ?>
  </main>
</div>
<div id="toastBox"></div>
<div id="modalRoot"></div>
</body></html><?php
}
