<?php
function current_user(): ?array {
    if (PHP_SAPI === 'cli') return $GLOBALS['CLI_USER'] ?? ['id' => null, 'username' => 'system', 'full_name' => 'System', 'role_name' => 'System', 'perms' => all_perm_keys()];
    return $_SESSION['user'] ?? null;
}
function load_user_perms(int $userId, int $roleId): array {
    $role = row('SELECT name FROM roles WHERE id=?', [$roleId]);
    if ($role && $role['name'] === 'Admin') return all_perm_keys();
    $perms = array_column(rows('SELECT perm FROM role_permissions WHERE role_id=?', [$roleId]), 'perm');
    foreach (rows('SELECT perm, allow FROM user_permissions WHERE user_id=?', [$userId]) as $o) {
        if ($o['allow']) $perms[] = $o['perm']; else $perms = array_diff($perms, [$o['perm']]);
    }
    return array_values(array_unique($perms));
}
function can(string $perm): bool {
    $u = current_user();
    return $u && in_array($perm, $u['perms'] ?? [], true);
}
function can_any(array $perms): bool { foreach ($perms as $p) if (can($p)) return true; return false; }
function is_admin(): bool { $u = current_user(); return $u && ($u['role_name'] ?? '') === 'Admin'; }

function require_perm(string ...$perms): void {
    foreach ($perms as $p) if (can($p)) return;
    throw new AppException('Access denied. You do not have permission for this action (' . implode(' / ', $perms) . ').');
}

function attempt_login(string $username, string $password, string $device): array {
    $u = row('SELECT u.*, r.name role_name FROM users u JOIN roles r ON r.id=u.role_id WHERE u.username=? AND u.is_deleted=0', [$username]);
    if (!$u) return [false, 'Invalid username or password.'];
    if (!$u['is_active']) return [false, 'This user account is disabled. Contact the administrator.'];
    if ($u['locked_until'] && strtotime($u['locked_until']) > time()) return [false, 'Account temporarily locked after failed attempts. Try again after ' . date('h:i A', strtotime($u['locked_until'])) . '.'];
    if (!password_verify($password, $u['password_hash'])) {
        $f = $u['failed_logins'] + 1;
        update('users', ['failed_logins' => $f, 'locked_until' => $f >= 5 ? date('Y-m-d H:i:s', time() + 600) : null], 'id=?', [$u['id']]);
        insert('audit_log', ['user_id' => $u['id'], 'username' => $u['username'], 'action' => 'LOGIN_FAIL', 'module' => 'auth', 'details' => 'Wrong password', 'device_name' => $device, 'ip_address' => client_ip(), 'created_at' => now()]);
        return [false, 'Invalid username or password.'];
    }
    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) update('users', ['password_hash' => password_hash($password, PASSWORD_DEFAULT)], 'id=?', [$u['id']]);
    session_regenerate_id(true);
    $token = bin2hex(random_bytes(24));
    $_SESSION['device_name'] = $device;
    $_SESSION['token'] = $token;
    $_SESSION['user'] = [
        'id' => (int)$u['id'], 'username' => $u['username'], 'full_name' => $u['full_name'], 'role_id' => (int)$u['role_id'],
        'role_name' => $u['role_name'], 'perms' => load_user_perms((int)$u['id'], (int)$u['role_id']), 'must_change_pw' => (int)$u['must_change_pw'],
    ];
    update('users', ['failed_logins' => 0, 'locked_until' => null, 'last_login' => now()], 'id=?', [$u['id']]);
    insert('user_sessions', ['user_id' => $u['id'], 'session_token' => $token, 'device_name' => $device, 'ip_address' => client_ip(), 'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250), 'login_at' => now(), 'last_seen' => now()]);
    audit('LOGIN', 'auth', $u['id'], null, 'Logged in from ' . $device);
    return [true, ''];
}

/** Validate that session is still active (admin may force logout, timeout, deactivated user) */
function validate_session(): bool {
    $u = $_SESSION['user'] ?? null;
    if (!$u || empty($_SESSION['token'])) return false;
    $s = row('SELECT s.id, s.is_active, s.last_seen, us.is_active uactive, us.is_deleted, us.role_id FROM user_sessions s JOIN users us ON us.id=s.user_id WHERE s.session_token=?', [$_SESSION['token']]);
    if (!$s || !$s['is_active'] || !$s['uactive'] || $s['is_deleted']) { destroy_session(); return false; }
    $timeout = (int)setting('session_timeout_min', '480');
    if ($timeout > 0 && time() - strtotime($s['last_seen']) > $timeout * 60) {
        q('UPDATE user_sessions SET is_active=0, logout_at=? WHERE id=?', [now(), $s['id']]);
        destroy_session(); return false;
    }
    if (time() - strtotime($s['last_seen']) > 30) {
        q('UPDATE user_sessions SET last_seen=? WHERE id=?', [now(), $s['id']]);
        // refresh permissions so admin changes take effect without re-login
        $_SESSION['user']['perms'] = load_user_perms((int)$u['id'], (int)$s['role_id']);
        $_SESSION['user']['role_id'] = (int)$s['role_id'];
        $_SESSION['user']['role_name'] = val('SELECT name FROM roles WHERE id=?', [$s['role_id']]);
    }
    return true;
}
function destroy_session(): void {
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) session_destroy();
}
function do_logout(): void {
    if (!empty($_SESSION['token'])) {
        q('UPDATE user_sessions SET is_active=0, logout_at=? WHERE session_token=?', [now(), $_SESSION['token']]);
        audit('LOGOUT', 'auth', $_SESSION['user']['id'] ?? null);
    }
    destroy_session();
}
function password_policy(string $pw): ?string {
    if (strlen($pw) < 6) return 'Password must be at least 6 characters.';
    if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/\d/', $pw)) return 'Password must contain letters and numbers.';
    return null;
}
