<?php
function outstanding_total(string $ptype): float {
    $sql = $ptype === 'C'
        ? "SELECT COALESCE(SUM(b),0) FROM (SELECT p.opening_balance + COALESCE(SUM(l.debit - l.credit),0) b FROM parties p LEFT JOIN party_ledger l ON l.party_id=p.id WHERE p.ptype='C' AND p.is_deleted=0 GROUP BY p.id) x WHERE b > 0"
        : "SELECT COALESCE(SUM(b),0) FROM (SELECT p.opening_balance + COALESCE(SUM(l.credit - l.debit),0) b FROM parties p LEFT JOIN party_ledger l ON l.party_id=p.id WHERE p.ptype='S' AND p.is_deleted=0 GROUP BY p.id) x WHERE b > 0";
    return r2(val($sql));
}

function profit_summary(string $from, string $to): array {
    $s = row("SELECT COALESCE(SUM(grand_total - gst_total),0) net, COALESCE(SUM(cost_total),0) cost, COALESCE(SUM(gst_total),0) gst FROM documents WHERE dtype='SALE' AND is_deleted=0 AND doc_date BETWEEN ? AND ?", [$from, $to]);
    $r = row("SELECT COALESCE(SUM(grand_total - gst_total),0) net, COALESCE(SUM(cost_total),0) cost FROM documents WHERE dtype='SRET' AND is_deleted=0 AND doc_date BETWEEN ? AND ?", [$from, $to]);
    $exp = (float)val("SELECT COALESCE(SUM(grand_total),0) FROM documents WHERE dtype='EXPENSE' AND is_deleted=0 AND doc_date BETWEEN ? AND ?", [$from, $to]);
    $netSales = r2($s['net'] - $r['net']);
    $cogs = r2($s['cost'] - $r['cost']);
    $gross = r2($netSales - $cogs);
    return ['sales' => r2($s['net']), 'returns' => r2($r['net']), 'net_sales' => $netSales, 'cogs' => $cogs, 'gross_profit' => $gross, 'expenses' => r2($exp), 'net_profit' => r2($gross - $exp), 'gst_collected' => r2($s['gst'])];
}

function dashboard_data(): array {
    $t = today();
    $sum = fn($type) => r2(val('SELECT COALESCE(SUM(grand_total),0) FROM documents WHERE dtype=? AND is_deleted=0 AND doc_date=?', [$type, $t]));
    $cnt = fn($type) => (int)val('SELECT COUNT(*) FROM documents WHERE dtype=? AND is_deleted=0 AND doc_date=?', [$type, $t]);
    $stock = row('SELECT COUNT(*) n, COALESCE(SUM(current_stock),0) qty, COALESCE(SUM(CASE WHEN current_stock>0 THEN current_stock*purchase_rate ELSE 0 END),0) val,
        SUM(CASE WHEN current_stock<=0 THEN 1 ELSE 0 END) oos, SUM(CASE WHEN current_stock>0 AND current_stock<=min_stock THEN 1 ELSE 0 END) low
        FROM products WHERE is_deleted=0 AND is_active=1');
    $collection = r2(val("SELECT COALESCE(SUM(amount_in),0) FROM account_transactions WHERE txn_date=? AND txn_type IN ('SALE','RECEIPT')", [$t]));
    $payment = r2(val("SELECT COALESCE(SUM(amount_out),0) FROM account_transactions WHERE txn_date=? AND txn_type IN ('PURCHASE','PAYMENT')", [$t]));
    $months = [];
    for ($i = 11; $i >= 0; $i--) $months[date('Y-m', strtotime("first day of -$i month"))] = ['s' => 0, 'p' => 0];
    $from = array_key_first($months) . '-01';
    foreach (rows("SELECT DATE_FORMAT(doc_date,'%Y-%m') m, dtype, SUM(grand_total) t FROM documents WHERE dtype IN ('SALE','PURCHASE') AND is_deleted=0 AND doc_date>=? GROUP BY m, dtype", [$from]) as $r) {
        if (isset($months[$r['m']])) $months[$r['m']][$r['dtype'] === 'SALE' ? 's' : 'p'] = r2($r['t']);
    }
    $own = !can('sale.view_all');
    $u = current_user();
    $recentSales = can('sale.view') || can('sale.view_all') ? rows("SELECT d.id, d.doc_no, d.doc_date, d.grand_total, d.due_amount, d.created_by_name, p.name party FROM documents d LEFT JOIN parties p ON p.id=d.party_id WHERE d.dtype='SALE' AND d.is_deleted=0" . ($own ? ' AND d.created_by=' . (int)$u['id'] : '') . ' ORDER BY d.id DESC LIMIT 8') : [];
    $ownP = !can('purchase.view_all');
    $recentPur = can('purchase.view') || can('purchase.view_all') ? rows("SELECT d.id, d.doc_no, d.ref_invoice_no, d.doc_date, d.grand_total, d.due_amount, d.created_by_name, p.name party FROM documents d LEFT JOIN parties p ON p.id=d.party_id WHERE d.dtype='PURCHASE' AND d.is_deleted=0" . ($ownP ? ' AND d.created_by=' . (int)$u['id'] : '') . ' ORDER BY d.id DESC LIMIT 8') : [];
    $low = rows('SELECT p.id, p.code, p.name, p.current_stock, p.min_stock, u.name unit FROM products p LEFT JOIN units u ON u.id=p.unit_id WHERE p.is_deleted=0 AND p.is_active=1 AND p.current_stock<=p.min_stock ORDER BY (p.current_stock<=0) DESC, p.current_stock - p.min_stock LIMIT 10');
    $data = [
        'updated' => date('h:i:s A'),
        'total_products' => (int)$stock['n'], 'total_stock' => qtyf($stock['qty']), 'stock_value' => r2($stock['val']),
        'out_of_stock' => (int)$stock['oos'], 'low_stock' => (int)$stock['low'],
        'today_sales' => $sum('SALE'), 'today_sales_count' => $cnt('SALE'), 'today_purchase' => $sum('PURCHASE'), 'today_purchase_count' => $cnt('PURCHASE'),
        'today_collection' => $collection, 'today_payment' => $payment, 'today_expense' => $sum('EXPENSE'),
        'total_customers' => (int)val("SELECT COUNT(*) FROM parties WHERE ptype='C' AND is_deleted=0 AND is_system=0"),
        'total_suppliers' => (int)val("SELECT COUNT(*) FROM parties WHERE ptype='S' AND is_deleted=0"),
        'customer_outstanding' => outstanding_total('C'), 'supplier_outstanding' => outstanding_total('S'),
        'months' => array_map(fn($m) => date('M y', strtotime($m . '-01')), array_keys($months)),
        'month_sales' => array_column(array_values($months), 's'), 'month_purchase' => array_column(array_values($months), 'p'),
        'recent_sales' => $recentSales, 'recent_purchases' => $recentPur, 'low_list' => $low,
        'online_users' => rows('SELECT u.full_name, s.device_name, MAX(s.last_seen) last_seen FROM user_sessions s JOIN users u ON u.id=s.user_id WHERE s.is_active=1 AND s.last_seen > ? GROUP BY u.id, u.full_name, s.device_name ORDER BY last_seen DESC LIMIT 15', [date('Y-m-d H:i:s', time() - 900)]),
    ];
    // ---- permission scoping: users only see figures their role allows ----
    $me = (int)current_user()['id'];
    $salesAll = can('sale.view_all') || can('report.sales') || can('dashboard.profit');
    $purAll = can('purchase.view_all') || can('report.purchase') || can('dashboard.profit');
    $salesAny = $salesAll || can('sale.view') || can('sale.add');
    $purAny = $purAll || can('purchase.view') || can('purchase.add');
    $ownSum = fn($type) => [r2(val('SELECT COALESCE(SUM(grand_total),0) FROM documents WHERE dtype=? AND is_deleted=0 AND doc_date=? AND created_by=?', [$type, $t, $me])), (int)val('SELECT COUNT(*) FROM documents WHERE dtype=? AND is_deleted=0 AND doc_date=? AND created_by=?', [$type, $t, $me])];
    $ownMonths = function ($type) use ($months, $from, $me) {
        $m = array_fill_keys(array_keys($months), 0);
        foreach (rows("SELECT DATE_FORMAT(doc_date,'%Y-%m') m, SUM(grand_total) t FROM documents WHERE dtype=? AND is_deleted=0 AND doc_date>=? AND created_by=? GROUP BY m", [$type, $from, $me]) as $r) if (isset($m[$r['m']])) $m[$r['m']] = r2($r['t']);
        return array_values($m);
    };
    $data['scope_sales'] = $salesAll ? 'all' : ($salesAny ? 'own' : 'none');
    $data['scope_purchase'] = $purAll ? 'all' : ($purAny ? 'own' : 'none');
    if (!$salesAll) {
        if ($salesAny) { [$data['today_sales'], $data['today_sales_count']] = $ownSum('SALE'); $data['month_sales'] = $ownMonths('SALE'); }
        else unset($data['today_sales'], $data['today_sales_count'], $data['month_sales']);
    }
    if (!$purAll) {
        if ($purAny) { [$data['today_purchase'], $data['today_purchase_count']] = $ownSum('PURCHASE'); $data['month_purchase'] = $ownMonths('PURCHASE'); }
        else unset($data['today_purchase'], $data['today_purchase_count'], $data['month_purchase']);
    }
    if (!(can('cash.view') || can('report.financial'))) unset($data['today_collection'], $data['today_payment'], $data['today_expense']);
    if (!(can('customer.ledger') || can('report.customer'))) unset($data['customer_outstanding']);
    if (!(can('supplier.ledger') || can('report.supplier'))) unset($data['supplier_outstanding']);
    if (!(can('report.stock') || can('dashboard.profit'))) unset($data['stock_value']);
    if (!can('user.manage') && !can('audit.view')) unset($data['online_users']);
    if (can('dashboard.profit')) {
        $data['profit_today'] = profit_summary($t, $t);
        $data['profit_month'] = profit_summary(date('Y-m-01'), $t);
        [$fs, $fe] = fy_range();
        $data['profit_fy'] = profit_summary($fs, min($fe, $t));
    }
    return $data;
}
