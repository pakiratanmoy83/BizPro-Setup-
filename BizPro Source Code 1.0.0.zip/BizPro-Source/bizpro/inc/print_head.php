<div class="head">
  <div class="biz">
    <h1><?= e($S['business_name'] ?? '') ?></h1>
    <div><?= nl2br(e($S['business_address'] ?? '')) ?><?= !empty($S['business_state']) ? (trim((string)($S['business_address'] ?? '')) !== '' ? ', ' : '') . e($S['business_state']) : '' ?></div>
    <div><?= !empty($S['business_phone']) ? 'Phone: ' . e($S['business_phone']) : '' ?><?= !empty($S['business_email']) ? ' &nbsp; Email: ' . e($S['business_email']) : '' ?></div>
    <?php if (!empty($S['business_gstin'])): ?><div><b>GSTIN: <?= e($S['business_gstin']) ?></b></div><?php endif; ?>
  </div>
  <?php if (!empty($logo)): ?><img src="<?= e($logo) ?>" alt="logo"><?php endif; ?>
</div>
