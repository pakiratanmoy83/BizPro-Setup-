<?php
class AppException extends Exception {}

function e($s): string { return htmlspecialchars((string)($s ?? ''), ENT_QUOTES, 'UTF-8'); }
function now(): string { return date('Y-m-d H:i:s'); }
function today(): string { return date('Y-m-d'); }
function money($n): string { return number_format((float)$n, 2); }
function qtyf($n): string { $n = (float)$n; return (floor($n) == $n) ? number_format($n, 0, '.', '') : rtrim(rtrim(number_format($n, 3, '.', ''), '0'), '.'); }
function r2($n): float { return round((float)$n + 0.0000001, 2); }
function r3($n): float { return round((float)$n, 3); }
function dmy($d): string { return $d ? date('d-m-Y', strtotime($d)) : ''; }
function dmyhm($d): string { return $d ? date('d-m-Y h:i A', strtotime($d)) : ''; }

function in(string $k, $default = '') { return $_POST[$k] ?? $_GET[$k] ?? $default; }
function ini(string $k, int $d = 0): int { return (int)(in($k, $d) ?: $d); }
function inf(string $k): float { return (float)str_replace(',', '', (string)in($k, 0)); }
function ind(string $k, ?string $d = null): string { $v = (string)in($k, ''); return preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : ($d ?? today()); }

function settings_all(bool $reload = false): array {
    static $cache = null;
    if ($cache === null || $reload) {
        $cache = [];
        foreach (rows('SELECT skey, svalue FROM settings') as $r) $cache[$r['skey']] = $r['svalue'];
    }
    return $cache;
}
function setting(string $k, $d = '') { $a = settings_all(); return $a[$k] ?? $d; }
function set_setting(string $k, $v): void {
    q('INSERT INTO settings (skey, svalue) VALUES (?,?) ON DUPLICATE KEY UPDATE svalue=VALUES(svalue)', [$k, (string)$v]);
    settings_all(true);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . csrf_token() . '">'; }
function csrf_check(): void {
    $t = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!hash_equals($_SESSION['csrf'] ?? '', (string)$t)) throw new AppException('Security token expired. Please reload the page and try again.');
}

function flash(string $type, string $msg): void { $_SESSION['flash'][] = [$type, $msg]; }
function redirect(string $url): void { header('Location: ' . $url); exit; }
function json_out($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR);
    exit;
}
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'; }

function client_ip(): string { return $_SERVER['REMOTE_ADDR'] ?? 'cli'; }
function device_name(): string {
    if (!empty($_SESSION['device_name'])) return $_SESSION['device_name'];
    return PHP_SAPI === 'cli' ? (gethostname() ?: 'SERVER') : client_ip();
}
function detect_device_name(): string {
    $ip = client_ip();
    if (in_array($ip, ['127.0.0.1', '::1'])) return strtoupper(gethostname() ?: 'SERVER');
    $h = @gethostbyaddr($ip);
    if ($h && $h !== $ip) return strtoupper(explode('.', $h)[0]);
    return $ip;
}

/** Atomically reserve the next number of a series (row locked within current transaction) */
function next_number(string $key, bool $reserve = true): string {
    $r = row('SELECT * FROM number_series WHERE skey=?' . ($reserve ? ' FOR UPDATE' : ''), [$key]);
    if (!$r) { q('INSERT INTO number_series (skey,prefix,next_no,pad) VALUES (?,?,1,5)', [$key, $key . '-']); $r = ['prefix' => $key . '-', 'next_no' => 1, 'pad' => 5]; }
    $no = $r['prefix'] . str_pad((string)$r['next_no'], (int)$r['pad'], '0', STR_PAD_LEFT);
    if ($reserve) q('UPDATE number_series SET next_no=next_no+1 WHERE skey=?', [$key]);
    return $no;
}

function audit(string $action, string $module, $recordId = null, ?string $refNo = null, $details = null): void {
    $u = current_user();
    insert('audit_log', [
        'user_id' => $u['id'] ?? null, 'username' => $u['username'] ?? 'system',
        'action' => $action, 'module' => $module, 'record_id' => $recordId, 'ref_no' => $refNo,
        'details' => $details === null ? null : (is_string($details) ? $details : json_encode($details, JSON_UNESCAPED_UNICODE)),
        'device_name' => device_name(), 'ip_address' => client_ip(), 'created_at' => now(),
    ]);
}

function stamp_create(): array {
    $u = current_user();
    return ['created_by' => $u['id'] ?? null, 'created_by_name' => $u['username'] ?? 'system', 'created_at' => now(), 'device_name' => device_name()];
}
function stamp_modify(): array {
    $u = current_user();
    return ['modified_by' => $u['id'] ?? null, 'modified_by_name' => $u['username'] ?? 'system', 'modified_at' => now()];
}

function amount_in_words(float $amount): string {
    $amount = round($amount, 2);
    $rupees = (int)floor($amount);
    $paise = (int)round(($amount - $rupees) * 100);
    $w = $rupees === 0 ? 'Zero' : _num_words_in($rupees);
    $s = 'Rupees ' . $w;
    if ($paise > 0) $s .= ' and ' . _num_words_in($paise) . ' Paise';
    return $s . ' Only';
}
function _num_words_in(int $n): string {
    $ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    $tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    $two = function ($n) use ($ones, $tens) { return $n < 20 ? $ones[$n] : trim($tens[intdiv($n, 10)] . ' ' . $ones[$n % 10]); };
    $out = [];
    foreach ([[10000000, 'Crore'], [100000, 'Lakh'], [1000, 'Thousand'], [100, 'Hundred']] as [$d, $l]) {
        if ($n >= $d) { $c = intdiv($n, $d); $out[] = ($d == 10000000 ? _num_words_in($c) : $two($c)) . ' ' . $l; $n %= $d; }
    }
    if ($n > 0) $out[] = $two($n);
    return implode(' ', $out);
}

function fy_range(): array {
    $start = setting('fy_start', date('Y') . '-04-01');
    $end = setting('fy_end', (date('Y') + 1) . '-03-31');
    return [$start, $end];
}

function options(array $list, $selected, string $idKey = 'id', string $labelKey = 'name', string $blank = ''): string {
    $h = $blank !== '' ? '<option value="">' . e($blank) . '</option>' : '';
    foreach ($list as $r) {
        $id = $r[$idKey];
        $h .= '<option value="' . e($id) . '"' . ((string)$id === (string)$selected ? ' selected' : '') . '>' . e($r[$labelKey]) . '</option>';
    }
    return $h;
}
function payment_modes(): array { return ['Cash', 'UPI', 'Card', 'Bank Transfer', 'Cheque', 'Credit']; }

function url(string $page, array $params = []): string {
    return 'index.php?' . http_build_query(array_merge(['p' => $page], $params));
}

function party_balance(int $partyId): float {
    $p = row('SELECT ptype, opening_balance FROM parties WHERE id=?', [$partyId]);
    if (!$p) return 0;
    $s = row('SELECT COALESCE(SUM(debit),0) d, COALESCE(SUM(credit),0) c FROM party_ledger WHERE party_id=?', [$partyId]);
    // Customer: receivable = opening + debit - credit ; Supplier: payable = opening + credit - debit
    return $p['ptype'] === 'C' ? r2($p['opening_balance'] + $s['d'] - $s['c']) : r2($p['opening_balance'] + $s['c'] - $s['d']);
}
function account_balance(int $accId, ?string $upto = null): float {
    $ob = (float)val('SELECT opening_balance FROM accounts WHERE id=?', [$accId]);
    $sql = 'SELECT COALESCE(SUM(amount_in - amount_out),0) FROM account_transactions WHERE account_id=?';
    $p = [$accId];
    if ($upto) { $sql .= ' AND txn_date<=?'; $p[] = $upto; }
    return r2($ob + (float)val($sql, $p));
}
function default_account_for_mode(string $mode): ?int {
    $map = ['Cash' => 'CASH', 'UPI' => 'UPI', 'Card' => 'BANK', 'Bank Transfer' => 'BANK', 'Cheque' => 'BANK'];
    if (!isset($map[$mode])) return null;
    $id = val('SELECT id FROM accounts WHERE atype=? AND is_active=1 AND is_deleted=0 ORDER BY id LIMIT 1', [$map[$mode]]);
    return $id ? (int)$id : null;
}

/** Simple pagination: returns [rows, pagerHtml, total] */
function paginate(string $sql, array $params, int $per = 50): array {
    $page = max(1, (int)($_GET['pg'] ?? 1));
    $total = (int)val("SELECT COUNT(*) FROM ($sql) _c", $params);
    $pages = max(1, (int)ceil($total / $per));
    $page = min($page, $pages);
    $rows = rows($sql . ' LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $params);
    $h = '<div class="pager"><span class="muted small">' . $total . ' records &middot; page ' . $page . ' of ' . $pages . '</span>';
    if ($pages > 1) {
        $qs = $_GET;
        foreach ([[1, '&laquo;'], [max(1, $page - 1), '&lsaquo; Prev'], [min($pages, $page + 1), 'Next &rsaquo;'], [$pages, '&raquo;']] as [$p, $l]) {
            $qs['pg'] = $p;
            $h .= '<a class="btn btn-sm' . ($p == $page ? ' disabled' : '') . '" href="index.php?' . e(http_build_query($qs)) . '">' . $l . '</a>';
        }
    }
    return [$rows, $h . '</div>', $total];
}
function hidden_get_fields(array $keep): string {
    $h = '';
    foreach ($keep as $k) if (isset($_GET[$k])) $h .= '<input type="hidden" name="' . e($k) . '" value="' . e($_GET[$k]) . '">';
    return $h;
}
function status_badge(float $due, float $total): string {
    if ($due <= 0.009) return '<span class="badge green">Paid</span>';
    if ($due + 0.009 >= $total) return '<span class="badge red">Unpaid</span>';
    return '<span class="badge amber">Partial</span>';
}

/** Party statement: [opening balance as on $from, ledger lines within period] */
function party_statement(int $id, string $from, string $to): array {
    $p = row('SELECT ptype, opening_balance FROM parties WHERE id=?', [$id]);
    $pre = row('SELECT COALESCE(SUM(debit),0) d, COALESCE(SUM(credit),0) c FROM party_ledger WHERE party_id=? AND txn_date<?', [$id, $from]);
    $ob = $p['ptype'] === 'C' ? $p['opening_balance'] + $pre['d'] - $pre['c'] : $p['opening_balance'] + $pre['c'] - $pre['d'];
    $lines = rows('SELECT * FROM party_ledger WHERE party_id=? AND txn_date BETWEEN ? AND ? ORDER BY txn_date, id', [$id, $from, $to]);
    return [r2($ob), $lines];
}

/** Unique EAN-13 barcode using the configured prefix */
function gen_barcode(): string {
    do {
        $base = substr(preg_replace('/\D/', '', (string)setting('barcode_prefix', '890')) . str_pad((string)random_int(0, 999999999), 9, '0', STR_PAD_LEFT), 0, 12);
        $base = str_pad($base, 12, '0');
        $sum = 0;
        for ($i = 0; $i < 12; $i++) $sum += (int)$base[$i] * ($i % 2 ? 3 : 1);
        $code = $base . ((10 - $sum % 10) % 10);
    } while (val('SELECT id FROM products WHERE barcode=?', [$code]));
    return $code;
}
