<?php
/** Report registry and builders. Every report returns columns, rows and summable columns. */

function rpt_filters(): array {
    [$fyS] = fy_range();
    return [
        'from' => ind('from', date('Y-m-01')), 'to' => ind('to'),
        'user' => (int)($_GET['user'] ?? 0), 'party' => (int)($_GET['party'] ?? 0),
        'product' => (int)($_GET['product'] ?? 0), 'category' => (int)($_GET['category'] ?? 0),
        'q' => trim((string)($_GET['q'] ?? '')), 'mode' => (string)($_GET['mode'] ?? ''),
        'fy_start' => $fyS,
    ];
}

/** WHERE for document-level reports */
function rpt_doc_where(array $types, array $f, bool $useProduct = true): array {
    $in = implode(',', array_map(fn($t) => db()->quote($t), $types));
    $w = ["d.dtype IN ($in)", 'd.is_deleted=0', 'd.doc_date BETWEEN ? AND ?'];
    $p = [$f['from'], $f['to']];
    if ($f['user']) { $w[] = 'd.created_by=?'; $p[] = $f['user']; }
    if ($f['party']) { $w[] = 'd.party_id=?'; $p[] = $f['party']; }
    if ($f['mode'] !== '') { $w[] = 'd.payment_mode=?'; $p[] = $f['mode']; }
    if ($useProduct && $f['product']) { $w[] = 'EXISTS (SELECT 1 FROM document_items xi WHERE xi.document_id=d.id AND xi.product_id=?)'; $p[] = $f['product']; }
    if ($useProduct && $f['category']) { $w[] = 'EXISTS (SELECT 1 FROM document_items xi JOIN products xp ON xp.id=xi.product_id WHERE xi.document_id=d.id AND xp.category_id=?)'; $p[] = $f['category']; }
    if ($f['q'] !== '') { $w[] = '(d.doc_no LIKE ? OR d.ref_invoice_no LIKE ? OR pa.name LIKE ? OR pa.mobile LIKE ? OR d.remarks LIKE ? OR d.description LIKE ?)'; $l = '%' . $f['q'] . '%'; array_push($p, $l, $l, $l, $l, $l, $l); }
    return [implode(' AND ', $w), $p];
}

/** WHERE for item-level reports (product filters apply to each line) */
function rpt_item_where(array $types, array $f): array {
    $in = implode(',', array_map(fn($t) => db()->quote($t), $types));
    $w = ["d.dtype IN ($in)", 'd.is_deleted=0', 'd.doc_date BETWEEN ? AND ?'];
    $p = [$f['from'], $f['to']];
    if ($f['user']) { $w[] = 'd.created_by=?'; $p[] = $f['user']; }
    if ($f['party']) { $w[] = 'd.party_id=?'; $p[] = $f['party']; }
    if ($f['product']) { $w[] = 'i.product_id=?'; $p[] = $f['product']; }
    if ($f['category']) { $w[] = 'pr.category_id=?'; $p[] = $f['category']; }
    if ($f['q'] !== '') { $w[] = '(i.product_name LIKE ? OR pr.code LIKE ? OR pr.barcode=?)'; array_push($p, '%' . $f['q'] . '%', '%' . $f['q'] . '%', $f['q']); }
    return [implode(' AND ', $w), $p];
}

function rpt_register(array $types, array $f, bool $party = true): array {
    [$w, $p] = rpt_doc_where($types, $f);
    $rows = rows("SELECT d.id, d.doc_date, d.doc_no, d.ref_invoice_no, pa.name party, d.taxable_amount, d.gst_total, d.item_discount+d.bill_discount discount, d.grand_total, d.paid_amount, d.due_amount, d.payment_mode, d.created_by_name, d.device_name
        FROM documents d LEFT JOIN parties pa ON pa.id=d.party_id WHERE $w ORDER BY d.doc_date, d.id", $p);
    $cols = ['doc_date' => ['Date', 'date'], 'doc_no' => ['Doc No', 'doc']];
    if (in_array('PURCHASE', $types)) $cols['ref_invoice_no'] = ['Supplier Bill', 'text'];
    if ($party) $cols['party'] = ['Party', 'text'];
    $cols += ['taxable_amount' => ['Taxable', 'money'], 'discount' => ['Discount', 'money'], 'gst_total' => ['GST', 'money'], 'grand_total' => ['Total', 'money'], 'paid_amount' => ['Paid', 'money'], 'due_amount' => ['Due', 'money'], 'payment_mode' => ['Mode', 'text'], 'created_by_name' => ['User', 'text'], 'device_name' => ['Computer', 'text']];
    return ['cols' => $cols, 'rows' => $rows, 'sum' => ['taxable_amount', 'discount', 'gst_total', 'grand_total', 'paid_amount', 'due_amount']];
}

function rpt_grouped(array $types, array $f, string $groupExpr, string $label, string $labelType = 'text', string $order = 'k'): array {
    [$w, $p] = rpt_doc_where($types, $f);
    $rows = rows("SELECT $groupExpr k, COUNT(*) bills, SUM(d.taxable_amount) taxable, SUM(d.gst_total) gst, SUM(d.item_discount+d.bill_discount) discount, SUM(d.grand_total) total, SUM(d.paid_amount) paid, SUM(d.due_amount) due
        FROM documents d LEFT JOIN parties pa ON pa.id=d.party_id WHERE $w GROUP BY k ORDER BY $order", $p);
    return ['cols' => ['k' => [$label, $labelType], 'bills' => ['Bills', 'int'], 'taxable' => ['Taxable', 'money'], 'discount' => ['Discount', 'money'], 'gst' => ['GST', 'money'], 'total' => ['Total', 'money'], 'paid' => ['Paid', 'money'], 'due' => ['Due', 'money']],
        'rows' => $rows, 'sum' => ['bills', 'taxable', 'discount', 'gst', 'total', 'paid', 'due']];
}

function rpt_product_wise(array $types, array $f, bool $withCost): array {
    [$w, $p] = rpt_item_where($types, $f);
    $rows = rows("SELECT pr.code, i.product_name, c.name category, SUM(i.qty) qty, SUM(i.free_qty) free_qty, SUM(i.taxable) taxable, SUM(i.gst_amt) gst, SUM(i.total) total, SUM(i.qty*i.cost_rate) cost, COUNT(DISTINCT d.id) bills
        FROM document_items i JOIN documents d ON d.id=i.document_id LEFT JOIN products pr ON pr.id=i.product_id LEFT JOIN categories c ON c.id=pr.category_id WHERE $w GROUP BY i.product_id, pr.code, i.product_name, c.name ORDER BY total DESC", $p);
    $cols = ['code' => ['Code', 'text'], 'product_name' => ['Product', 'text'], 'category' => ['Category', 'text'], 'bills' => ['Bills', 'int'], 'qty' => ['Qty', 'qty']];
    if (in_array('PURCHASE', $types)) $cols['free_qty'] = ['Free', 'qty'];
    $cols += ['taxable' => ['Taxable', 'money'], 'gst' => ['GST', 'money'], 'total' => ['Total', 'money']];
    $sum = ['bills', 'qty', 'free_qty', 'taxable', 'gst', 'total'];
    if ($withCost) {
        foreach ($rows as &$r) { $r['profit'] = r2($r['taxable'] - $r['cost']); $r['margin'] = $r['taxable'] > 0 ? round($r['profit'] * 100 / $r['taxable'], 2) : 0; }
        unset($r);
        $cols += ['cost' => ['Cost', 'money'], 'profit' => ['Gross Profit', 'money'], 'margin' => ['Margin %', 'pct']];
        $sum = array_merge($sum, ['cost', 'profit']);
    }
    return ['cols' => $cols, 'rows' => $rows, 'sum' => $sum];
}

function rpt_gst_summary(array $types, array $f): array {
    [$w, $p] = rpt_item_where($types, $f);
    $rows = rows("SELECT i.gst_pct, COUNT(DISTINCT d.id) bills, SUM(i.taxable) taxable, SUM(CASE WHEN d.is_interstate=0 THEN i.gst_amt/2 ELSE 0 END) cgst, SUM(CASE WHEN d.is_interstate=0 THEN i.gst_amt/2 ELSE 0 END) sgst, SUM(CASE WHEN d.is_interstate=1 THEN i.gst_amt ELSE 0 END) igst, SUM(i.gst_amt) gst, SUM(i.total) total
        FROM document_items i JOIN documents d ON d.id=i.document_id LEFT JOIN products pr ON pr.id=i.product_id WHERE $w GROUP BY i.gst_pct ORDER BY i.gst_pct", $p);
    foreach ($rows as &$r) $r['gst_pct'] = (float)$r['gst_pct'] . '%';
    return ['cols' => ['gst_pct' => ['GST Rate', 'text'], 'bills' => ['Bills', 'int'], 'taxable' => ['Taxable', 'money'], 'cgst' => ['CGST', 'money'], 'sgst' => ['SGST', 'money'], 'igst' => ['IGST', 'money'], 'gst' => ['Total GST', 'money'], 'total' => ['Invoice Value', 'money']], 'rows' => $rows, 'sum' => ['taxable', 'cgst', 'sgst', 'igst', 'gst', 'total']];
}

function rpt_stock(array $f, string $kind): array {
    $w = ['p.is_deleted=0']; $pp = [];
    if ($f['product']) { $w[] = 'p.id=?'; $pp[] = $f['product']; }
    if ($f['category']) { $w[] = 'p.category_id=?'; $pp[] = $f['category']; }
    if ($f['q'] !== '') { $w[] = '(p.name LIKE ? OR p.code LIKE ? OR p.barcode=?)'; array_push($pp, '%' . $f['q'] . '%', '%' . $f['q'] . '%', $f['q']); }
    if ($kind === 'low') $w[] = 'p.current_stock>0 AND p.current_stock<=p.min_stock';
    if ($kind === 'out') $w[] = 'p.current_stock<=0';
    $rows = rows('SELECT p.code, p.name, c.name category, b.name brand, u.name unit, p.min_stock, p.max_stock, p.current_stock, p.purchase_rate, p.sale_rate, p.mrp, GREATEST(p.current_stock,0)*p.purchase_rate value_cost, GREATEST(p.current_stock,0)*p.sale_rate value_sale,
        (SELECT MAX(txn_date) FROM stock_transactions s WHERE s.product_id=p.id AND s.qty_out>0) last_sold
        FROM products p LEFT JOIN categories c ON c.id=p.category_id LEFT JOIN brands b ON b.id=p.brand_id LEFT JOIN units u ON u.id=p.unit_id WHERE ' . implode(' AND ', $w) . ' ORDER BY p.name', $pp);
    if ($kind === 'valuation') {
        $g = [];
        foreach ($rows as $r) { $k = $r['category'] ?: '(No category)'; $g[$k] ??= ['category' => $k, 'items' => 0, 'qty' => 0, 'value_cost' => 0, 'value_sale' => 0]; $g[$k]['items']++; $g[$k]['qty'] += max(0, $r['current_stock']); $g[$k]['value_cost'] += $r['value_cost']; $g[$k]['value_sale'] += $r['value_sale']; }
        ksort($g);
        foreach ($g as &$x) $x['margin'] = r2($x['value_sale'] - $x['value_cost']);
        return ['cols' => ['category' => ['Category', 'text'], 'items' => ['Products', 'int'], 'qty' => ['Stock Qty', 'qty'], 'value_cost' => ['Value at Cost', 'money'], 'value_sale' => ['Value at Sale Rate', 'money'], 'margin' => ['Potential Margin', 'money']], 'rows' => array_values($g), 'sum' => ['items', 'qty', 'value_cost', 'value_sale', 'margin'],
            'detail' => ['cols' => ['code' => ['Code', 'text'], 'name' => ['Product', 'text'], 'category' => ['Category', 'text'], 'current_stock' => ['Stock', 'qty'], 'purchase_rate' => ['Cost', 'money'], 'value_cost' => ['Value (Cost)', 'money'], 'sale_rate' => ['Sale Rate', 'money'], 'value_sale' => ['Value (Sale)', 'money']], 'rows' => $rows, 'sum' => ['current_stock', 'value_cost', 'value_sale']]];
    }
    if ($kind === 'low' || $kind === 'out') {
        foreach ($rows as &$r) $r['reorder'] = max(0, ($r['max_stock'] > 0 ? $r['max_stock'] : $r['min_stock'] * 2) - $r['current_stock']);
        unset($r);
        return ['cols' => ['code' => ['Code', 'text'], 'name' => ['Product', 'text'], 'category' => ['Category', 'text'], 'brand' => ['Brand', 'text'], 'unit' => ['Unit', 'text'], 'min_stock' => ['Min', 'qty'], 'max_stock' => ['Max', 'qty'], 'current_stock' => ['Stock', 'qty'], 'reorder' => ['Suggested Order', 'qty'], 'purchase_rate' => ['Cost Rate', 'money'], 'last_sold' => ['Last Sold', 'date']], 'rows' => $rows, 'sum' => ['reorder']];
    }
    return ['cols' => ['code' => ['Code', 'text'], 'name' => ['Product', 'text'], 'category' => ['Category', 'text'], 'brand' => ['Brand', 'text'], 'unit' => ['Unit', 'text'], 'current_stock' => ['Stock', 'qty'], 'purchase_rate' => ['Cost', 'money'], 'sale_rate' => ['Sale Rate', 'money'], 'mrp' => ['MRP', 'money'], 'value_cost' => ['Value (Cost)', 'money'], 'value_sale' => ['Value (Sale)', 'money']], 'rows' => $rows, 'sum' => ['current_stock', 'value_cost', 'value_sale']];
}

function rpt_stock_movement(array $f): array {
    $w = ['p.is_deleted=0']; $pp = [$f['from'], $f['from'], $f['to'], $f['from'], $f['to'], $f['from'], $f['to'], $f['from'], $f['to'], $f['from'], $f['to'], $f['to']];
    if ($f['product']) { $w[] = 'p.id=?'; $pp[] = $f['product']; }
    if ($f['category']) { $w[] = 'p.category_id=?'; $pp[] = $f['category']; }
    if ($f['q'] !== '') { $w[] = '(p.name LIKE ? OR p.code LIKE ?)'; array_push($pp, '%' . $f['q'] . '%', '%' . $f['q'] . '%'); }
    $rows = rows("SELECT p.id, p.code, p.name,
        COALESCE(SUM(CASE WHEN s.txn_date < ? THEN s.qty_in - s.qty_out END),0) opening,
        COALESCE(SUM(CASE WHEN s.txn_date BETWEEN ? AND ? AND s.txn_type='PURCHASE' THEN s.qty_in END),0) purchase,
        COALESCE(SUM(CASE WHEN s.txn_date BETWEEN ? AND ? AND s.txn_type='SRET' THEN s.qty_in END),0) sret,
        COALESCE(SUM(CASE WHEN s.txn_date BETWEEN ? AND ? AND s.txn_type='SALE' THEN s.qty_out END),0) sale,
        COALESCE(SUM(CASE WHEN s.txn_date BETWEEN ? AND ? AND s.txn_type='PRET' THEN s.qty_out END),0) pret,
        COALESCE(SUM(CASE WHEN s.txn_date BETWEEN ? AND ? AND s.txn_type IN ('ADJ','OPENING') THEN s.qty_in - s.qty_out END),0) adj,
        COALESCE(SUM(CASE WHEN s.txn_date <= ? THEN s.qty_in - s.qty_out END),0) closing, p.purchase_rate
        FROM products p LEFT JOIN stock_transactions s ON s.product_id=p.id WHERE " . implode(' AND ', $w) . ' GROUP BY p.id, p.code, p.name, p.purchase_rate ORDER BY p.name', $pp);
    foreach ($rows as &$r) $r['closing_value'] = r2(max(0, $r['closing']) * $r['purchase_rate']);
    unset($r);
    if (empty($_GET['all'])) $rows = array_values(array_filter($rows, fn($r) => $r['opening'] != 0 || $r['closing'] != 0 || $r['purchase'] + $r['sale'] + $r['sret'] + $r['pret'] + abs($r['adj']) > 0));
    return ['cols' => ['code' => ['Code', 'text'], 'name' => ['Product', 'text'], 'opening' => ['Opening', 'qty'], 'purchase' => ['Purchase', 'qty'], 'sret' => ['Sales Ret.', 'qty'], 'sale' => ['Sales', 'qty'], 'pret' => ['Pur. Ret.', 'qty'], 'adj' => ['Adj./Opening', 'qty'], 'closing' => ['Closing', 'qty'], 'closing_value' => ['Closing Value', 'money']],
        'rows' => $rows, 'sum' => ['opening', 'purchase', 'sret', 'sale', 'pret', 'adj', 'closing', 'closing_value'], 'rowlink' => fn($r) => url('stock_ledger', ['product' => $r['id'], 'from' => $f['from'], 'to' => $f['to']])];
}

function rpt_outstanding(string $pt, array $f): array {
    $sign = $pt === 'C' ? 'l.debit - l.credit' : 'l.credit - l.debit';
    $w = ['p.ptype=?', 'p.is_deleted=0']; $pp = [$f['to'], $pt];
    if ($f['party']) { $w[] = 'p.id=?'; $pp[] = $f['party']; }
    if ($f['q'] !== '') { $w[] = '(p.name LIKE ? OR p.mobile LIKE ? OR p.code LIKE ?)'; array_push($pp, '%' . $f['q'] . '%', '%' . $f['q'] . '%', '%' . $f['q'] . '%'); }
    $rows = rows("SELECT p.id, p.code, p.name, p.mobile, p.credit_limit, p.opening_balance + COALESCE(SUM($sign),0) balance,
        (SELECT MAX(txn_date) FROM party_ledger x WHERE x.party_id=p.id AND x.txn_type IN ('RECEIPT','PAYMENT')) last_payment,
        (SELECT MIN(doc_date) FROM documents dd WHERE dd.party_id=p.id AND dd.is_deleted=0 AND dd.due_amount>0 AND dd.dtype IN ('SALE','PURCHASE')) oldest_due
        FROM parties p LEFT JOIN party_ledger l ON l.party_id=p.id AND l.txn_date<=? WHERE " . implode(' AND ', $w) . ' GROUP BY p.id, p.code, p.name, p.mobile, p.credit_limit, p.opening_balance HAVING ABS(balance) > 0.009 ORDER BY balance DESC', $pp);
    foreach ($rows as &$r) { $r['days'] = $r['oldest_due'] && $r['balance'] > 0 ? (int)((strtotime(today()) - strtotime($r['oldest_due'])) / 86400) : ''; $r['over_limit'] = $r['credit_limit'] > 0 && $r['balance'] > $r['credit_limit'] ? 'Yes' : ''; }
    unset($r);
    return ['cols' => ['code' => ['Code', 'text'], 'name' => ['Name', 'text'], 'mobile' => ['Mobile', 'text'], 'balance' => [$pt === 'C' ? 'Receivable (+) / Advance (-)' : 'Payable (+) / Advance (-)', 'money'], 'credit_limit' => ['Credit Limit', 'money'], 'over_limit' => ['Over Limit', 'text'], 'oldest_due' => ['Oldest Due Bill', 'date'], 'days' => ['Days', 'int'], 'last_payment' => ['Last Payment', 'date']],
        'rows' => $rows, 'sum' => ['balance'], 'rowlink' => fn($r) => url('party', ['id' => $r['id']])];
}

function rpt_ledger(array $f): array {
    if (!$f['party']) return ['cols' => [], 'rows' => [], 'sum' => [], 'note' => 'Select a party to view the ledger.'];
    [$ob, $lines] = party_statement($f['party'], $f['from'], $f['to']);
    $pt = val('SELECT ptype FROM parties WHERE id=?', [$f['party']]);
    $bal = $ob;
    $rows = [['txn_date' => $f['from'], 'doc_no' => '', 'txn_type' => '', 'narration' => 'Opening Balance', 'debit' => 0, 'credit' => 0, 'balance' => $ob, 'user_name' => '', 'document_id' => null]];
    foreach ($lines as $l) { $bal += $pt === 'C' ? $l['debit'] - $l['credit'] : $l['credit'] - $l['debit']; $l['balance'] = r2($bal); $rows[] = $l; }
    return ['cols' => ['txn_date' => ['Date', 'date'], 'doc_no' => ['Doc No', 'doclink'], 'txn_type' => ['Type', 'text'], 'narration' => ['Particulars', 'text'], 'debit' => ['Debit', 'money'], 'credit' => ['Credit', 'money'], 'balance' => ['Balance', 'money'], 'user_name' => ['User', 'text']],
        'rows' => $rows, 'sum' => ['debit', 'credit'], 'note' => 'Closing balance: ' . money($bal) . ($bal >= 0 ? ($pt === 'C' ? ' receivable' : ' payable') : ' advance'),
        'extra_btn' => '<a class="btn" target="_blank" href="print.php?type=statement&id=' . $f['party'] . '&from=' . $f['from'] . '&to=' . $f['to'] . '">Print Statement</a>'];
}

function rpt_money_flow(array $f, string $dir): array {
    $col = $dir === 'in' ? 'amount_in' : 'amount_out';
    $w = ["t.$col > 0", 't.txn_date BETWEEN ? AND ?']; $pp = [$f['from'], $f['to']];
    if ($f['user']) { $w[] = 't.user_id=?'; $pp[] = $f['user']; }
    if ($f['party']) { $w[] = 't.party_id=?'; $pp[] = $f['party']; }
    if ($f['q'] !== '') { $w[] = '(t.doc_no LIKE ? OR t.narration LIKE ? OR p.name LIKE ?)'; array_push($pp, '%' . $f['q'] . '%', '%' . $f['q'] . '%', '%' . $f['q'] . '%'); }
    $rows = rows("SELECT t.txn_date, t.doc_no, t.document_id, t.txn_type, a.name account, a.atype, p.name party, t.narration, t.$col amount, t.user_name FROM account_transactions t JOIN accounts a ON a.id=t.account_id LEFT JOIN parties p ON p.id=t.party_id WHERE " . implode(' AND ', $w) . ' ORDER BY t.txn_date, t.id', $pp);
    $by = [];
    foreach ($rows as $r) $by[$r['account']] = ($by[$r['account']] ?? 0) + $r['amount'];
    $note = implode(' | ', array_map(fn($k, $v) => $k . ': ' . money($v), array_keys($by), $by));
    return ['cols' => ['txn_date' => ['Date', 'date'], 'doc_no' => ['Doc No', 'doclink'], 'txn_type' => ['Type', 'text'], 'party' => ['Party', 'text'], 'account' => ['Account', 'text'], 'atype' => ['Mode', 'text'], 'narration' => ['Particulars', 'text'], 'amount' => ['Amount', 'money'], 'user_name' => ['User', 'text']], 'rows' => $rows, 'sum' => ['amount'], 'note' => $note];
}

function rpt_pnl(array $f): array {
    $ps = profit_summary($f['from'], $f['to']);
    $pur = row("SELECT COALESCE(SUM(taxable_amount),0) t FROM documents WHERE dtype='PURCHASE' AND is_deleted=0 AND doc_date BETWEEN ? AND ?", [$f['from'], $f['to']]);
    $pret = row("SELECT COALESCE(SUM(taxable_amount),0) t FROM documents WHERE dtype='PRET' AND is_deleted=0 AND doc_date BETWEEN ? AND ?", [$f['from'], $f['to']]);
    $exp = rows("SELECT ec.name, SUM(d.grand_total) t FROM documents d LEFT JOIN expense_categories ec ON ec.id=d.expense_category_id WHERE d.dtype='EXPENSE' AND d.is_deleted=0 AND d.doc_date BETWEEN ? AND ? GROUP BY ec.name ORDER BY t DESC", [$f['from'], $f['to']]);
    $cash = row("SELECT COALESCE(SUM(CASE WHEN entry_type='IN' THEN grand_total END),0) i, COALESCE(SUM(CASE WHEN entry_type='OUT' THEN grand_total END),0) o FROM documents WHERE dtype='CASH' AND is_deleted=0 AND doc_date BETWEEN ? AND ?", [$f['from'], $f['to']]);
    $stock = r2(val('SELECT COALESCE(SUM(GREATEST(current_stock,0)*purchase_rate),0) FROM products WHERE is_deleted=0'));
    $R = fn($l, $a, $b = 'text') => ['particular' => $l, 'amount' => $a, 'kind' => $b];
    $rows = [
        $R('Sales (net of GST)', $ps['sales']), $R('Less: Sales Returns', -$ps['returns']), $R('Net Sales', $ps['net_sales'], 'bold'),
        $R('Less: Cost of Goods Sold (at purchase cost)', -$ps['cogs']), $R('GROSS PROFIT', $ps['gross_profit'], 'bold'),
    ];
    foreach ($exp as $e) $rows[] = $R('Less: Expense - ' . ($e['name'] ?: 'Other'), -r2($e['t']));
    $rows[] = $R('Total Expenses', -$ps['expenses'], 'bold');
    $rows[] = $R('NET PROFIT / (LOSS)', $ps['net_profit'], 'bold');
    $rows[] = $R('', null);
    $rows[] = $R('Memo: Purchases (taxable) in period', r2($pur['t']));
    $rows[] = $R('Memo: Purchase Returns (taxable)', r2($pret['t']));
    $rows[] = $R('Memo: GST collected on sales', $ps['gst_collected']);
    $rows[] = $R('Memo: Other cash in / out entries (not in P&L)', r2($cash['i'] - $cash['o']));
    $rows[] = $R('Memo: Current closing stock value (at cost)', $stock);
    return ['cols' => ['particular' => ['Particulars', 'text'], 'amount' => ['Amount', 'money']], 'rows' => $rows, 'sum' => [], 'boldkey' => 'kind', 'note' => 'Cost of goods sold uses the purchase rate captured on each invoice line at the time of sale.'];
}

function rpt_user_summary(array $f): array {
    $w = ['d.is_deleted=0', 'd.doc_date BETWEEN ? AND ?']; $pp = [$f['from'], $f['to']];
    if ($f['user']) { $w[] = 'd.created_by=?'; $pp[] = $f['user']; }
    $rows = rows("SELECT d.created_by_name username,
        SUM(d.dtype='SALE') sale_n, SUM(CASE WHEN d.dtype='SALE' THEN d.grand_total ELSE 0 END) sale_amt,
        SUM(CASE WHEN d.dtype='SRET' THEN d.grand_total ELSE 0 END) sret_amt,
        SUM(d.dtype='PURCHASE') pur_n, SUM(CASE WHEN d.dtype='PURCHASE' THEN d.grand_total ELSE 0 END) pur_amt,
        SUM(CASE WHEN d.dtype='RECEIPT' THEN d.grand_total ELSE 0 END) rec_amt, SUM(CASE WHEN d.dtype='PAYMENT' THEN d.grand_total ELSE 0 END) pay_amt,
        SUM(CASE WHEN d.dtype='EXPENSE' THEN d.grand_total ELSE 0 END) exp_amt, COUNT(*) docs
        FROM documents d WHERE " . implode(' AND ', $w) . ' GROUP BY d.created_by, d.created_by_name ORDER BY sale_amt DESC', $pp);
    return ['cols' => ['username' => ['User', 'text'], 'sale_n' => ['Sales Bills', 'int'], 'sale_amt' => ['Sales', 'money'], 'sret_amt' => ['Sales Returns', 'money'], 'pur_n' => ['Purchase Bills', 'int'], 'pur_amt' => ['Purchases', 'money'], 'rec_amt' => ['Receipts', 'money'], 'pay_amt' => ['Payments', 'money'], 'exp_amt' => ['Expenses', 'money'], 'docs' => ['Total Entries', 'int']],
        'rows' => $rows, 'sum' => ['sale_n', 'sale_amt', 'sret_amt', 'pur_n', 'pur_amt', 'rec_amt', 'pay_amt', 'exp_amt', 'docs']];
}

function rpt_user_activity(array $f): array {
    $w = ['DATE(a.created_at) BETWEEN ? AND ?']; $pp = [$f['from'], $f['to']];
    if ($f['user']) { $w[] = 'a.user_id=?'; $pp[] = $f['user']; }
    if ($f['q'] !== '') { $w[] = '(a.action LIKE ? OR a.module LIKE ? OR a.ref_no LIKE ?)'; array_push($pp, '%' . $f['q'] . '%', '%' . $f['q'] . '%', '%' . $f['q'] . '%'); }
    $rows = rows('SELECT a.username, SUM(a.action=\'LOGIN\') logins, SUM(a.action=\'LOGIN_FAIL\') failed, SUM(a.action=\'CREATE\') creates, SUM(a.action=\'EDIT\') edits, SUM(a.action=\'DELETE\') deletes, SUM(a.action=\'PRINT\') prints, COUNT(*) total, MIN(a.created_at) first_at, MAX(a.created_at) last_at, COUNT(DISTINCT a.device_name) devices
        FROM audit_log a WHERE ' . implode(' AND ', $w) . ' GROUP BY a.username ORDER BY total DESC', $pp);
    return ['cols' => ['username' => ['User', 'text'], 'logins' => ['Logins', 'int'], 'failed' => ['Failed Logins', 'int'], 'creates' => ['Created', 'int'], 'edits' => ['Edited', 'int'], 'deletes' => ['Deleted', 'int'], 'prints' => ['Prints', 'int'], 'total' => ['Total Actions', 'int'], 'devices' => ['Computers', 'int'], 'first_at' => ['First Activity', 'datetime'], 'last_at' => ['Last Activity', 'datetime']],
        'rows' => $rows, 'sum' => ['logins', 'failed', 'creates', 'edits', 'deletes', 'prints', 'total'], 'extra_btn' => can('audit.view') ? '<a class="btn" href="' . e(url('audit', ['from' => $f['from'], 'to' => $f['to'], 'user' => $f['user'] ?: ''])) . '">Detailed Audit Log</a>' : ''];
}

function rpt_expense(array $f, string $by): array {
    [$w, $p] = rpt_doc_where(['EXPENSE'], $f, false);
    if (!empty($_GET['ecat'])) { $w .= ' AND d.expense_category_id=?'; $p[] = (int)$_GET['ecat']; }
    if ($by === 'register') {
        $rows = rows("SELECT d.id, d.doc_date, d.doc_no, ec.name category, d.description, d.payment_mode, a.name account, d.grand_total, d.created_by_name FROM documents d LEFT JOIN parties pa ON pa.id=d.party_id LEFT JOIN expense_categories ec ON ec.id=d.expense_category_id LEFT JOIN accounts a ON a.id=d.account_id WHERE $w ORDER BY d.doc_date, d.id", $p);
        return ['cols' => ['doc_date' => ['Date', 'date'], 'doc_no' => ['Voucher', 'doc'], 'category' => ['Category', 'text'], 'description' => ['Description', 'text'], 'payment_mode' => ['Mode', 'text'], 'account' => ['Account', 'text'], 'grand_total' => ['Amount', 'money'], 'created_by_name' => ['User', 'text']], 'rows' => $rows, 'sum' => ['grand_total']];
    }
    $g = ['category' => "COALESCE(ec.name,'Other')", 'daily' => 'd.doc_date', 'monthly' => "DATE_FORMAT(d.doc_date,'%Y-%m')"][$by];
    $rows = rows("SELECT $g k, COUNT(*) n, SUM(d.grand_total) amount FROM documents d LEFT JOIN parties pa ON pa.id=d.party_id LEFT JOIN expense_categories ec ON ec.id=d.expense_category_id WHERE $w GROUP BY k ORDER BY " . ($by === 'category' ? 'amount DESC' : 'k'), $p);
    return ['cols' => ['k' => [$by === 'category' ? 'Category' : ($by === 'daily' ? 'Date' : 'Month'), $by === 'daily' ? 'date' : ($by === 'monthly' ? 'month' : 'text')], 'n' => ['Entries', 'int'], 'amount' => ['Amount', 'money']], 'rows' => $rows, 'sum' => ['n', 'amount']];
}

function report_registry(): array {
    $D = ['date', 'user', 'party', 'product', 'category', 'q', 'mode'];
    $cost = can('dashboard.profit') || can('report.financial');
    return [
        // Sales
        'sales_register' => ['Sales', 'Sales Register (Invoice-wise)', 'report.sales', 'C', $D, fn($f) => rpt_register(['SALE'], $f)],
        'sales_daily' => ['Sales', 'Daily Sales Summary', 'report.sales', 'C', $D, fn($f) => rpt_grouped(['SALE'], $f, 'd.doc_date', 'Date', 'date')],
        'sales_monthly' => ['Sales', 'Monthly Sales Summary', 'report.sales', 'C', $D, fn($f) => rpt_grouped(['SALE'], $f, "DATE_FORMAT(d.doc_date,'%Y-%m')", 'Month', 'month')],
        'sales_user' => ['Sales', 'User-wise Sales', 'report.sales', 'C', $D, fn($f) => rpt_grouped(['SALE'], $f, 'd.created_by_name', 'User', 'text', 'total DESC')],
        'sales_customer' => ['Sales', 'Customer-wise Sales', 'report.sales', 'C', $D, fn($f) => rpt_grouped(['SALE'], $f, "COALESCE(pa.name,'-')", 'Customer', 'text', 'total DESC')],
        'sales_product' => ['Sales', 'Product-wise Sales' . ($cost ? ' & Profit' : ''), 'report.sales', 'C', ['date', 'user', 'party', 'product', 'category', 'q'], fn($f) => rpt_product_wise(['SALE'], $f, $cost)],
        'sales_return' => ['Sales', 'Sales Return Register', 'report.sales', 'C', $D, fn($f) => rpt_register(['SRET'], $f)],
        'sales_gst' => ['Sales', 'GST Summary (Sales)', 'report.sales', 'C', ['date', 'user', 'party', 'product', 'category'], fn($f) => rpt_gst_summary(['SALE'], $f)],
        // Purchase
        'purchase_register' => ['Purchase', 'Purchase Register (Invoice-wise)', 'report.purchase', 'S', $D, fn($f) => rpt_register(['PURCHASE'], $f)],
        'purchase_daily' => ['Purchase', 'Daily Purchase Summary', 'report.purchase', 'S', $D, fn($f) => rpt_grouped(['PURCHASE'], $f, 'd.doc_date', 'Date', 'date')],
        'purchase_monthly' => ['Purchase', 'Monthly Purchase Summary', 'report.purchase', 'S', $D, fn($f) => rpt_grouped(['PURCHASE'], $f, "DATE_FORMAT(d.doc_date,'%Y-%m')", 'Month', 'month')],
        'purchase_user' => ['Purchase', 'User-wise Purchase', 'report.purchase', 'S', $D, fn($f) => rpt_grouped(['PURCHASE'], $f, 'd.created_by_name', 'User', 'text', 'total DESC')],
        'purchase_supplier' => ['Purchase', 'Supplier-wise Purchase', 'report.purchase', 'S', $D, fn($f) => rpt_grouped(['PURCHASE'], $f, "COALESCE(pa.name,'-')", 'Supplier', 'text', 'total DESC')],
        'purchase_product' => ['Purchase', 'Product-wise Purchase', 'report.purchase', 'S', ['date', 'user', 'party', 'product', 'category', 'q'], fn($f) => rpt_product_wise(['PURCHASE'], $f, false)],
        'purchase_return' => ['Purchase', 'Purchase Return Register', 'report.purchase', 'S', $D, fn($f) => rpt_register(['PRET'], $f)],
        'purchase_gst' => ['Purchase', 'GST Summary (Purchase / Input)', 'report.purchase', 'S', ['date', 'user', 'party', 'product', 'category'], fn($f) => rpt_gst_summary(['PURCHASE'], $f)],
        // Stock
        'stock_current' => ['Stock', 'Current Stock', 'report.stock', null, ['product', 'category', 'q'], fn($f) => rpt_stock($f, 'current')],
        'stock_valuation' => ['Stock', 'Stock Valuation (Category-wise)', 'report.stock', null, ['product', 'category', 'q'], fn($f) => rpt_stock($f, 'valuation')],
        'stock_low' => ['Stock', 'Low Stock Report', 'report.stock', null, ['product', 'category', 'q'], fn($f) => rpt_stock($f, 'low')],
        'stock_out' => ['Stock', 'Out of Stock Report', 'report.stock', null, ['product', 'category', 'q'], fn($f) => rpt_stock($f, 'out')],
        'stock_movement' => ['Stock', 'Stock Movement Summary (Opening / In / Out / Closing)', 'report.stock', null, ['date', 'product', 'category', 'q'], fn($f) => rpt_stock_movement($f)],
        'stock_ledger' => ['Stock', 'Product Stock Ledger', 'report.stock', null, [], null, url('stock_ledger')],
        // Customer
        'customer_ledger' => ['Customer', 'Customer Ledger / Statement', 'report.customer', 'C', ['date', 'party'], fn($f) => rpt_ledger($f)],
        'customer_outstanding' => ['Customer', 'Customer Outstanding', 'report.customer', 'C', ['to', 'party', 'q'], fn($f) => rpt_outstanding('C', $f)],
        'customer_sales' => ['Customer', 'Customer-wise Sales', 'report.customer', 'C', $D, fn($f) => rpt_grouped(['SALE'], $f, "COALESCE(pa.name,'-')", 'Customer', 'text', 'total DESC')],
        'customer_payments' => ['Customer', 'Customer Payment History (Receipts)', 'report.customer', 'C', $D, fn($f) => rpt_register(['RECEIPT'], $f)],
        // Supplier
        'supplier_ledger' => ['Supplier', 'Supplier Ledger / Statement', 'report.supplier', 'S', ['date', 'party'], fn($f) => rpt_ledger($f)],
        'supplier_outstanding' => ['Supplier', 'Supplier Outstanding', 'report.supplier', 'S', ['to', 'party', 'q'], fn($f) => rpt_outstanding('S', $f)],
        'supplier_purchase' => ['Supplier', 'Supplier-wise Purchase', 'report.supplier', 'S', $D, fn($f) => rpt_grouped(['PURCHASE'], $f, "COALESCE(pa.name,'-')", 'Supplier', 'text', 'total DESC')],
        'supplier_payments' => ['Supplier', 'Supplier Payment History', 'report.supplier', 'S', $D, fn($f) => rpt_register(['PAYMENT'], $f)],
        // Financial
        'pnl' => ['Financial', 'Profit & Loss Statement', 'report.financial', null, ['date'], fn($f) => rpt_pnl($f)],
        'expense_register' => ['Financial', 'Expense Register', 'report.financial', null, ['date', 'user', 'q', 'ecat', 'mode'], fn($f) => rpt_expense($f, 'register')],
        'expense_category' => ['Financial', 'Category-wise Expenses', 'report.financial', null, ['date', 'user', 'ecat'], fn($f) => rpt_expense($f, 'category')],
        'expense_daily' => ['Financial', 'Daily Expenses', 'report.financial', null, ['date', 'user', 'ecat'], fn($f) => rpt_expense($f, 'daily')],
        'expense_monthly' => ['Financial', 'Monthly Expenses', 'report.financial', null, ['date', 'user', 'ecat'], fn($f) => rpt_expense($f, 'monthly')],
        'collection' => ['Financial', 'Collection Report (All Money In)', 'report.financial', null, ['date', 'user', 'q'], fn($f) => rpt_money_flow($f, 'in')],
        'payments_out' => ['Financial', 'Payment Report (All Money Out)', 'report.financial', null, ['date', 'user', 'q'], fn($f) => rpt_money_flow($f, 'out')],
        'cash_book' => ['Financial', 'Cash Book', 'report.financial', null, [], null, url('book', ['kind' => 'CASH'])],
        'bank_book' => ['Financial', 'Bank Book', 'report.financial', null, [], null, url('book', ['kind' => 'BANK'])],
        // User
        'user_summary' => ['User', 'User-wise Sales / Purchase / Collection', 'report.user', null, ['date', 'user'], fn($f) => rpt_user_summary($f)],
        'user_activity' => ['User', 'User Activity Summary', 'report.user', null, ['date', 'user', 'q'], fn($f) => rpt_user_activity($f)],
        'audit_log' => ['User', 'Audit Log (detailed)', 'audit.view', null, [], null, url('audit')],
    ];
}
