<?php
// Master list of permissions grouped by module
function perm_catalog(): array {
    return [
        'Dashboard' => ['dashboard.view' => 'View dashboard', 'dashboard.profit' => 'See profit summary'],
        'Products' => ['product.view' => 'View products & stock', 'product.add' => 'Add product', 'product.edit' => 'Edit product', 'product.delete' => 'Delete product', 'master.manage' => 'Manage categories / brands / units'],
        'Customers' => ['customer.view' => 'View customers', 'customer.add' => 'Add customer', 'customer.edit' => 'Edit customer', 'customer.delete' => 'Delete customer', 'customer.ledger' => 'Customer ledger / statement'],
        'Suppliers' => ['supplier.view' => 'View suppliers', 'supplier.add' => 'Add supplier', 'supplier.edit' => 'Edit supplier', 'supplier.delete' => 'Delete supplier', 'supplier.ledger' => 'Supplier ledger / statement'],
        'Sales' => ['sale.add' => 'Create sale / billing', 'sale.view' => 'View own sales', 'sale.view_all' => 'View all users\' sales', 'sale.edit' => 'Edit sale', 'sale.delete' => 'Delete sale', 'sale.credit_override' => 'Override credit limit'],
        'Purchases' => ['purchase.add' => 'Create purchase', 'purchase.view' => 'View own purchases', 'purchase.view_all' => 'View all users\' purchases', 'purchase.edit' => 'Edit purchase', 'purchase.delete' => 'Delete purchase'],
        'Returns' => ['sret.add' => 'Create sales return', 'sret.view' => 'View sales returns', 'sret.delete' => 'Delete sales return', 'pret.add' => 'Create purchase return', 'pret.view' => 'View purchase returns', 'pret.delete' => 'Delete purchase return'],
        'Receipts & Payments' => ['receipt.add' => 'Customer receipt entry', 'receipt.view' => 'View receipts', 'receipt.edit' => 'Edit receipt', 'receipt.delete' => 'Delete receipt', 'payment.add' => 'Supplier payment entry', 'payment.view' => 'View supplier payments', 'payment.edit' => 'Edit payment', 'payment.delete' => 'Delete payment'],
        'Expenses' => ['expense.add' => 'Add expense', 'expense.view' => 'View expenses', 'expense.edit' => 'Edit expense', 'expense.delete' => 'Delete expense'],
        'Stock' => ['stock.view' => 'View stock / stock ledger', 'stock.adjust' => 'Stock adjustment'],
        'Cash & Bank' => ['cash.view' => 'View cash / bank books', 'cash.entry' => 'Cash in / out / transfer entry', 'account.manage' => 'Manage cash/bank accounts'],
        'Reports' => ['report.sales' => 'Sales reports', 'report.purchase' => 'Purchase reports', 'report.stock' => 'Stock reports', 'report.customer' => 'Customer reports', 'report.supplier' => 'Supplier reports', 'report.financial' => 'Financial reports (P&L, books)', 'report.user' => 'User reports'],
        'Administration' => ['user.manage' => 'Manage users, roles & permissions', 'audit.view' => 'View audit / activity log', 'backup.manage' => 'Backup & restore', 'settings.manage' => 'All system settings', 'settings.limited' => 'Limited settings (invoice / printer)', 'recycle.manage' => 'Restore / purge deleted records'],
    ];
}

function all_perm_keys(): array {
    $k = [];
    foreach (perm_catalog() as $g) foreach ($g as $p => $l) $k[] = $p;
    return $k;
}

function default_role_perms(): array {
    $all = all_perm_keys();
    $manager = array_values(array_diff($all, ['user.manage', 'backup.manage', 'settings.manage', 'recycle.manage', 'sale.delete', 'purchase.delete', 'receipt.delete', 'payment.delete', 'expense.delete', 'product.delete', 'customer.delete', 'supplier.delete', 'sret.delete', 'pret.delete', 'audit.view']));
    return [
        'Admin' => ['desc' => 'Full access to the entire software', 'perms' => $all],
        'Manager' => ['desc' => 'Products, purchase, sales, parties, payments, reports, limited settings', 'perms' => $manager],
        'Sales User' => ['desc' => 'Billing, customers, receipts, view stock and own sales', 'perms' => ['dashboard.view', 'product.view', 'stock.view', 'customer.view', 'customer.add', 'sale.add', 'sale.view', 'receipt.add', 'receipt.view', 'sret.add', 'sret.view']],
        'Purchase User' => ['desc' => 'Purchase entry, suppliers, supplier payment, view stock and own purchases', 'perms' => ['dashboard.view', 'product.view', 'stock.view', 'supplier.view', 'supplier.add', 'purchase.add', 'purchase.view', 'payment.add', 'payment.view', 'pret.add', 'pret.view']],
        'Viewer / Accounts' => ['desc' => 'View reports and ledgers only - no editing', 'perms' => ['dashboard.view', 'product.view', 'stock.view', 'customer.view', 'customer.ledger', 'supplier.view', 'supplier.ledger', 'sale.view_all', 'sale.view', 'purchase.view', 'purchase.view_all', 'sret.view', 'pret.view', 'receipt.view', 'payment.view', 'expense.view', 'cash.view', 'report.sales', 'report.purchase', 'report.stock', 'report.customer', 'report.supplier', 'report.financial']],
    ];
}
