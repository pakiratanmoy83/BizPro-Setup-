<?php
declare(strict_types=1);
define('APP_NAME', 'BizPro');
define('APP_VERSION', '1.0.0');
define('BASE_DIR', dirname(__DIR__));
date_default_timezone_set('Asia/Kolkata');
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

$cfgFile = BASE_DIR . '/config/config.php';
if (!is_file($cfgFile)) {
    if (PHP_SAPI !== 'cli') { header('Location: install/index.php'); exit; }
    fwrite(STDERR, "Not installed\n"); exit(1);
}
$CONFIG = require $cfgFile;
if (!empty($CONFIG['timezone'])) date_default_timezone_set($CONFIG['timezone']);

require_once __DIR__ . '/permissions.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/auth.php';

if (PHP_SAPI !== 'cli') {
    session_name('BIZPROSESS');
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'path' => '/']);
    session_start();
}
