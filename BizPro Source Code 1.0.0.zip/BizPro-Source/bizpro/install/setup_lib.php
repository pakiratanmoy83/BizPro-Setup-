<?php
/** Shared installer logic for web setup and command-line setup (used by Windows installer) */
require_once dirname(__DIR__) . '/inc/permissions.php';

function bp_run_install(array $o): array {
    $log = [];
    $dsn = sprintf('mysql:host=%s;port=%d;charset=utf8mb4', $o['db_host'], (int)$o['db_port']);
    $pdo = new PDO($dsn, $o['db_user'], $o['db_pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    if (!preg_match('/^[A-Za-z0-9_]+$/', $o['db_name'])) throw new Exception('Invalid database name');
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `{$o['db_name']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `{$o['db_name']}`");
    $log[] = 'Database ready: ' . $o['db_name'];
    $sql = file_get_contents(__DIR__ . '/schema.sql');
    foreach (array_filter(array_map('trim', explode(";\n", $sql))) as $stmt) {
        $clean = trim(preg_replace('/^--.*$/m', '', $stmt));
        if ($clean !== '') $pdo->exec($clean);
    }
    $log[] = 'Tables created';

    $exists = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($exists === 0) {
        $now = date('Y-m-d H:i:s');
        $roleIds = [];
        foreach (default_role_perms() as $name => $r) {
            $pdo->prepare('INSERT INTO roles (name, description, is_system) VALUES (?,?,1)')->execute([$name, $r['desc']]);
            $rid = (int)$pdo->lastInsertId();
            $roleIds[$name] = $rid;
            $st = $pdo->prepare('INSERT INTO role_permissions (role_id, perm) VALUES (?,?)');
            foreach ($r['perms'] as $p) $st->execute([$rid, $p]);
        }
        $pdo->prepare('INSERT INTO users (username, password_hash, full_name, email, role_id, is_active, created_at) VALUES (?,?,?,?,?,1,?)')
            ->execute([$o['admin_user'], password_hash($o['admin_pass'], PASSWORD_DEFAULT), 'Administrator', $o['email'] ?? '', $roleIds['Admin'], $now]);
        $y = (int)date('Y'); $m = (int)date('n');
        $fyS = ($m >= 4 ? $y : $y - 1) . '-04-01'; $fyE = ($m >= 4 ? $y + 1 : $y) . '-03-31';
        $settings = [
            'business_name' => $o['business_name'] ?? 'My Business', 'business_address' => '', 'business_state' => 'West Bengal', 'business_phone' => '', 'business_email' => '',
            'business_gstin' => '', 'business_logo' => '', 'fy_start' => $fyS, 'fy_end' => $fyE, 'currency_symbol' => '₹',
            'invoice_format' => 'A4', 'thermal_width' => '80', 'invoice_terms' => "1. Goods once sold will not be taken back.\n2. Subject to local jurisdiction.\n3. E. & O.E.",
            'invoice_footer' => 'Thank you for your business!', 'round_off' => '1', 'allow_negative_stock' => '0', 'block_negative_cash' => '1', 'update_purchase_rate' => '1',
            'backup_dir' => str_replace('\\', '/', dirname(__DIR__) . '/backups'), 'auto_backup' => '1', 'auto_backup_hours' => '24', 'backup_keep' => '30', 'last_auto_backup' => '',
            'session_timeout_min' => '480', 'lock_date' => '', 'default_gst' => '18', 'tax_label' => 'GST', 'printer_name' => '', 'auto_print' => '0', 'product_code_prefix' => 'P', 'barcode_prefix' => '890',
            'mysqldump_path' => '', 'mysql_path' => '', 'dashboard_refresh_sec' => '60',
        ];
        $st = $pdo->prepare('INSERT IGNORE INTO settings (skey, svalue) VALUES (?,?)');
        foreach ($settings as $k => $v) $st->execute([$k, $v]);
        $series = ['SALE' => 'INV-', 'PUR' => 'PUR-', 'SRET' => 'SR-', 'PRET' => 'PR-', 'RCPT' => 'RC-', 'PAY' => 'PY-', 'EXP' => 'EX-', 'ADJ' => 'ADJ-', 'CB' => 'CB-', 'CUST' => 'C', 'SUPP' => 'S', 'PROD' => 'P'];
        $st = $pdo->prepare('INSERT IGNORE INTO number_series (skey, prefix, next_no, pad) VALUES (?,?,1,?)');
        foreach ($series as $k => $p) $st->execute([$k, $p, in_array($k, ['CUST', 'SUPP', 'PROD']) ? 4 : 5]);
        $st = $pdo->prepare('INSERT INTO accounts (name, atype, opening_balance) VALUES (?,?,0)');
        foreach ([['Cash in Hand', 'CASH'], ['Bank Account', 'BANK'], ['UPI Collection', 'UPI'], ['Card / Other', 'OTHER']] as $a) $st->execute($a);
        $pdo->prepare("INSERT INTO parties (ptype, code, name, state, is_system, created_by_name, created_at) VALUES ('C','C0000','Walk-in Customer',?,1,'system',?)")->execute(['West Bengal', $now]);
        foreach (['Pcs', 'Nos', 'Kg', 'Gm', 'Ltr', 'Ml', 'Box', 'Pkt', 'Dozen', 'Mtr', 'Set', 'Pair'] as $u) $pdo->prepare('INSERT IGNORE INTO units (name) VALUES (?)')->execute([$u]);
        foreach (['General', 'Grocery', 'Electronics', 'Stationery', 'Hardware', 'Cosmetics'] as $c) $pdo->prepare('INSERT IGNORE INTO categories (name) VALUES (?)')->execute([$c]);
        $pdo->prepare('INSERT IGNORE INTO brands (name) VALUES (?)')->execute(['Generic']);
        foreach (['Rent', 'Electricity', 'Salary', 'Transport', 'Telephone / Internet', 'Office Supplies', 'Repairs & Maintenance', 'Tea / Refreshment', 'Miscellaneous'] as $c) $pdo->prepare('INSERT IGNORE INTO expense_categories (name) VALUES (?)')->execute([$c]);
        $log[] = 'Default roles, admin user, accounts and masters created';
    } else {
        $log[] = 'Existing data found - kept as is';
    }

    $cfg = "<?php\nreturn " . var_export([
        'db_host' => $o['db_host'], 'db_port' => (int)$o['db_port'], 'db_name' => $o['db_name'], 'db_user' => $o['db_user'], 'db_pass' => $o['db_pass'],
        'timezone' => 'Asia/Kolkata', 'installed_at' => date('Y-m-d H:i:s'),
    ], true) . ";\n";
    if (file_put_contents(dirname(__DIR__) . '/config/config.php', $cfg) === false) throw new Exception('Cannot write config/config.php - check folder permissions');
    $log[] = 'Configuration saved';
    return $log;
}
