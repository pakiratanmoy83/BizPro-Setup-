<?php
require __DIR__ . '/setup_lib.php';
$installed = is_file(dirname(__DIR__) . '/config/config.php');
$err = ''; $log = [];
if (!$installed && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $o = [
        'db_host' => trim($_POST['db_host'] ?? '127.0.0.1'), 'db_port' => (int)($_POST['db_port'] ?? 3306), 'db_name' => trim($_POST['db_name'] ?? 'bizpro'),
        'db_user' => trim($_POST['db_user'] ?? 'root'), 'db_pass' => (string)($_POST['db_pass'] ?? ''),
        'business_name' => trim($_POST['business_name'] ?? ''), 'admin_user' => trim($_POST['admin_user'] ?? 'admin'), 'admin_pass' => (string)($_POST['admin_pass'] ?? ''),
    ];
    if (strlen($o['admin_pass']) < 6) $err = 'Admin password must be at least 6 characters.';
    elseif ($o['business_name'] === '') $err = 'Enter business name.';
    else {
        try { $log = bp_run_install($o); $installed = true; } catch (Throwable $e) { $err = $e->getMessage(); }
    }
}
?><!doctype html><html><head><meta charset="utf-8"><title>BizPro Setup</title>
<link rel="stylesheet" href="../assets/css/app.css"></head>
<body class="login-body"><div class="login-card" style="width:520px">
<div class="login-brand"><div class="logo-mark">B</div><div><h1>BizPro Setup</h1><p>Server database configuration</p></div></div>
<?php if ($installed): ?>
  <div class="alert alert-success">Installation complete.</div>
  <ul><?php foreach ($log as $l) echo '<li>' . htmlspecialchars($l) . '</li>'; ?></ul>
  <p>Setup is locked. To reinstall, delete <code>config/config.php</code> on the server.</p>
  <a class="btn btn-primary btn-block" href="../login.php">Go to Login</a>
<?php else: ?>
  <?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>
  <form method="post" class="form-grid cols-2">
    <div class="fg span-2"><label>Business Name</label><input name="business_name" required value="<?= htmlspecialchars($_POST['business_name'] ?? '') ?>"></div>
    <div class="fg"><label>MySQL Host</label><input name="db_host" value="<?= htmlspecialchars($_POST['db_host'] ?? '127.0.0.1') ?>"></div>
    <div class="fg"><label>Port</label><input name="db_port" value="<?= htmlspecialchars($_POST['db_port'] ?? '3306') ?>"></div>
    <div class="fg"><label>Database Name</label><input name="db_name" value="<?= htmlspecialchars($_POST['db_name'] ?? 'bizpro') ?>"></div>
    <div class="fg"><label>MySQL User</label><input name="db_user" value="<?= htmlspecialchars($_POST['db_user'] ?? 'root') ?>"></div>
    <div class="fg span-2"><label>MySQL Password</label><input type="password" name="db_pass"></div>
    <div class="fg"><label>Admin Username</label><input name="admin_user" value="admin"></div>
    <div class="fg"><label>Admin Password</label><input type="password" name="admin_pass" required minlength="6"></div>
    <div class="span-2"><button class="btn btn-primary btn-block">Install</button></div>
  </form>
<?php endif; ?>
</div></body></html>
