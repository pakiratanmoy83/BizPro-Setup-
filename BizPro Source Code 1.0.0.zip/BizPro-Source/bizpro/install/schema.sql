-- BizPro Business, Inventory, Purchase & Sales Management
-- MySQL / MariaDB schema (InnoDB, utf8mb4)
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS settings (
  skey VARCHAR(64) PRIMARY KEY,
  svalue TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  is_system TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id INT NOT NULL,
  perm VARCHAR(64) NOT NULL,
  PRIMARY KEY (role_id, perm)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NULL,
  mobile VARCHAR(20) NULL,
  role_id INT NOT NULL,
  is_active TINYINT NOT NULL DEFAULT 1,
  must_change_pw TINYINT NOT NULL DEFAULT 0,
  failed_logins INT NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  last_login DATETIME NULL,
  created_by INT NULL, created_at DATETIME NULL,
  modified_by INT NULL, modified_at DATETIME NULL,
  is_deleted TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- per-user overrides: allow=1 grant, allow=0 revoke (on top of role)
CREATE TABLE IF NOT EXISTS user_permissions (
  user_id INT NOT NULL,
  perm VARCHAR(64) NOT NULL,
  allow TINYINT NOT NULL,
  PRIMARY KEY (user_id, perm)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS user_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  session_token VARCHAR(64) NOT NULL,
  device_name VARCHAR(100) NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  login_at DATETIME NOT NULL,
  last_seen DATETIME NOT NULL,
  logout_at DATETIME NULL,
  is_active TINYINT NOT NULL DEFAULT 1,
  INDEX (session_token), INDEX (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  username VARCHAR(50) NULL,
  action VARCHAR(30) NOT NULL,
  module VARCHAR(40) NOT NULL,
  record_id BIGINT NULL,
  ref_no VARCHAR(50) NULL,
  details MEDIUMTEXT NULL,
  device_name VARCHAR(100) NULL,
  ip_address VARCHAR(45) NULL,
  created_at DATETIME NOT NULL,
  INDEX (module, record_id), INDEX (user_id), INDEX (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS number_series (
  skey VARCHAR(30) PRIMARY KEY,
  prefix VARCHAR(20) NOT NULL,
  next_no INT NOT NULL DEFAULT 1,
  pad INT NOT NULL DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS categories (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, is_deleted TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS brands (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, is_deleted TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS units (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(30) NOT NULL UNIQUE, is_deleted TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS expense_categories (
  id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL UNIQUE, is_deleted TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  barcode VARCHAR(60) NULL UNIQUE,
  name VARCHAR(200) NOT NULL,
  category_id INT NULL, brand_id INT NULL, unit_id INT NULL,
  hsn_code VARCHAR(20) NULL,
  gst_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
  purchase_rate DECIMAL(14,2) NOT NULL DEFAULT 0,
  sale_rate DECIMAL(14,2) NOT NULL DEFAULT 0,
  mrp DECIMAL(14,2) NOT NULL DEFAULT 0,
  opening_stock DECIMAL(14,3) NOT NULL DEFAULT 0,
  current_stock DECIMAL(14,3) NOT NULL DEFAULT 0,
  min_stock DECIMAL(14,3) NOT NULL DEFAULT 0,
  max_stock DECIMAL(14,3) NOT NULL DEFAULT 0,
  description TEXT NULL,
  is_active TINYINT NOT NULL DEFAULT 1,
  row_version INT NOT NULL DEFAULT 1,
  created_by INT NULL, created_by_name VARCHAR(50) NULL, created_at DATETIME NULL, device_name VARCHAR(100) NULL,
  modified_by INT NULL, modified_by_name VARCHAR(50) NULL, modified_at DATETIME NULL,
  is_deleted TINYINT NOT NULL DEFAULT 0, deleted_by INT NULL, deleted_at DATETIME NULL,
  INDEX (name), INDEX (category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS parties (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ptype CHAR(1) NOT NULL,               -- C = customer, S = supplier
  code VARCHAR(20) NOT NULL,
  name VARCHAR(150) NOT NULL,
  company_name VARCHAR(150) NULL,
  address TEXT NULL,
  state VARCHAR(50) NULL,
  mobile VARCHAR(20) NULL,
  email VARCHAR(100) NULL,
  gstin VARCHAR(20) NULL,
  opening_balance DECIMAL(14,2) NOT NULL DEFAULT 0,
  credit_limit DECIMAL(14,2) NOT NULL DEFAULT 0,
  remarks TEXT NULL,
  is_active TINYINT NOT NULL DEFAULT 1,
  is_system TINYINT NOT NULL DEFAULT 0,
  row_version INT NOT NULL DEFAULT 1,
  created_by INT NULL, created_by_name VARCHAR(50) NULL, created_at DATETIME NULL, device_name VARCHAR(100) NULL,
  modified_by INT NULL, modified_by_name VARCHAR(50) NULL, modified_at DATETIME NULL,
  is_deleted TINYINT NOT NULL DEFAULT 0, deleted_by INT NULL, deleted_at DATETIME NULL,
  UNIQUE KEY (ptype, code), INDEX (ptype, name), INDEX (mobile)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  atype VARCHAR(10) NOT NULL,           -- CASH, BANK, UPI, OTHER
  account_no VARCHAR(50) NULL,
  opening_balance DECIMAL(14,2) NOT NULL DEFAULT 0,
  is_active TINYINT NOT NULL DEFAULT 1,
  is_deleted TINYINT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Universal transaction document header
-- dtype: SALE, PURCHASE, SRET, PRET, RECEIPT, PAYMENT, EXPENSE, ADJ, CASH
CREATE TABLE IF NOT EXISTS documents (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  dtype VARCHAR(10) NOT NULL,
  doc_no VARCHAR(40) NOT NULL,
  ref_invoice_no VARCHAR(50) NULL,      -- supplier bill no / original invoice no
  doc_date DATE NOT NULL,
  party_id INT NULL,
  against_doc_id BIGINT NULL,           -- return against invoice
  account_id INT NULL,                  -- cash/bank used for paid amount
  to_account_id INT NULL,               -- for transfers
  expense_category_id INT NULL,
  entry_type VARCHAR(10) NULL,          -- ADJ: ADD/LESS ; CASH: IN/OUT/TRANSFER
  payment_mode VARCHAR(20) NULL,
  reference_no VARCHAR(60) NULL,
  subtotal DECIMAL(14,2) NOT NULL DEFAULT 0,
  item_discount DECIMAL(14,2) NOT NULL DEFAULT 0,
  taxable_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  cgst DECIMAL(14,2) NOT NULL DEFAULT 0,
  sgst DECIMAL(14,2) NOT NULL DEFAULT 0,
  igst DECIMAL(14,2) NOT NULL DEFAULT 0,
  gst_total DECIMAL(14,2) NOT NULL DEFAULT 0,
  bill_discount DECIMAL(14,2) NOT NULL DEFAULT 0,
  other_charges DECIMAL(14,2) NOT NULL DEFAULT 0,
  round_off DECIMAL(14,2) NOT NULL DEFAULT 0,
  grand_total DECIMAL(14,2) NOT NULL DEFAULT 0,
  paid_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  due_amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  cost_total DECIMAL(14,2) NOT NULL DEFAULT 0,
  is_interstate TINYINT NOT NULL DEFAULT 0,
  description VARCHAR(255) NULL,
  remarks TEXT NULL,
  row_version INT NOT NULL DEFAULT 1,
  created_by INT NULL, created_by_name VARCHAR(50) NULL, created_at DATETIME NULL, device_name VARCHAR(100) NULL,
  modified_by INT NULL, modified_by_name VARCHAR(50) NULL, modified_at DATETIME NULL, modified_device VARCHAR(100) NULL,
  is_deleted TINYINT NOT NULL DEFAULT 0, deleted_by INT NULL, deleted_by_name VARCHAR(50) NULL, deleted_at DATETIME NULL, delete_reason VARCHAR(255) NULL,
  UNIQUE KEY (dtype, doc_no),
  INDEX (dtype, doc_date), INDEX (party_id), INDEX (created_by), INDEX (against_doc_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS document_items (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  document_id BIGINT NOT NULL,
  line_no INT NOT NULL DEFAULT 1,
  product_id INT NOT NULL,
  product_name VARCHAR(200) NULL,
  hsn_code VARCHAR(20) NULL,
  unit VARCHAR(30) NULL,
  qty DECIMAL(14,3) NOT NULL DEFAULT 0,
  free_qty DECIMAL(14,3) NOT NULL DEFAULT 0,
  rate DECIMAL(14,2) NOT NULL DEFAULT 0,
  mrp DECIMAL(14,2) NOT NULL DEFAULT 0,
  amount DECIMAL(14,2) NOT NULL DEFAULT 0,
  disc_pct DECIMAL(6,2) NOT NULL DEFAULT 0,
  disc_amt DECIMAL(14,2) NOT NULL DEFAULT 0,
  taxable DECIMAL(14,2) NOT NULL DEFAULT 0,
  gst_pct DECIMAL(5,2) NOT NULL DEFAULT 0,
  gst_amt DECIMAL(14,2) NOT NULL DEFAULT 0,
  total DECIMAL(14,2) NOT NULL DEFAULT 0,
  cost_rate DECIMAL(14,2) NOT NULL DEFAULT 0,
  INDEX (document_id), INDEX (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Every stock change
CREATE TABLE IF NOT EXISTS stock_transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  txn_date DATE NOT NULL,
  txn_type VARCHAR(10) NOT NULL,        -- OPENING, PURCHASE, SALE, SRET, PRET, ADJ
  document_id BIGINT NULL,
  doc_no VARCHAR(40) NULL,
  qty_in DECIMAL(14,3) NOT NULL DEFAULT 0,
  qty_out DECIMAL(14,3) NOT NULL DEFAULT 0,
  rate DECIMAL(14,2) NOT NULL DEFAULT 0,
  narration VARCHAR(255) NULL,
  user_id INT NULL, user_name VARCHAR(50) NULL, device_name VARCHAR(100) NULL,
  created_at DATETIME NOT NULL,
  INDEX (product_id, txn_date), INDEX (document_id), INDEX (txn_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Customer / supplier ledger (debit = party owes us more)
CREATE TABLE IF NOT EXISTS party_ledger (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  party_id INT NOT NULL,
  txn_date DATE NOT NULL,
  txn_type VARCHAR(10) NOT NULL,
  document_id BIGINT NULL,
  doc_no VARCHAR(40) NULL,
  debit DECIMAL(14,2) NOT NULL DEFAULT 0,
  credit DECIMAL(14,2) NOT NULL DEFAULT 0,
  narration VARCHAR(255) NULL,
  user_id INT NULL, user_name VARCHAR(50) NULL,
  created_at DATETIME NOT NULL,
  INDEX (party_id, txn_date), INDEX (document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cash / bank / UPI book
CREATE TABLE IF NOT EXISTS account_transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  account_id INT NOT NULL,
  txn_date DATE NOT NULL,
  txn_type VARCHAR(10) NOT NULL,
  document_id BIGINT NULL,
  doc_no VARCHAR(40) NULL,
  party_id INT NULL,
  amount_in DECIMAL(14,2) NOT NULL DEFAULT 0,
  amount_out DECIMAL(14,2) NOT NULL DEFAULT 0,
  narration VARCHAR(255) NULL,
  user_id INT NULL, user_name VARCHAR(50) NULL,
  created_at DATETIME NOT NULL,
  INDEX (account_id, txn_date), INDEX (document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS held_bills (
  id INT AUTO_INCREMENT PRIMARY KEY,
  label VARCHAR(100) NULL,
  party_id INT NULL,
  payload MEDIUMTEXT NOT NULL,
  grand_total DECIMAL(14,2) NOT NULL DEFAULT 0,
  user_id INT NULL, user_name VARCHAR(50) NULL, device_name VARCHAR(100) NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS backups (
  id INT AUTO_INCREMENT PRIMARY KEY,
  filename VARCHAR(255) NOT NULL,
  filepath VARCHAR(500) NOT NULL,
  size_bytes BIGINT NOT NULL DEFAULT 0,
  btype VARCHAR(10) NOT NULL,           -- MANUAL, AUTO, RESTORE
  status VARCHAR(20) NOT NULL DEFAULT 'OK',
  created_by INT NULL, created_by_name VARCHAR(50) NULL,
  created_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS=1;
