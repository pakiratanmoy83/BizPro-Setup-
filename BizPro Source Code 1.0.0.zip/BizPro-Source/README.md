# BizPro Business Manager 1.0

Multi-user Business, Inventory, Purchase & Sales Management (PHP 8 + MySQL/MariaDB, LAN client/server).

## Windows installation

Run `BizPro-Setup-1.0.0.exe` on the server PC (choose **Server**), then on every other PC (choose **Client**). Full details are below.

## Install from source (any OS, developers)

1. PHP 8.1+ with pdo_mysql, mbstring, gd; MySQL 8 / MariaDB 10.6+.
2. Point a web server document root at `bizpro/` (the `.htaccess` files block `inc`, `config`, `cli`, `backups`, `modules`).
3. Either open `http://server/install/` (web installer) or run:
   `php cli/install.php --host=127.0.0.1 --port=3306 --db=bizpro --user=USER --pass=PASS --adminpass=admin123 --business="My Shop" --backupdir=/path/outside/webroot`
4. Log in as `admin` / `admin123` and change the password right away (My Profile).
5. Daily backup: cron/Task Scheduler -> `php cli/backup.php`.

## Rebuild the Windows installer

`win/` contains `bizpro.nsi`, the templates (`tpl/`) and README. Put PHP 8.3 TS x64, Apache Lounge 2.4 x64, MariaDB 11.4 winx64 and vc_redist.x64 into `win/stage/` as in `bizpro.nsi`, then run `makensis bizpro.nsi`.

## Tests

The `tests/` folder has Python scripts for smoke, sweep, e2e, roles, concurrency and Playwright UI tests.

```
BizPro Business Manager 1.0 - Multi-User Business, Inventory, Purchase & Sales
===============================================================================

WHAT IS INSTALLED
-----------------
SERVER (install on ONE PC - the one that stores the data)
  C:\BizPro\app       application (PHP)
  C:\BizPro\php       PHP 8.3 runtime
  C:\BizPro\apache    Apache 2.4 web server  -> Windows service "BizProWeb"
  C:\BizPro\mariadb   MariaDB 11.4 database   -> Windows service "BizProDB" (port 3307, local only)
  C:\BizPro\data      the business database (one central database for all users)
  C:\BizPro\backups   automatic + manual backups
  C:\BizPro\logs      setup / web / PHP logs
  C:\BizPro\secure    database passwords (Administrators only)
  Both services start automatically with Windows (no one needs to log in).
  Firewall rule "BizPro Server" opens the web port (default 8080) for private/domain networks.
  Scheduled task "BizPro Auto Backup" backs up the database every day (default 23:00).

CLIENT (install on every other PC in the LAN)
  Only a desktop / Start Menu shortcut "BizPro" is created. It opens the software from the
  server in an app window (Microsoft Edge / Chrome app mode). No database on client PCs.
  The shortcut sends the PC's Windows computer name, which is recorded in every transaction
  and in the Activity Log.

LAN SETUP - STEP BY STEP
------------------------
1. Choose the server PC. Give it a fixed IP address (router DHCP reservation), e.g. 192.168.1.10.
2. Run BizPro-Setup-1.0.0.exe on it -> choose "Server" -> enter business name, admin password,
   port (8080) and backup time.
3. When setup finishes, open BizPro -> Help. It shows the server PC name / IP address.
4. On each other PC run the same BizPro-Setup-1.0.0.exe -> choose "Client" -> enter the server
   IP (e.g. 192.168.1.10) and port 8080.
5. Any device on the LAN can also open  http://192.168.1.10:8080/  in a browser.
   Set the Windows network profile of the server to "Private" so the firewall rule applies.

FIRST LOGIN
-----------
  Username: admin
  Password: the admin password you entered during server setup.
  (If you install from source with the command-line installer, the example password is admin123 -
   change it immediately from My Profile -> Change Password.)
  Then: Settings (business details, GSTIN, invoice terms, logo) -> Users & Roles (create users).

ROLES (fully customisable; Admin can also allow/deny individual permissions per user)
  Admin            full control, users, permissions, settings, backup/restore, recycle bin purge
  Manager          all business operations and reports, no user/security administration
  Sales User       billing, customers, receipts, sales returns (own bills by default)
  Purchase User    purchases, suppliers, supplier payments, purchase returns
  Viewer/Accounts  read-only views and reports

KEYBOARD SHORTCUTS
  F1 Help  F2 Product  F3 Customer  F4 Supplier  F5 New Sale  F6 New Purchase
  F7 Receipt  F8 Supplier Payment  Ctrl+S Save  Ctrl+P Print  Esc Close

BACKUP & RESTORE
  Automatic: every day at the configured time (C:\BizPro\backups, old ones cleaned per Settings).
  Manual:    BizPro -> Backup & Restore -> Backup Now, or Start Menu -> BizPro -> Backup Now.
  Restore:   BizPro -> Backup & Restore (Admin only). A safety backup is taken automatically
             before every restore.
  Copy the backups folder to a USB drive / cloud folder regularly.

SERVER TOOLS (Start Menu -> BizPro)
  Start / Stop / Restart Server, Repair Server (re-applies configuration, keeps data),
  Backups Folder, Server Logs, Uninstall.

UPGRADE
  Run a newer setup on the server and choose "Server" - data, users and settings are kept.

UNINSTALL
  Settings -> Apps -> BizPro Business Manager. You will be asked whether to delete the database
  and backups; answer NO to keep them (they are reused on reinstall).

TROUBLESHOOTING
  Clients cannot connect: ping the server IP; check the "BizPro Server" firewall rule and that
  the network profile is Private; check services BizProWeb and BizProDB are Running (services.msc).
  Setup error: see C:\BizPro\logs\setup.log, then run "Repair Server".
  Port 8080 in use by another program: reinstall the server with a different port.

REQUIREMENTS
  Windows 10 / 11 or Windows Server 2016+ (64-bit). Server: 4 GB RAM recommended, 1 GB disk.
  Clients: Microsoft Edge (built into Windows) or Google Chrome.
```
