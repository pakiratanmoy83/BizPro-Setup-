@echo off
title BizPro - Repair / Re-run server setup
echo This re-applies the web server, PHP, firewall and backup configuration.
echo Existing data is kept.
pause
> "%~dp0install\setup.ini" echo inst=%~dp0
>> "%~dp0install\setup.ini" type "%~dp0install\last.ini"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install\setup-server.ps1" -Ini "%~dp0install\setup.ini"
pause
