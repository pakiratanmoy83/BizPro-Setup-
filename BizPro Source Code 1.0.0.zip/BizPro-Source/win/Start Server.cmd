@echo off
title BizPro - Start Server
net start BizProDB
net start BizProWeb
pause
