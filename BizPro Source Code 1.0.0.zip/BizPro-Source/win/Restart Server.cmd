@echo off
title BizPro - Restart Server
net stop BizProWeb
net stop BizProDB
net start BizProDB
net start BizProWeb
pause
