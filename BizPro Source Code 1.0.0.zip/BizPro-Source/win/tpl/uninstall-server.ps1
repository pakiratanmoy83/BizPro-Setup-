# Removes BizPro services, firewall rule and scheduled task. Data/backups are removed only with -RemoveData.
param([string]$Inst, [switch]$RemoveData)
$ErrorActionPreference = 'Continue'
foreach ($s in 'BizProWeb','BizProDB') {
    if (Get-Service -Name $s -ErrorAction SilentlyContinue) { Stop-Service $s -Force -ErrorAction SilentlyContinue; & sc.exe delete $s | Out-Null }
}
Get-NetFirewallRule -DisplayName 'BizPro Server' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
Unregister-ScheduledTask -TaskName 'BizPro Auto Backup' -Confirm:$false -ErrorAction SilentlyContinue
Start-Sleep 2
if ($RemoveData) { Remove-Item -Recurse -Force "$Inst\data","$Inst\backups","$Inst\secure","$Inst\app\config" -ErrorAction SilentlyContinue }
exit 0
