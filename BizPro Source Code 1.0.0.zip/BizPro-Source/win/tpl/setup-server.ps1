# BizPro server setup - executed by the installer (elevated).
# Reads parameters from setup.ini written by the installer, then:
#  1. installs VC++ runtime   2. initialises MariaDB + Windows service (BizProDB)
#  3. creates the application database/user   4. installs the BizPro database schema
#  5. configures PHP + Apache and installs the web service (BizProWeb)
#  6. opens the firewall port   7. schedules the daily automatic backup
param([string]$Ini)
$ErrorActionPreference = 'Continue'   # native tools write to stderr; failures are checked explicitly
function IniVal($k, $def='') { $l = Get-Content $Ini | Where-Object { $_ -match "^$k=" } | Select-Object -First 1; if ($l) { return $l.Substring($k.Length + 1) } return $def }
$Inst     = (IniVal 'inst').TrimEnd('\')
$Port     = [int](IniVal 'port' '8080')
$DbPort   = [int](IniVal 'dbport' '3307')
$AdminPw  = IniVal 'adminpass' 'admin123'
$Business = IniVal 'business' 'My Business'
$Tz       = IniVal 'tz' 'Asia/Kolkata'
$BkTime   = IniVal 'backuptime' '23:00'
$InstF    = $Inst -replace '\\','/'
New-Item -ItemType Directory -Force -Path "$Inst\logs","$Inst\tmp\sessions","$Inst\backups","$Inst\secure" | Out-Null
$Log = "$Inst\logs\setup.log"
function Log($m) { $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $m; Add-Content -Path $Log -Value $line; Write-Host $line }
function Run($exe, $argList) {
    Log "RUN $exe $($argList -replace '--password=\S+','--password=***' -replace 'IDENTIFIED BY ''[^'']+''','IDENTIFIED BY ***')"
    $p = Start-Process -FilePath $exe -ArgumentList $argList -NoNewWindow -Wait -PassThru -RedirectStandardOutput "$Inst\tmp\out.txt" -RedirectStandardError "$Inst\tmp\err.txt"
    $o = (Get-Content "$Inst\tmp\out.txt" -Raw -ErrorAction SilentlyContinue) + (Get-Content "$Inst\tmp\err.txt" -Raw -ErrorAction SilentlyContinue)
    if ($o) { Add-Content -Path $Log -Value $o }
    return $p.ExitCode
}
function NewSecret() { -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 24 | ForEach-Object { [char]$_ }) }
try {
    Log "BizPro server setup started. Folder=$Inst WebPort=$Port DbPort=$DbPort"

    # 1. Visual C++ runtime (required by PHP, Apache and MariaDB)
    if (Test-Path "$Inst\redist\vc_redist.x64.exe") { Run "$Inst\redist\vc_redist.x64.exe" '/install /quiet /norestart' | Out-Null }

    # 2. MariaDB database server
    $bin = "$Inst\mariadb\bin"
    $secFile = "$Inst\secure\db.ini"
    if (Test-Path $secFile) {
        $RootPw = (Get-Content $secFile | Where-Object { $_ -match '^root=' }).Substring(5)
        $AppPw  = (Get-Content $secFile | Where-Object { $_ -match '^app=' }).Substring(4)
        Log 'Existing database credentials found (upgrade / reinstall).'
    } else {
        $RootPw = NewSecret; $AppPw = NewSecret
        Set-Content -Path $secFile -Value "root=$RootPw`r`napp=$AppPw`r`nport=$DbPort"
    }
    # restrict the secret file to Administrators + SYSTEM
    & icacls "$Inst\secure" /inheritance:r /grant:r "*S-1-5-32-544:(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" | Out-Null

    $svc = Get-Service -Name 'BizProDB' -ErrorAction SilentlyContinue
    if (-not (Test-Path "$Inst\data\mysql")) {
        if ($svc) { Stop-Service BizProDB -Force -ErrorAction SilentlyContinue; & sc.exe delete BizProDB | Out-Null; Start-Sleep 2 }
        if (Test-Path "$Inst\data") { Remove-Item -Recurse -Force "$Inst\data" }   # leftover from a failed attempt (no system tables)
        $rc = Run "$bin\mariadb-install-db.exe" "--datadir=`"$Inst\data`" --service=BizProDB --port=$DbPort --password=$RootPw --allow-remote-root-access"
        if ($rc -ne 0) { throw "mariadb-install-db failed (exit $rc). See $Log" }
        Add-Content -Path "$Inst\data\my.ini" -Value (Get-Content "$Inst\install\my.ini.append" -Raw)
    } elseif (-not $svc) {
        Run "$bin\mariadbd.exe" "--install BizProDB --defaults-file=`"$Inst\data\my.ini`"" | Out-Null
    }
    & sc.exe config BizProDB start= auto | Out-Null
    & sc.exe failure BizProDB reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    Start-Service BizProDB -ErrorAction SilentlyContinue
    $ok = $false
    for ($i = 0; $i -lt 60; $i++) {
        & "$bin\mariadb-admin.exe" --host=127.0.0.1 --port=$DbPort -uroot "--password=$RootPw" ping 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { $ok = $true; break }
        Start-Sleep 1
    }
    if (-not $ok) { throw 'Database service did not start. See logs\setup.log and data\*.err' }
    Log 'Database service running.'

    # 3. Application database + restricted user
    $sql = "CREATE DATABASE IF NOT EXISTS bizpro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; " +
           "CREATE USER IF NOT EXISTS 'bizpro'@'localhost' IDENTIFIED BY '$AppPw'; CREATE USER IF NOT EXISTS 'bizpro'@'127.0.0.1' IDENTIFIED BY '$AppPw'; " +
           "ALTER USER 'bizpro'@'localhost' IDENTIFIED BY '$AppPw'; ALTER USER 'bizpro'@'127.0.0.1' IDENTIFIED BY '$AppPw'; " +
           "GRANT ALL PRIVILEGES ON bizpro.* TO 'bizpro'@'localhost'; GRANT ALL PRIVILEGES ON bizpro.* TO 'bizpro'@'127.0.0.1'; " +
           "GRANT PROCESS, RELOAD ON *.* TO 'bizpro'@'localhost'; GRANT PROCESS, RELOAD ON *.* TO 'bizpro'@'127.0.0.1'; FLUSH PRIVILEGES;"
    $rc = Run "$bin\mariadb.exe" "--host=127.0.0.1 --port=$DbPort -uroot --password=$RootPw -e `"$sql`""
    if ($rc -ne 0) { throw "Could not create application database user (exit $rc)" }

    # 4. PHP configuration
    (Get-Content "$Inst\install\php.ini.tpl" -Raw).Replace('@@INST@@', $InstF).Replace('@@TZ@@', $Tz) | Set-Content -Path "$Inst\php\php.ini" -Encoding ASCII
    $php = "$Inst\php\php.exe"
    $mods = (& $php -m 2>&1 | Out-String)
    Add-Content -Path $Log -Value "PHP modules:`r`n$mods"
    foreach ($m in 'pdo_mysql','mbstring','gd','zlib') { if ($mods -notmatch "(?m)^$m\s*$") { throw "PHP extension '$m' did not load. See $Log" } }

    # 5. BizPro schema, roles, admin user (skipped automatically if already installed)
    if (-not (Test-Path "$Inst\app\config\config.php")) {
        $argsI = "`"$Inst\app\cli\install.php`" --host=127.0.0.1 --port=$DbPort --db=bizpro --user=bizpro --pass=$AppPw --admin=admin --adminpass=`"$AdminPw`" --business=`"$($Business -replace '"','')`" --backupdir=`"$InstF/backups`""
        $rc = Run $php $argsI
        if ($rc -ne 0) { throw "BizPro database installation failed (exit $rc). See $Log" }
        Log 'BizPro database installed.'
    } else { Log 'Existing BizPro configuration kept.' }

    # 6. Apache web server service
    (Get-Content "$Inst\install\httpd.conf.tpl" -Raw).Replace('@@INST@@', $InstF).Replace('@@PORT@@', "$Port") | Set-Content -Path "$Inst\apache\conf\httpd.conf" -Encoding ASCII
    $httpd = "$Inst\apache\bin\httpd.exe"
    $rc = Run $httpd '-t'
    if ($rc -ne 0) { throw 'Web server configuration test failed. See logs\setup.log' }
    if (-not (Get-Service -Name 'BizProWeb' -ErrorAction SilentlyContinue)) { Run $httpd '-k install -n BizProWeb' | Out-Null }
    & sc.exe config BizProWeb start= auto | Out-Null
    & sc.exe failure BizProWeb reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    Restart-Service BizProWeb -ErrorAction SilentlyContinue
    Start-Service BizProWeb -ErrorAction SilentlyContinue
    if ((Get-Service BizProWeb).Status -ne 'Running') {
        $el = Get-Content "$Inst\logs\web_error.log" -Tail 20 -ErrorAction SilentlyContinue | Out-String
        throw "Web service BizProWeb did not start. Is port $Port already used by another program? Last web log lines:`r`n$el"
    }
    Log 'Web service running.'

    # 7. Firewall: allow LAN clients to reach the web port (database stays local-only)
    try {
    Get-NetFirewallRule -DisplayName 'BizPro Server' -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
    New-NetFirewallRule -DisplayName 'BizPro Server' -Direction Inbound -Action Allow -Protocol TCP -LocalPort $Port -Profile Private,Domain -ErrorAction Stop | Out-Null
    Log "Firewall rule added for TCP $Port (private/domain networks)."
    } catch { Log "WARNING: firewall rule could not be added ($_). Open TCP $Port manually in Windows Firewall." }

    # 8. Daily automatic backup (runs as SYSTEM even when nobody is logged in)
    try {
    Unregister-ScheduledTask -TaskName 'BizPro Auto Backup' -Confirm:$false -ErrorAction SilentlyContinue
    $act = New-ScheduledTaskAction -Execute $php -Argument "`"$Inst\app\cli\backup.php`"" -WorkingDirectory "$Inst\app"
    $trg = New-ScheduledTaskTrigger -Daily -At $BkTime
    $prn = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 2)
    Register-ScheduledTask -TaskName 'BizPro Auto Backup' -Action $act -Trigger $trg -Principal $prn -Settings $set -Force -ErrorAction Stop | Out-Null
    Log "Automatic backup scheduled daily at $BkTime."
    } catch { Log "WARNING: automatic backup task could not be created ($_). Use Backup Now or create it in Task Scheduler." }

    # quick self-test
    try { $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 20 "http://127.0.0.1:$Port/login.php"; Log "Self-test HTTP $($r.StatusCode)" } catch { Log "Self-test warning: $_" }
    Log 'SETUP COMPLETED'
    exit 0
} catch {
    Log "ERROR: $_"
    exit 1
} finally {
    Remove-Item -Path $Ini -Force -ErrorAction SilentlyContinue
}
