@echo off
title BizPro - Backup Now
"%~dp0php\php.exe" "%~dp0app\cli\backup.php"
pause
