@echo off
title BizPro - Stop Server
net stop BizProWeb
net stop BizProDB
pause
