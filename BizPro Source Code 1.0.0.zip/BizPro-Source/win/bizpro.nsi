; BizPro Business Manager - Windows installer (Server + LAN Client)
; Build:  makensis bizpro.nsi
Unicode true
ManifestDPIAware true
SetCompressor /SOLID lzma
SetCompressorDictSize 64
RequestExecutionLevel admin

!define APPNAME   "BizPro Business Manager"
!define APPSHORT  "BizPro"
!define VERSION   "1.0.0"
!define PUBLISHER "BizPro"
!define UNKEY     "Software\Microsoft\Windows\CurrentVersion\Uninstall\BizPro"
!define REGKEY    "Software\BizPro"

!include "MUI2.nsh"
!include "nsDialogs.nsh"
!include "LogicLib.nsh"
!include "x64.nsh"
!include "FileFunc.nsh"
!include "WinMessages.nsh"

Name "${APPNAME}"
OutFile "BizPro-Setup-${VERSION}.exe"
InstallDir "C:\BizPro"
BrandingText "${APPNAME} ${VERSION}"
VIProductVersion "${VERSION}.0"
VIAddVersionKey "ProductName" "${APPNAME}"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "ProductVersion" "${VERSION}"
VIAddVersionKey "CompanyName" "${PUBLISHER}"
VIAddVersionKey "FileDescription" "${APPNAME} Setup"
VIAddVersionKey "LegalCopyright" "${PUBLISHER}"

!define MUI_ICON   "stage\bizpro.ico"
!define MUI_UNICON "stage\bizpro.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Welcome to ${APPNAME} Setup"
!define MUI_WELCOMEPAGE_TEXT "Multi-user Business, Inventory, Purchase and Sales Management.$\r$\n$\r$\nInstall the SERVER on the one PC that stores the business data (database + web service).$\r$\n$\r$\nInstall the CLIENT on every other PC in the LAN. Clients connect to the server over the network - there is no separate database on client PCs.$\r$\n$\r$\nClick Next to continue."

Var Mode          ; "server" or "client"
Var RadServer
Var RadClient
Var Business
Var AdminPass
Var AdminPass2
Var WebPort
Var BackupTime
Var ServerHost
Var ServerPort
Var hBusiness
Var hAdminPass
Var hAdminPass2
Var hWebPort
Var hBackupTime
Var hServerHost
Var hServerPort
Var PcName

!insertmacro MUI_PAGE_WELCOME
Page custom ModePage ModePageLeave
!define MUI_PAGE_CUSTOMFUNCTION_PRE DirPre
!define MUI_DIRECTORYPAGE_TEXT_TOP "The server files, database and backups will be stored in this folder. Use a short path without spaces (recommended: C:\BizPro)."
!insertmacro MUI_PAGE_DIRECTORY
Page custom ServerPage ServerPageLeave
Page custom ClientPage ClientPageLeave
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "Open ${APPSHORT} now"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp
!define MUI_FINISHPAGE_SHOWREADME "$INSTDIR\README.txt"
!define MUI_FINISHPAGE_SHOWREADME_TEXT "View README (LAN setup and default login)"
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  ${IfNot} ${RunningX64}
    MessageBox MB_ICONSTOP "${APPNAME} requires 64-bit Windows 10 or later."
    Abort
  ${EndIf}
  SetRegView 64
  StrCpy $Mode "server"
  StrCpy $WebPort "8080"
  StrCpy $BackupTime "23:00"
  StrCpy $ServerHost ""
  StrCpy $ServerPort "8080"
  ReadEnvStr $PcName COMPUTERNAME
  ; previous install?
  ReadRegStr $0 HKLM "${REGKEY}" "Mode"
  ${If} $0 != ""
    StrCpy $Mode $0
    ReadRegStr $1 HKLM "${REGKEY}" "InstallDir"
    ${If} $1 != ""
      StrCpy $INSTDIR $1
    ${EndIf}
    ReadRegStr $1 HKLM "${REGKEY}" "WebPort"
    ${If} $1 != ""
      StrCpy $WebPort $1
    ${EndIf}
    ReadRegStr $1 HKLM "${REGKEY}" "ServerHost"
    StrCpy $ServerHost $1
    ReadRegStr $1 HKLM "${REGKEY}" "ServerPort"
    ${If} $1 != ""
      StrCpy $ServerPort $1
    ${EndIf}
  ${EndIf}
FunctionEnd

; ---------------- Page: installation type ----------------
Function ModePage
  !insertmacro MUI_HEADER_TEXT "Installation Type" "Choose what to install on this computer."
  nsDialogs::Create 1018
  Pop $0
  ${NSD_CreateRadioButton} 10u 10u 280u 12u "&Server  (main PC - stores the database for all users)"
  Pop $RadServer
  ${NSD_CreateLabel} 24u 24u 270u 30u "Installs the database (MariaDB), web service (Apache + PHP), the application, automatic daily backup and the firewall rule. Install on ONE computer only."
  Pop $0
  ${NSD_CreateRadioButton} 10u 62u 280u 12u "&Client  (other PCs in the LAN)"
  Pop $RadClient
  ${NSD_CreateLabel} 24u 76u 270u 30u "Creates a ${APPSHORT} desktop shortcut that connects to the server PC. No database or data is stored on client PCs."
  Pop $0
  ${If} $Mode == "client"
    ${NSD_Check} $RadClient
  ${Else}
    ${NSD_Check} $RadServer
  ${EndIf}
  nsDialogs::Show
FunctionEnd

Function ModePageLeave
  ${NSD_GetState} $RadClient $0
  ${If} $0 == ${BST_CHECKED}
    StrCpy $Mode "client"
    ReadRegStr $1 HKLM "${REGKEY}" "InstallDir"
    ${If} $1 == ""
      StrCpy $INSTDIR "$PROGRAMFILES64\BizPro Client"
    ${EndIf}
  ${Else}
    StrCpy $Mode "server"
    ReadRegStr $1 HKLM "${REGKEY}" "InstallDir"
    ${If} $1 == ""
      StrCpy $INSTDIR "C:\BizPro"
    ${EndIf}
  ${EndIf}
FunctionEnd

Function DirPre
  ${If} $Mode == "client"
    Abort
  ${EndIf}
FunctionEnd

; ---------------- Page: server settings ----------------
Function ServerPage
  ${If} $Mode != "server"
    Abort
  ${EndIf}
  IfFileExists "$INSTDIR\app\config\config.php" 0 +3
    MessageBox MB_ICONINFORMATION "An existing ${APPSHORT} server was found in $INSTDIR.$\r$\nIt will be upgraded; your data, users and passwords are kept."
    Abort
  !insertmacro MUI_HEADER_TEXT "Server Settings" "Business details and the administrator login."
  nsDialogs::Create 1018
  Pop $0
  ${NSD_CreateLabel} 0 2u 110u 10u "Business / shop name:"
  Pop $0
  ${NSD_CreateText} 115u 0 180u 12u "$Business"
  Pop $hBusiness
  ${NSD_CreateLabel} 0 22u 110u 10u "Admin username:"
  Pop $0
  ${NSD_CreateLabel} 115u 22u 180u 10u "admin"
  Pop $0
  ${NSD_CreateLabel} 0 40u 110u 10u "Admin password (min 6):"
  Pop $0
  ${NSD_CreatePassword} 115u 38u 180u 12u ""
  Pop $hAdminPass
  ${NSD_CreateLabel} 0 58u 110u 10u "Confirm password:"
  Pop $0
  ${NSD_CreatePassword} 115u 56u 180u 12u ""
  Pop $hAdminPass2
  ${NSD_CreateLabel} 0 78u 110u 10u "Web port (LAN):"
  Pop $0
  ${NSD_CreateNumber} 115u 76u 50u 12u "$WebPort"
  Pop $hWebPort
  ${NSD_CreateLabel} 0 96u 110u 10u "Daily auto-backup time:"
  Pop $0
  ${NSD_CreateText} 115u 94u 50u 12u "$BackupTime"
  Pop $hBackupTime
  ${NSD_CreateLabel} 170u 96u 125u 10u "(24h HH:MM)"
  Pop $0
  ${NSD_CreateLabel} 0 116u 295u 24u "Clients will open http://$PcName:<port>/ . The database listens only on this PC (127.0.0.1) and is never exposed to the network."
  Pop $0
  nsDialogs::Show
FunctionEnd

Function ServerPageLeave
  ${NSD_GetText} $hBusiness $Business
  ${NSD_GetText} $hAdminPass $AdminPass
  ${NSD_GetText} $hAdminPass2 $AdminPass2
  ${NSD_GetText} $hWebPort $WebPort
  ${NSD_GetText} $hBackupTime $BackupTime
  ${If} $Business == ""
    MessageBox MB_ICONEXCLAMATION "Please enter the business name."
    Abort
  ${EndIf}
  StrLen $0 $AdminPass
  ${If} $0 < 6
    MessageBox MB_ICONEXCLAMATION "Admin password must be at least 6 characters."
    Abort
  ${EndIf}
  ${If} $AdminPass != $AdminPass2
    MessageBox MB_ICONEXCLAMATION "Passwords do not match."
    Abort
  ${EndIf}
  ${If} $WebPort < 1
  ${OrIf} $WebPort > 65535
    MessageBox MB_ICONEXCLAMATION "Enter a valid port (e.g. 8080)."
    Abort
  ${EndIf}
  StrLen $0 $BackupTime
  ${If} $0 != 5
    MessageBox MB_ICONEXCLAMATION "Backup time must be in HH:MM format, e.g. 23:00"
    Abort
  ${EndIf}
FunctionEnd

; ---------------- Page: client settings ----------------
Function ClientPage
  ${If} $Mode != "client"
    Abort
  ${EndIf}
  !insertmacro MUI_HEADER_TEXT "Connect to Server" "Enter the name or IP address of the ${APPSHORT} server PC."
  nsDialogs::Create 1018
  Pop $0
  ${NSD_CreateLabel} 0 2u 120u 10u "Server PC name or IP address:"
  Pop $0
  ${NSD_CreateText} 125u 0 170u 12u "$ServerHost"
  Pop $hServerHost
  ${NSD_CreateLabel} 0 22u 120u 10u "Server web port:"
  Pop $0
  ${NSD_CreateNumber} 125u 20u 50u 12u "$ServerPort"
  Pop $hServerPort
  ${NSD_CreateLabel} 0 44u 295u 40u "Example: 192.168.1.10 or SHOP-SERVER. The server PC shows its address on the ${APPSHORT} Help page. Tip: give the server PC a fixed IP address in your router so clients always find it."
  Pop $0
  nsDialogs::Show
FunctionEnd

Function ClientPageLeave
  ${NSD_GetText} $hServerHost $ServerHost
  ${NSD_GetText} $hServerPort $ServerPort
  ${If} $ServerHost == ""
    MessageBox MB_ICONEXCLAMATION "Please enter the server PC name or IP address."
    Abort
  ${EndIf}
  ; connectivity check (warning only)
  nsExec::ExecToStack 'powershell -NoProfile -Command "try { (Invoke-WebRequest -UseBasicParsing -TimeoutSec 5 http://$ServerHost:$ServerPort/login.php).StatusCode } catch { 0 }"'
  Pop $0
  Pop $1
  StrCpy $1 $1 3
  ${If} $1 != "200"
    MessageBox MB_YESNO|MB_ICONQUESTION "Could not reach the ${APPSHORT} server at http://$ServerHost:$ServerPort/ right now.$\r$\n$\r$\nCheck that the server PC is on and connected to the LAN. Continue anyway?" IDYES +2
    Abort
  ${EndIf}
FunctionEnd

; ---------------- Shortcut helper ----------------
; $R0 = URL, $R1 = shortcut path
Function MakeAppShortcut
  StrCpy $R2 ""
  IfFileExists "$PROGRAMFILES32\Microsoft\Edge\Application\msedge.exe" 0 +2
    StrCpy $R2 "$PROGRAMFILES32\Microsoft\Edge\Application\msedge.exe"
  ${If} $R2 == ""
    IfFileExists "$PROGRAMFILES64\Microsoft\Edge\Application\msedge.exe" 0 +2
      StrCpy $R2 "$PROGRAMFILES64\Microsoft\Edge\Application\msedge.exe"
  ${EndIf}
  ${If} $R2 == ""
    IfFileExists "$PROGRAMFILES64\Google\Chrome\Application\chrome.exe" 0 +2
      StrCpy $R2 "$PROGRAMFILES64\Google\Chrome\Application\chrome.exe"
  ${EndIf}
  ${If} $R2 == ""
    IfFileExists "$PROGRAMFILES32\Google\Chrome\Application\chrome.exe" 0 +2
      StrCpy $R2 "$PROGRAMFILES32\Google\Chrome\Application\chrome.exe"
  ${EndIf}
  ${If} $R2 != ""
    CreateShortcut "$R1" "$R2" "--app=$R0 --start-maximized" "$INSTDIR\bizpro.ico" 0
  ${Else}
    CreateShortcut "$R1" "$WINDIR\explorer.exe" "$R0" "$INSTDIR\bizpro.ico" 0
  ${EndIf}
FunctionEnd

Function LaunchApp
  SetShellVarContext all
  ; launch through Explorer so the browser does not run with administrator rights
  Exec '"$WINDIR\explorer.exe" "$DESKTOP\${APPSHORT}.lnk"'
FunctionEnd

; ---------------- Install ----------------
Section "Install" SecMain
  SetShellVarContext all
  SetRegView 64
  SetOutPath "$INSTDIR"
  File "stage\bizpro.ico"
  File "README.txt"

  ${If} $Mode == "server"
    ; stop running services during upgrade so files can be replaced
    nsExec::Exec 'net stop BizProWeb'
    nsExec::Exec 'net stop BizProDB'
    DetailPrint "Copying application and runtimes (this can take a minute)..."
    SetOutPath "$INSTDIR\app"
    File /r "stage\app\*.*"
    SetOutPath "$INSTDIR\php"
    File /r "stage\php\*.*"
    SetOutPath "$INSTDIR\apache"
    File /r "stage\apache\*.*"
    SetOutPath "$INSTDIR\mariadb"
    File /r "stage\mariadb\*.*"
    SetOutPath "$INSTDIR\install"
    File /r "stage\install\*.*"
    SetOutPath "$INSTDIR\redist"
    File "stage\redist\vc_redist.x64.exe"
    SetOutPath "$INSTDIR"
    File "stage\Backup Now.cmd"
    File "stage\Start Server.cmd"
    File "stage\Stop Server.cmd"
    File "stage\Restart Server.cmd"
    File "stage\Repair Server.cmd"

    ; parameters for the setup script (deleted by the script after reading)
    Delete "$INSTDIR\install\setup.ini"
    FileOpen $0 "$INSTDIR\install\setup.ini" w
    FileWrite $0 "inst=$INSTDIR$\r$\n"
    FileWrite $0 "port=$WebPort$\r$\n"
    FileWrite $0 "dbport=3307$\r$\n"
    FileWrite $0 "adminpass=$AdminPass$\r$\n"
    FileWrite $0 "business=$Business$\r$\n"
    FileWrite $0 "tz=Asia/Kolkata$\r$\n"
    FileWrite $0 "backuptime=$BackupTime$\r$\n"
    FileClose $0
    ; non-secret copy used by "Repair Server.cmd"
    FileOpen $0 "$INSTDIR\install\last.ini" w
    FileWrite $0 "port=$WebPort$\r$\ndbport=3307$\r$\ntz=Asia/Kolkata$\r$\nbackuptime=$BackupTime$\r$\n"
    FileClose $0

    DetailPrint "Configuring database, web service, firewall and backup schedule..."
    nsExec::ExecToLog 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\install\setup-server.ps1" -Ini "$INSTDIR\install\setup.ini"'
    Pop $0
    Delete "$INSTDIR\install\setup.ini"
    ${If} $0 != "0"
      MessageBox MB_ICONSTOP "Server configuration did not complete (code $0).$\r$\n$\r$\nDetails are in:$\r$\n$INSTDIR\logs\setup.log$\r$\n$\r$\nFix the reported problem and run 'Repair Server' from the Start Menu."
    ${EndIf}

    StrCpy $R0 "http://localhost:$WebPort/login.php?pc=$PcName"
    WriteRegStr HKLM "${REGKEY}" "WebPort" "$WebPort"
  ${Else}
    StrCpy $R0 "http://$ServerHost:$ServerPort/login.php?pc=$PcName"
    WriteRegStr HKLM "${REGKEY}" "ServerHost" "$ServerHost"
    WriteRegStr HKLM "${REGKEY}" "ServerPort" "$ServerPort"
  ${EndIf}

  ; shortcuts
  StrCpy $R1 "$DESKTOP\${APPSHORT}.lnk"
  Call MakeAppShortcut
  CreateDirectory "$SMPROGRAMS\${APPSHORT}"
  StrCpy $R1 "$SMPROGRAMS\${APPSHORT}\${APPSHORT}.lnk"
  Call MakeAppShortcut
  ${If} $Mode == "server"
    CreateShortcut "$SMPROGRAMS\${APPSHORT}\Backup Now.lnk" "$INSTDIR\Backup Now.cmd" "" "$INSTDIR\bizpro.ico" 0
    CreateShortcut "$SMPROGRAMS\${APPSHORT}\Start Server.lnk" "$INSTDIR\Start Server.cmd"
    CreateShortcut "$SMPROGRAMS\${APPSHORT}\Stop Server.lnk" "$INSTDIR\Stop Server.cmd"
    CreateShortcut "$SMPROGRAMS\${APPSHORT}\Restart Server.lnk" "$INSTDIR\Restart Server.cmd"
    CreateShortcut "$SMPROGRAMS\${APPSHORT}\Repair Server.lnk" "$INSTDIR\Repair Server.cmd"
    CreateShortcut "$SMPROGRAMS\${APPSHORT}\Backups Folder.lnk" "$INSTDIR\backups"
    CreateShortcut "$SMPROGRAMS\${APPSHORT}\Server Logs.lnk" "$INSTDIR\logs"
  ${EndIf}
  CreateShortcut "$SMPROGRAMS\${APPSHORT}\README.lnk" "$INSTDIR\README.txt"
  CreateShortcut "$SMPROGRAMS\${APPSHORT}\Uninstall ${APPSHORT}.lnk" "$INSTDIR\Uninstall.exe"

  ; registry + uninstaller
  WriteRegStr HKLM "${REGKEY}" "Mode" "$Mode"
  WriteRegStr HKLM "${REGKEY}" "InstallDir" "$INSTDIR"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKLM "${UNKEY}" "DisplayName" "${APPNAME} ($Mode)"
  WriteRegStr HKLM "${UNKEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKLM "${UNKEY}" "Publisher" "${PUBLISHER}"
  WriteRegStr HKLM "${UNKEY}" "DisplayIcon" "$INSTDIR\bizpro.ico"
  WriteRegStr HKLM "${UNKEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr HKLM "${UNKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKLM "${UNKEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNKEY}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  IntFmt $0 "0x%08X" $0
  WriteRegDWORD HKLM "${UNKEY}" "EstimatedSize" "$0"
SectionEnd

; ---------------- Uninstall ----------------
Function un.onInit
  SetRegView 64
FunctionEnd

Section "Uninstall"
  SetShellVarContext all
  SetRegView 64
  ReadRegStr $0 HKLM "${REGKEY}" "Mode"
  ${If} $0 == "server"
    StrCpy $1 ""
    MessageBox MB_YESNO|MB_ICONEXCLAMATION|MB_DEFBUTTON2 "Also DELETE the business database and all backups?$\r$\n$\r$\nChoose NO to keep your data (recommended). It will be reused if you install the server again into $INSTDIR." IDNO +2
      StrCpy $1 "-RemoveData"
    DetailPrint "Stopping and removing BizPro services..."
    nsExec::ExecToLog 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\install\uninstall-server.ps1" -Inst "$INSTDIR" $1'
    RMDir /r "$INSTDIR\php"
    RMDir /r "$INSTDIR\apache"
    RMDir /r "$INSTDIR\mariadb"
    RMDir /r "$INSTDIR\install"
    RMDir /r "$INSTDIR\redist"
    RMDir /r "$INSTDIR\tmp"
    ; keep app\config (database connection) together with the data so a reinstall reuses it
    RMDir /r "$INSTDIR\app\assets"
    RMDir /r "$INSTDIR\app\modules"
    RMDir /r "$INSTDIR\app\inc"
    RMDir /r "$INSTDIR\app\cli"
    Delete "$INSTDIR\app\*.php"
    ${If} $1 == "-RemoveData"
      RMDir /r "$INSTDIR\app"
      RMDir /r "$INSTDIR\logs"
    ${EndIf}
    Delete "$INSTDIR\*.cmd"
  ${EndIf}
  Delete "$DESKTOP\${APPSHORT}.lnk"
  RMDir /r "$SMPROGRAMS\${APPSHORT}"
  Delete "$INSTDIR\bizpro.ico"
  Delete "$INSTDIR\README.txt"
  Delete "$INSTDIR\Uninstall.exe"
  RMDir "$INSTDIR"
  DeleteRegKey HKLM "${UNKEY}"
  DeleteRegKey HKLM "${REGKEY}"
SectionEnd
