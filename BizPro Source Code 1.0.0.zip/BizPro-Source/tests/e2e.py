from smoke import *
import json
s,r=login('admin','admin123','SERVER-PC')
H=lambda: {'X-CSRF-Token':csrf(s)}
def api(a,data=None,get=None):
    if get is not None: r=s.get(B+'api.php?a='+a,params=get)
    else: r=s.post(B+'api.php?a='+a,json=data,headers=H())
    try: j=r.json()
    except Exception: print('API RAW',a,r.text[:500]); raise
    return j
def post(page,data,params=''):
    html=s.get(B+'index.php?p='+page+params).text
    data['_csrf']=csrf(s,html)
    r=s.post(B+'index.php?p='+page+params,data=data)
    fl=re.findall(r'class="(?:toast|flash|alert)[^"]*(?:success|danger|error)[^"]*"[^>]*>(.*?)<',r.text)
    return r, fl
def dbv(sql):
    import subprocess
    return subprocess.run(['sudo','mysql','-N','bizpro','-e',sql],capture_output=True,text=True).stdout.strip()
# products
for n,(pr,sr,gst,op) in {'Soap':(20,30,18,10),'Rice 1kg':(50,60,5,0),'Pen':(5,10,12,100)}.items():
    r,fl=post('product',{'name':n,'purchase_rate':pr,'sale_rate':sr,'gst_pct':gst,'opening_stock':op,'min_stock':5,'is_active':1,'mrp':sr+5})
    print('product',n,r.url[-40:],fl)
print(dbv("select id,code,barcode,name,current_stock from products"))
# parties
r,fl=post('party',{'name':'Ravi Traders','mobile':'9800000001','opening_balance':500,'is_active':1,'credit_limit':0},'&t=C'); print('cust',fl)
r,fl=post('party',{'name':'ABC Wholesale','mobile':'9800000002','opening_balance':1000,'is_active':1},'&t=S'); print('supp',fl)
print(dbv("select id,ptype,code,name,opening_balance from parties"))
