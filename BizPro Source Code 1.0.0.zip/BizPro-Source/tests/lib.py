from smoke import *
import json
s,r=login('admin','admin123','SERVER-PC')
H=lambda: {'X-CSRF-Token':csrf(s)}
def api(a,data=None,get=None):
    if get is not None: r=s.get(B+'api.php?a='+a,params=get)
    else: r=s.post(B+'api.php?a='+a,json=data,headers=H())
    try: j=r.json()
    except Exception: print('API RAW',a,r.text[:500]); raise
    return j
def post(page,data,params=''):
    html=s.get(B+'index.php?p='+page+params).text
    data['_csrf']=csrf(s,html)
    r=s.post(B+'index.php?p='+page+params,data=data)
    fl=re.findall(r'class="(?:toast|flash|alert)[^"]*(?:success|danger|error)[^"]*"[^>]*>(.*?)<',r.text)
    return r, fl
def dbv(sql):
    import subprocess
    return subprocess.run(['sudo','mysql','-N','bizpro','-e',sql],capture_output=True,text=True).stdout.strip()
