import requests, re, sys
B='http://localhost:8080/'
def login(u,p,dev='TEST-PC'):
    s=requests.Session()
    r=s.get(B+'login.php'); tok=re.search(r'name="_csrf" value="([^"]+)"',r.text)
    data={'username':u,'password':p,'device_name':dev}
    if tok: data['_csrf']=tok.group(1)
    r=s.post(B+'login.php',data=data,allow_redirects=True)
    return s,r
def csrf(s,html=None):
    html=html or s.get(B+'index.php?p=dashboard').text
    m=re.search(r'name="_csrf" value="([^"]+)"',html) or re.search(r'csrf["\']?\s*[:=]\s*["\']([a-f0-9]{20,})',html)
    return m.group(1) if m else None
def check(s,path,expect=None):
    r=s.get(B+path)
    bad = [x for x in ['Fatal error','Warning:','Notice:','Deprecated:','Error: ','alert-danger'] if x in r.text]
    ok = r.status_code==200 and not bad and (expect is None or expect in r.text)
    print(('OK  ' if ok else 'FAIL'), r.status_code, path, bad, '' if ok else re.sub(r'\s+',' ',re.sub('<[^>]+>',' ',r.text))[:300])
    return r
if __name__=='__main__':
    s,r=login('admin','admin123')
    print('login ->', r.url)
