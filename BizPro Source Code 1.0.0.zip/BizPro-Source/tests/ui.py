from playwright.sync_api import sync_playwright
import re
B='http://localhost:8080/'
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=__import__('glob').glob('/home/user/.cache/ms-playwright/chromium-1217/chrome-linux*/chrome')[0]); pg=b.new_page(viewport={'width':1440,'height':900})
    pg.on('pageerror',lambda e: errs.append(('pageerror',pg.url,str(e))))
    pg.on('console',lambda m: m.type=='error' and errs.append(('console',pg.url,m.text)))
    pg.goto(B+'login.php'); pg.fill('input[name=username]','admin'); pg.fill('input[name=password]','admin123'); pg.press('input[name=password]','Enter'); pg.wait_for_load_state('networkidle')
    pg.screenshot(path='/tmp/dash.png',full_page=True)
    pg.keyboard.press('F5'); pg.wait_for_url('**doc_form**'); pg.wait_for_load_state('networkidle'); print('F5 ->',pg.url)
    pg.fill('#partyInput','Ravi'); pg.wait_for_timeout(700); pg.keyboard.press('ArrowDown'); pg.keyboard.press('Enter'); pg.wait_for_timeout(500)
    print('party info:',pg.inner_text('#partyInfo')[:80].replace('\n',' '))
    pg.fill('#scanInput','890000000001'); pg.keyboard.press('Enter'); pg.wait_for_timeout(600)
    pg.fill('#scanInput','3*P0002'); pg.keyboard.press('Enter'); pg.wait_for_timeout(600)
    print('items:',pg.inner_text('#tCount'),'grand:',pg.inner_text('#tGrand'))
    pg.screenshot(path='/tmp/sale.png',full_page=True)
    pg.keyboard.press('Control+s'); pg.wait_for_timeout(1500)
    print('modal:',pg.locator('.modal').first.inner_text()[:120].replace('\n',' ') if pg.locator('.modal').count() else 'none')
    pg.screenshot(path='/tmp/saved.png')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(800)
    for path in ['index.php?p=reports','index.php?p=report&r=sales_register','index.php?p=stock','index.php?p=report&r=pnl','index.php?p=settings','index.php?p=roles','index.php?p=user&id=2','index.php?p=voucher_form&t=RECEIPT','index.php?p=help','print.php?id=8&noprint=1','print.php?id=8&fmt=thermal&noprint=1']:
        pg.goto(B+path); pg.wait_for_load_state('networkidle')
        pg.screenshot(path='/tmp/'+re.sub(r'\W','_',path)[:40]+'.png',full_page=True)
    # excel export
    pg.goto(B+'index.php?p=report&r=sales_register')
    with pg.expect_download() as d: pg.click('[data-export=excel]')
    print('excel:',d.value.suggested_filename)
    with pg.expect_download() as d: pg.click('[data-export=pdf]')
    print('pdf:',d.value.suggested_filename)
    b.close()
print('JS errors:',errs)
