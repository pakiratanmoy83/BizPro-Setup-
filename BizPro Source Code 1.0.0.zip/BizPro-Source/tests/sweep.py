from lib import *
import subprocess,json
s,r=login('admin','admin123')
pages=['dashboard','profile','help','products','product','masters','parties&t=C','parties&t=S','party&t=C','party&t=S','stock','stock_ledger','accounts','book','reports','users','user','roles','audit','backup','settings','recycle','recycle&k=products','recycle&k=parties']
for t in ['SALE','PURCHASE','SRET','PRET','ADJ']:
    pages+=['doc_list&t='+t,'doc_form&t='+t]
for t in ['RECEIPT','PAYMENT','EXPENSE','CASH']:
    pages+=['doc_list&t='+t,'voucher_form&t='+t]
for tab in ['business','invoice','numbering','tax','security','database']: pages.append('settings&tab='+tab)
keys=subprocess.run(['php','-r','$GLOBALS["x"]=1; require "/home/user/workspace/bizpro/inc/bootstrap.php"; require "/home/user/workspace/bizpro/inc/reports_lib.php"; echo json_encode(array_keys(report_registry()));'],capture_output=True,text=True).stdout
print(keys[:200])
for k in json.loads(keys): pages.append('report&r='+k)
for p in pages: check(s,'index.php?p='+p)
ids=dbv("select group_concat(id) from documents").split(',')
for i in ids:
    check(s,'index.php?p=doc_view&id='+i); check(s,'print.php?id='+i+'&noprint=1'); check(s,'print.php?id='+i+'&fmt=thermal&noprint=1')
for pid in ['1','2','3']:
    check(s,'index.php?p=product&id='+pid+'&view=1'); check(s,'index.php?p=stock_ledger&product_id='+pid)
    check(s,'index.php?p=party&id='+pid+'&view=1') ; check(s,'print.php?type=statement&id='+pid+'&noprint=1')
for i in ids:
    t=dbv("select dtype from documents where id="+i)
    pg='doc_form' if t in('SALE','PURCHASE','SRET','PRET','ADJ') else 'voucher_form'
    check(s,f'index.php?p={pg}&t={t}&id={i}')
check(s,'api.php?a=dashboard')
