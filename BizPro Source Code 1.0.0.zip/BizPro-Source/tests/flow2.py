from lib import *
sale=dbv("select id from documents where doc_no='INV-00002'")
rv=dbv(f"select row_version from documents where id={sale}")
# edit sale: change rice qty 2->4
j=api('save_doc',{'dtype':'SALE','id':int(sale),'row_version':int(rv),'doc_date':'2026-09-23','party_id':2,'items':[{'product_id':2,'qty':4,'rate':60,'gst_pct':5},{'product_id':1,'qty':3,'rate':30,'gst_pct':18,'disc_pct':10}],'paid_amount':100,'payment_mode':'UPI'})
print('edit',j)
j=api('save_doc',{'dtype':'SALE','id':int(sale),'row_version':int(rv),'doc_date':'2026-09-23','party_id':2,'items':[{'product_id':2,'qty':1,'rate':60,'gst_pct':5}],'paid_amount':0,'payment_mode':'Credit'})
print('stale edit (expect ERR)',j)
print('rice stock',dbv("select current_stock from products where id=2"), 'ledger', dbv(f"select count(*),sum(debit) from party_ledger where document_id={sale}"))
# delete expense with reason
ex=dbv("select id from documents where dtype='EXPENSE'")
html=s.get(B+'index.php?p=doc_view&id='+ex).text
r=s.post(B+'index.php?p=doc_list&t=EXPENSE',data={'_csrf':csrf(s,html),'action':'delete','id':ex,'reason':'wrong entry'})
print('deleted', dbv(f"select is_deleted,deleted_by_name,delete_reason from documents where id={ex}"), 'acct rows', dbv(f"select count(*) from account_transactions where document_id={ex}"))
check(s,'index.php?p=recycle')
r,fl=post('recycle',{'k':'docs','action':'restore','id':ex}); print('restore',fl, dbv(f"select is_deleted from documents where id={ex}"), dbv(f"select count(*) from account_transactions where document_id={ex}"))
r=s.post(B+'index.php?p=doc_list&t=EXPENSE',data={'_csrf':csrf(s),'action':'delete','id':ex,'reason':'again'})
r,fl=post('recycle',{'k':'docs','action':'purge','id':ex,'confirm_text':'nope'}); print('purge bad confirm',fl)
r,fl=post('recycle',{'k':'docs','action':'purge','id':ex,'confirm_text':'DELETE'}); print('purge',fl, dbv(f"select count(*) from documents where id={ex}"), dbv("select action,module,ref_no from audit_log where action='PURGE'"))
# delete a sale that has a return -> should be blocked?
html=s.get(B+'index.php?p=doc_view&id='+sale).text
r=s.post(B+'index.php?p=doc_list&t=SALE',data={'_csrf':csrf(s,html),'action':'delete','id':sale,'reason':'x'},)
print('delete sale w/ return', re.findall(r'(?:success|danger)[^"]*"[^>]*>(.*?)<',r.text)[:2], dbv(f"select is_deleted from documents where id={sale}"))
# product delete & restore
r,fl=post('product',{'action':'delete'},'&id=3'); print('prod del',fl, dbv("select code,barcode,is_deleted from products where id=3"))
r,fl=post('recycle',{'k':'products','action':'restore','id':3}); print('prod restore',fl, dbv("select code,barcode,is_deleted from products where id=3"))
print(dbv("select action,module,ref_no,username,device_name from audit_log order by id desc limit 8"))
