from lib import *
import lib
for u,rid,extra in [('sales1',3,{}),('pur1',4,{}),('view1',5,{}),('mgr1',2,{}),('sales2',3,{'ov[report.sales]':'1','ov[sale.view_all]':'0'})]:
    d={'username':u,'full_name':u.upper(),'role_id':rid,'is_active':1,'password':'pass1234','password2':'pass1234'}; d.update(extra)
    r,fl=post('user',d); print('user',u,fl)
pages=['dashboard','products','product','masters','parties&t=C','parties&t=S','stock','accounts','book','reports','users','roles','audit','backup','settings','recycle',
 'doc_form&t=SALE','doc_form&t=PURCHASE','voucher_form&t=RECEIPT','voucher_form&t=PAYMENT','voucher_form&t=EXPENSE','doc_list&t=SALE','doc_list&t=PURCHASE',
 'report&r=sales_register','report&r=purchase_register','report&r=pnl','report&r=stock_current','report&r=user_activity']
res={}
for u in ['sales1','pur1','view1','mgr1','sales2']:
    ss,r=login(u,'pass1234','PC-'+u)
    row=[]
    for p in pages:
        t=ss.get(B+'index.php?p='+p).text
        denied=('Access denied' in t) or ('do not have permission' in t) or ('alert-danger' in t)
        row.append('-' if denied else 'Y')
    res[u]=row
    # API action checks
    lib.s=ss
    j=api('save_doc',{'dtype':'PURCHASE','doc_date':'2026-09-23','party_id':3,'items':[{'product_id':2,'qty':1,'rate':50,'gst_pct':5}],'paid_amount':0,'payment_mode':'Credit'})
    k=api('save_doc',{'dtype':'SALE','doc_date':'2026-09-23','party_id':2,'items':[{'product_id':3,'qty':1,'rate':10,'gst_pct':12}],'paid_amount':0,'payment_mode':'Credit'})
    print(u,'purchase:',j.get('doc_no') or j.get('error'),'| sale:',k.get('doc_no') or k.get('error'))
print('%-24s'%'page',' '.join('%-6s'%u for u in res))
for i,p in enumerate(pages): print('%-24s'%p[:24],' '.join('%-6s'%res[u][i] for u in res))
