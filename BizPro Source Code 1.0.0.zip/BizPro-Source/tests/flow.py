from lib import *
def ok(j,label): print(label, 'OK' if j.get('ok') else 'ERR', j.get('doc_no') or j.get('error'), j.get('grand_total','')); return j
r,fl=post('voucher_form',{'doc_date':'2026-09-23','amount':5000,'entry_type':'IN','account_id':1,'description':'Capital','after':''},'&t=CASH'); print('capital in',fl)
# purchase: 20 Rice @50 5%, 10 Soap @20 18%; paid 500 cash
p=ok(api('save_doc',{'dtype':'PURCHASE','doc_date':'2026-09-23','party_id':3,'ref_invoice_no':'ABC-77','items':[{'product_id':2,'qty':20,'rate':50,'gst_pct':5},{'product_id':1,'qty':10,'rate':20,'gst_pct':18}],'bill_discount':0,'other_charges':0,'paid_amount':500,'payment_mode':'Cash'}),'purchase')
# sale credit to Ravi: 2 Rice @60, 3 Soap @30 disc 10%
sl=ok(api('save_doc',{'dtype':'SALE','doc_date':'2026-09-23','party_id':2,'items':[{'product_id':2,'qty':2,'rate':60,'gst_pct':5},{'product_id':1,'qty':3,'rate':30,'gst_pct':18,'disc_pct':10}],'bill_discount':0,'other_charges':0,'paid_amount':100,'payment_mode':'UPI'}),'sale')
# walk-in cash sale
#ok(api('save_doc',{'dtype':'SALE','doc_date':'2026-09-23','party_id':1,'items':[{'product_id':3,'qty':5,'rate':10,'gst_pct':12}],'paid_amount':56,'payment_mode':'Cash'}),'cash sale')
# walk-in credit should fail
ok(api('save_doc',{'dtype':'SALE','doc_date':'2026-09-23','party_id':1,'items':[{'product_id':3,'qty':1,'rate':10,'gst_pct':12}],'paid_amount':0,'payment_mode':'Credit'}),'walkin credit (expect ERR)')
# oversell should fail
ok(api('save_doc',{'dtype':'SALE','doc_date':'2026-09-23','party_id':2,'items':[{'product_id':2,'qty':999,'rate':60,'gst_pct':5}],'paid_amount':0,'payment_mode':'Credit'}),'oversell (expect ERR)')
# sales return 1 rice against sale
sr=ok(api('save_doc',{'dtype':'SRET','doc_date':'2026-09-23','party_id':2,'against_doc_id':sl['id'],'items':[{'product_id':2,'qty':1,'rate':60,'gst_pct':5}],'paid_amount':0,'payment_mode':'Credit'}),'sales return')
ok(api('save_doc',{'dtype':'SRET','doc_date':'2026-09-23','party_id':2,'against_doc_id':sl['id'],'items':[{'product_id':2,'qty':5,'rate':60,'gst_pct':5}],'paid_amount':0,'payment_mode':'Credit'}),'over-return (expect ERR)')
pr=ok(api('save_doc',{'dtype':'PRET','doc_date':'2026-09-23','party_id':3,'against_doc_id':p['id'],'items':[{'product_id':1,'qty':2,'rate':20,'gst_pct':18}],'paid_amount':0,'payment_mode':'Credit'}),'purchase return')
ok(api('save_doc',{'dtype':'ADJ','doc_date':'2026-09-23','remarks':'damaged','items':[{'product_id':3,'qty':-2,'rate':5}]}),'adjustment')
# vouchers
r,fl=post('voucher_form',{'doc_date':'2026-09-23','party_id':2,'amount':200,'payment_mode':'Cash','after':''},'&t=RECEIPT'); print('receipt',fl)
r,fl=post('voucher_form',{'doc_date':'2026-09-23','party_id':3,'amount':300,'payment_mode':'Bank Transfer','reference_no':'NEFT1','after':''},'&t=PAYMENT'); print('payment',fl)
ec=dbv("select id from expense_categories limit 1")
r,fl=post('voucher_form',{'doc_date':'2026-09-23','amount':150,'payment_mode':'Cash','expense_category_id':ec,'description':'Tea','after':''},'&t=EXPENSE'); print('expense',fl)
acc=dbv("select group_concat(id,':',name,':',atype) from accounts"); print(acc)
r,fl=post('voucher_form',{'doc_date':'2026-09-23','amount':1000,'entry_type':'IN','account_id':1,'description':'Capital','after':''},'&t=CASH'); print('cash in',fl)
r,fl=post('voucher_form',{'doc_date':'2026-09-23','amount':400,'entry_type':'TRANSFER','account_id':1,'to_account_id':2,'description':'deposit','after':''},'&t=CASH'); print('transfer',fl)
# hold/resume
h=api('hold_save',{'payload':{'dtype':'SALE','party_id':2,'items':[{'product_id':3,'qty':1,'rate':10}]},'label':'counter2','grand_total':11.2}); print('hold',h)
print('holds',api('hold_list',get={}))
print('resume',api('hold_get',get={'id':h['id']})['payload']['items'])
print(api('hold_delete',{'id':h['id']}))
print('STOCK', dbv("select name,current_stock,(select sum(qty_in-qty_out) from stock_transactions t where t.product_id=p.id) from products p"))
print('PARTY', dbv("select p.name,p.opening_balance,(select sum(debit-credit) from party_ledger l where l.party_id=p.id) from parties p"))
print('ACCT', dbv("select a.name,(select sum(amount_in-amount_out) from account_transactions t where t.account_id=a.id) from accounts a"))
print('DOCS', dbv("select doc_no,dtype,grand_total,paid_amount,due_amount,created_by_name,device_name from documents"))
