from lib import *
import lib, concurrent.futures as cf, requests
stock=float(dbv("select current_stock from products where id=1")); print('soap before',stock)
sess=[]
for i in range(12):
    ss,_=login(['admin','mgr1','sales1'][i%3],'admin123' if i%3==0 else 'pass1234','PC%d'%i)
    tok=csrf(ss); sess.append((ss,tok))
def sell(a):
    ss,tok=a
    r=ss.post(B+'api.php?a=save_doc',json={'dtype':'SALE','doc_date':'2026-09-23','party_id':2,'items':[{'product_id':1,'qty':2,'rate':30,'gst_pct':18}],'paid_amount':0,'payment_mode':'Credit'},headers={'X-CSRF-Token':tok})
    return r.json()
with cf.ThreadPoolExecutor(12) as ex: res=list(ex.map(sell,sess))
okc=[r['doc_no'] for r in res if r.get('ok')]; print('ok',len(okc),sorted(okc)); print('errors',set(r.get('error') for r in res if not r.get('ok')))
print('soap after',dbv("select current_stock, (select sum(qty_in-qty_out) from stock_transactions where product_id=1) from products where id=1"))
print('dup numbers', dbv("select doc_no,count(*) c from documents group by doc_no having c>1"))
